import leds

leds = leds.LEDs()
leds.set(0, 'green')