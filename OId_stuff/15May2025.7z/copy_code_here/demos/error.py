# This demo just raises an exception.  When you run it from the
# default main.py, the exception text will print to the screen, and
# the buzzer will sound a low tone.

raise Exception("This is a test exception.")
