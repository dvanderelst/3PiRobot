#%%
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
from sklearn.decomposition import FastICA, PCA
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import Dataset, DataLoader
from Library import DataProcessor
from Library import Guidance

torch.set_num_threads(1)
torch.set_num_interop_threads(1)

seed = 1
np.random.seed(seed)
torch.manual_seed(seed)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device, flush=True)

# -----------------------------
# Settings
# -----------------------------
n_prev = 0  # previous frames (window uses n_prev + current)
use_rotation_history = False
base_components = 75
reduction = "pca"
d0 = 1000
batch_size_train = 64
batch_size_val = 128
drop_p = 0.2
epochs = 300
patience = 100

# -----------------------------
# Load and collate data
# -----------------------------
processor1 = DataProcessor.DataProcessor("session6")
processor2 = DataProcessor.DataProcessor("session7")
processor3 = DataProcessor.DataProcessor("session8")

collated1 = processor1.collate_data(d=d0)
collated2 = processor2.collate_data(d=d0)
collated3 = processor3.collate_data(d=d0)

sonar_flat1 = collated1["sonar_data"]  # (N, 200)
sonar_flat2 = collated2["sonar_data"]  # (N, 200)
sonar_flat3 = collated3["sonar_data"]  # (N, 200)
rotations1 = collated1['rotations']
rotations2 = collated2['rotations']
rotations3 = collated3['rotations']

vector_field1 = collated1['vector_field']
vector_field2 = collated2['vector_field']
vector_field3 = collated3['vector_field']

yaw_err1 = vector_field1["yaw_err_deg"].to_numpy(dtype=np.float32)
yaw_err2 = vector_field2["yaw_err_deg"].to_numpy(dtype=np.float32)
yaw_err3 = vector_field3["yaw_err_deg"].to_numpy(dtype=np.float32)
dir_x1 = vector_field1["dir_x"].to_numpy(dtype=np.float32)
dir_y1 = vector_field1["dir_y"].to_numpy(dtype=np.float32)
dir_x2 = vector_field2["dir_x"].to_numpy(dtype=np.float32)
dir_y2 = vector_field2["dir_y"].to_numpy(dtype=np.float32)
dir_x3 = vector_field3["dir_x"].to_numpy(dtype=np.float32)
dir_y3 = vector_field3["dir_y"].to_numpy(dtype=np.float32)
yaw_deg1 = collated1["rob_yaw_deg"].astype(np.float32)
yaw_deg2 = collated2["rob_yaw_deg"].astype(np.float32)
yaw_deg3 = collated3["rob_yaw_deg"].astype(np.float32)

polyline = collated1['polyline']

def build_sequence_features(
    sonar_flat,
    rotations,
    target_yaw_err,
    x_pos,
    y_pos,
    dir_x,
    dir_y,
    yaw_deg,
    n_prev,
    use_rotation_history,
):
    n = sonar_flat.shape[0]
    if n <= n_prev:
        raise ValueError("Not enough samples to build sequences")
    if rotations.shape[0] != n:
        raise ValueError("rotations length must match sonar length")
    if x_pos.shape[0] != n or y_pos.shape[0] != n:
        raise ValueError("position length must match sonar length")
    if dir_x.shape[0] != n or dir_y.shape[0] != n:
        raise ValueError("direction length must match sonar length")
    if yaw_deg.shape[0] != n:
        raise ValueError("yaw length must match sonar length")
    X_seq = []
    y_seq = []
    x_seq = []
    y_seq_pos = []
    dx_seq = []
    dy_seq = []
    yaw_seq = []
    for i in range(n_prev, n):
        window = sonar_flat[i - n_prev:i + 1]  # (n_prev+1, 200)
        rot_window = rotations[i - n_prev:i + 1].copy()  # (n_prev+1,)
        rot_window[-1] = 0.0  # avoid leaking current rotation into inputs
        if not use_rotation_history:
            rot_window[:] = 0.0
        x_feat = np.concatenate([window.reshape(-1), rot_window], axis=0)
        X_seq.append(x_feat)
        y_seq.append(target_yaw_err[i])
        x_seq.append(x_pos[i])
        y_seq_pos.append(y_pos[i])
        dx_seq.append(dir_x[i])
        dy_seq.append(dir_y[i])
        yaw_seq.append(yaw_deg[i])
    X_seq = np.array(X_seq, dtype=np.float32)
    y_seq = np.array(y_seq, dtype=np.float32)
    yaw_rad = np.deg2rad(y_seq)
    y_enc = np.column_stack([np.sin(yaw_rad), np.cos(yaw_rad)]).astype(np.float32)
    return (
        X_seq,
        y_enc,
        np.array(x_seq, dtype=np.float32),
        np.array(y_seq_pos, dtype=np.float32),
        np.array(dx_seq, dtype=np.float32),
        np.array(dy_seq, dtype=np.float32),
        np.array(yaw_seq, dtype=np.float32),
    )


X_seq1, y_seq1, x_pos1, y_pos1, dx1, dy1, yaw_deg1_seq = build_sequence_features(
    sonar_flat1,
    rotations1,
    yaw_err1,
    collated1["rob_x"],
    collated1["rob_y"],
    dir_x1,
    dir_y1,
    yaw_deg1,
    n_prev,
    use_rotation_history,
)
X_seq2, y_seq2, x_pos2, y_pos2, dx2, dy2, yaw_deg2_seq = build_sequence_features(
    sonar_flat2,
    rotations2,
    yaw_err2,
    collated2["rob_x"],
    collated2["rob_y"],
    dir_x2,
    dir_y2,
    yaw_deg2,
    n_prev,
    use_rotation_history,
)
X_seq3, y_seq3, x_pos3, y_pos3, dx3, dy3, yaw_deg3_seq = build_sequence_features(
    sonar_flat3,
    rotations3,
    yaw_err3,
    collated3["rob_x"],
    collated3["rob_y"],
    dir_x3,
    dir_y3,
    yaw_deg3,
    n_prev,
    use_rotation_history,
)

X_all = np.concatenate((X_seq1, X_seq2, X_seq3), axis=0).astype(np.float32)
y_all = np.concatenate((y_seq1, y_seq2, y_seq3), axis=0).astype(np.float32)
x_all = np.concatenate((x_pos1, x_pos2, x_pos3), axis=0).astype(np.float32)
y_all_pos = np.concatenate((y_pos1, y_pos2, y_pos3), axis=0).astype(np.float32)
dx_all = np.concatenate((dx1, dx2, dx3), axis=0).astype(np.float32)
dy_all = np.concatenate((dy1, dy2, dy3), axis=0).astype(np.float32)
yaw_deg_all = np.concatenate((yaw_deg1_seq, yaw_deg2_seq, yaw_deg3_seq), axis=0).astype(np.float32)

# -----------------------------
# Train/val split
# -----------------------------
X_train, X_val, y_train, y_val, x_train, x_val, y_train_pos, y_val_pos, dx_train, dx_val, dy_train, dy_val, yaw_train, yaw_val = train_test_split(
    X_all,
    y_all,
    x_all,
    y_all_pos,
    dx_all,
    dy_all,
    yaw_deg_all,
    test_size=0.2,
    random_state=seed,
    shuffle=True,
)

# -----------------------------
# Standardize features using train stats
# -----------------------------
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_val = scaler.transform(X_val)

# -----------------------------
# Dimensionality reduction
# -----------------------------
n_components = base_components * (n_prev + 1)
if reduction == "pca":
    reducer = PCA(n_components=n_components, random_state=seed)
    X_train = reducer.fit_transform(X_train)
    X_val = reducer.transform(X_val)
    print(f"PCA explained variance: {reducer.explained_variance_ratio_.sum():.3f}")
else:
    reducer = FastICA(n_components=n_components, random_state=seed, max_iter=1000)
    X_train = reducer.fit_transform(X_train)
    X_val = reducer.transform(X_val)
    print(f"ICA components: {n_components}")


class SonarYawSignDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.from_numpy(X)
        self.y = torch.from_numpy(y)

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        x = self.X[idx]  # (n_components,)
        return x, self.y[idx]


train_ds = SonarYawSignDataset(X_train, y_train)
val_ds = SonarYawSignDataset(X_val, y_val)

train_loader = DataLoader(train_ds, batch_size=batch_size_train, shuffle=True, drop_last=False)
val_loader = DataLoader(val_ds, batch_size=batch_size_val, shuffle=False, drop_last=False)


class YawSignCNN(nn.Module):
    def __init__(self, in_dim, hidden_dims, drop_p=0.2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dims[0]),
            nn.ReLU(),
            nn.Linear(hidden_dims[0], hidden_dims[1]),
            nn.ReLU(),
            nn.Linear(hidden_dims[1], hidden_dims[2]),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(hidden_dims[2], 2),
        )

    def forward(self, x):
        return self.net(x)


hidden_dims = [4 * n_components, 2 * n_components, n_components]
model = YawSignCNN(in_dim=n_components, hidden_dims=hidden_dims, drop_p=drop_p).to(device)
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=3e-4, weight_decay=1e-4)


def eval_metrics(model, loader):
    model.eval()
    ys, yps = [], []
    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(device)
            yp = model(xb)
            yp_norm = yp / (yp.norm(dim=1, keepdim=True) + 1e-8)
            yp = yp_norm.cpu().numpy()
            ys.append(yb.cpu().numpy())
            yps.append(yp)
    ys = np.vstack(ys)
    yps = np.vstack(yps)
    cos_loss = float(1.0 - np.mean(np.sum(ys * yps, axis=1)))
    ang_true = np.arctan2(ys[:, 0], ys[:, 1])
    ang_pred = np.arctan2(yps[:, 0], yps[:, 1])
    diff = (ang_pred - ang_true + np.pi) % (2 * np.pi) - np.pi
    ang_mae_deg = float(np.mean(np.abs(np.rad2deg(diff))))
    return cos_loss, ang_mae_deg, ys, yps


best_val = np.inf
best_state = None
pat = 0

for ep in range(1, epochs + 1):
    model.train()
    losses = []
    for xb, yb in train_loader:
        xb = xb.to(device)
        yb = yb.to(device)
        optimizer.zero_grad()
        yp = model(xb)
        yp_norm = yp / (yp.norm(dim=1, keepdim=True) + 1e-8)
        loss = 1.0 - torch.mean(torch.sum(yp_norm * yb, dim=1))
        loss.backward()
        optimizer.step()
        losses.append(loss.item())

    train_loss = float(np.mean(losses))
    val_cos, val_ang_mae, _, _ = eval_metrics(model, val_loader)
    print(
        f"Epoch {ep:03d} | train loss {train_loss:.5f} | "
        f"val cos loss {val_cos:.5f} | val ang MAE {val_ang_mae:.2f} deg"
    )

    if val_cos < best_val - 1e-5:
        best_val = val_cos
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        pat = 0
    else:
        pat += 1
        if pat >= patience:
            print(f"Early stop (best val cos loss {best_val:.5f})")
            break

if best_state is not None:
    model.load_state_dict(best_state)

# -----------------------------
# Diagnostics
# -----------------------------
val_cos, val_ang_mae, y_true_val, y_pred_val = eval_metrics(model, val_loader)
print(f"Final val cos loss: {val_cos:.5f} | val ang MAE {val_ang_mae:.2f} deg")

y_true_angle = np.rad2deg(np.arctan2(y_true_val[:, 0], y_true_val[:, 1]))
y_pred_angle = np.rad2deg(np.arctan2(y_pred_val[:, 0], y_pred_val[:, 1]))
angle_corr = float(np.corrcoef(y_true_angle, y_pred_angle)[0, 1])
print(f"Angle correlation (val): {angle_corr:.3f}")
lo, hi = np.percentile(y_true_angle, [2.5, 97.5])
mask = (y_true_angle >= lo) & (y_true_angle <= hi)
if mask.sum() >= 2:
    robust_corr = float(np.corrcoef(y_true_angle[mask], y_pred_angle[mask])[0, 1])
    print(f"Angle correlation (val, 2.5-97.5% trimmed): {robust_corr:.3f}")

sign_equal = np.sign(y_true_angle) == np.sign(y_pred_angle)
lims = [
    min(y_true_angle.min(), y_pred_angle.min()),
    max(y_true_angle.max(), y_pred_angle.max()),
]

print('correct sign prop', np.mean(sign_equal))

plt.figure()
plt.scatter(y_true_angle, y_pred_angle, c=sign_equal, s=8, alpha=0.5)
plt.plot(lims, lims, "k--", linewidth=1)
plt.xlabel("Yaw error true (deg)")
plt.ylabel("Yaw error predicted (deg)")
plt.title("Yaw error prediction scatter (val)")
plt.tight_layout()
plt.show()

angle_diff = (np.deg2rad(y_pred_angle) - np.deg2rad(y_true_angle) + np.pi) % (2 * np.pi) - np.pi
angle_diff_deg = np.rad2deg(angle_diff)
plt.figure()
plt.hist(angle_diff_deg, bins=50, alpha=0.8, edgecolor="black")
plt.xlabel("Yaw error prediction error (deg)")
plt.ylabel("Count")
plt.title("Distribution of yaw error prediction error (val)")
plt.tight_layout()
plt.show()

# -----------------------------
# Error over arena positions (val)
# -----------------------------
arrow_len = 50.0
pred_rad = np.deg2rad(y_pred_angle + yaw_val)
u = np.cos(pred_rad) * arrow_len
v = np.sin(pred_rad) * arrow_len
yaw_rad = np.deg2rad(yaw_val)
hx = np.cos(yaw_rad) * arrow_len
hy = np.sin(yaw_rad) * arrow_len
#%%
#
plt.figure()
sc = plt.scatter(x_val, y_val_pos, c=np.abs(angle_diff_deg), s=24, cmap="jet")
plt.plot(polyline[:, 0], polyline[:, 1], "k-", linewidth=1.5, label="path")
plt.quiver(
    x_val,
    y_val_pos,
    u,
    v,
    angles="xy",
    scale_units="xy",
    scale=1.0,
    width=0.003,
    color="black",
    alpha=0.5,
    label="pred heading",
)
plt.quiver(
    x_val,
    y_val_pos,
    dx_val,
    dy_val,
    angles="xy",
    scale_units="xy",
    scale=1.0 / arrow_len,
    width=0.003,
    color="limegreen",
    alpha=0.6,
    label="desired heading",
)
plt.quiver(
    x_val,
    y_val_pos,
    hx,
    hy,
    angles="xy",
    scale_units="xy",
    scale=1.0,
    width=0.003,
    color="tab:blue",
    alpha=0.6,
    label="current heading",
)
plt.colorbar(sc, label="|Yaw error| (deg)")
plt.xlabel("X (mm)")
plt.ylabel("Y (mm)")
plt.title("Yaw error magnitude over poses (val)")
plt.axis("equal")
plt.legend()
plt.tight_layout()
plt.show()
