#%%
"""
Learn a soft-min summary of the profile with a learnable temperature (tau),
and train a network to predict that summary from binaural sonar.
"""
import numpy as np
import torch
import torch.nn as nn
from sklearn.decomposition import FastICA, PCA
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import Dataset, DataLoader
from Library import Utils
from Library import DataProcessor
from matplotlib import pyplot as plt


torch.set_num_threads(1)
torch.set_num_interop_threads(1)

seed = 123
np.random.seed(seed)
torch.manual_seed(seed)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device, flush=True)

# -----------------------------
# Settings
# -----------------------------
az_steps = 21
max_extent = 20
use_raw_sonar = True
reduction = "pca"  # "pca", "ica", or None
base_components = 75
batch_size_train = 64
batch_size_val = 128
drop_p = 0.1
epochs = 400
patience = 100
tau_init = 0.3  # degrees of smoothing for soft-min (lower -> closer to true min)

# -----------------------------
# Load and collate data
# -----------------------------
processor1 = DataProcessor.DataProcessor("session6")
processor2 = DataProcessor.DataProcessor("session7")
processor3 = DataProcessor.DataProcessor("session8")

collated1 = processor1.collate_data(az_min=-max_extent, az_max=max_extent, az_steps=az_steps)
collated2 = processor2.collate_data(az_min=-max_extent, az_max=max_extent, az_steps=az_steps)
collated3 = processor3.collate_data(az_min=-max_extent, az_max=max_extent, az_steps=az_steps)

collated_results = [collated1, collated2, collated3]
profiles = DataProcessor.collect(collated_results, "profiles").astype(np.float32)
centers = np.round(collated1["centers"]).astype(np.float32)
sonar_flat = DataProcessor.collect(collated_results, "sonar_data")  # flattened L/R echoes
sonar_distance = DataProcessor.collect(collated_results, "corrected_distance")  # meters

profile_m = profiles / 1000.0
closest_visual_distance = Utils.get_extrema_values(profiles, "min") / 1000.0

# -----------------------------
# Build feature matrix
# -----------------------------
if use_raw_sonar:
    X = sonar_flat.astype(np.float32)
else:
    raise ValueError("No sonar features selected.")

valid = np.isfinite(X).all(axis=1)
valid &= np.isfinite(profile_m).all(axis=1)
valid &= np.isfinite(closest_visual_distance)

X = X[valid]
profile_m = profile_m[valid]
closest_visual_distance = closest_visual_distance[valid]
sonar_distance = sonar_distance[valid]

# -----------------------------
# Train/val split
# -----------------------------
X_train, X_val, profile_train, profile_val, min_train, min_val, sonar_dist_train, sonar_dist_val = train_test_split(
    X,
    profile_m,
    closest_visual_distance,
    sonar_distance,
    test_size=0.2,
    random_state=seed,
    shuffle=True,
)

# -----------------------------
# Standardize features using train stats
# -----------------------------
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_val = scaler.transform(X_val)

# -----------------------------
# Optional dimensionality reduction
# -----------------------------
if reduction in ("pca", "ica"):
    n_components = base_components
    n_components = min(n_components, X_train.shape[1])
    if reduction == "pca":
        reducer = PCA(n_components=n_components, random_state=seed)
    else:
        reducer = FastICA(n_components=n_components, random_state=seed, max_iter=1000)
    X_train = reducer.fit_transform(X_train)
    X_val = reducer.transform(X_val)


class SonarDataset(Dataset):
    def __init__(self, X, profiles):
        self.X = torch.from_numpy(X.astype(np.float32))
        self.profiles = torch.from_numpy(profiles.astype(np.float32))

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        return self.X[idx], self.profiles[idx]


train_loader = DataLoader(
    SonarDataset(X_train, profile_train),
    batch_size=batch_size_train,
    shuffle=True,
    drop_last=False,
)
val_loader = DataLoader(
    SonarDataset(X_val, profile_val),
    batch_size=batch_size_val,
    shuffle=False,
    drop_last=False,
)

input_dim = X_train.shape[1]
hidden1 = max(128, min(512, input_dim * 2))
hidden2 = max(96, min(320, input_dim))
hidden3 = max(48, min(160, input_dim // 2))


class SonarNet(nn.Module):
    def __init__(self, in_dim, h1, h2, h3, drop_p):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, h1),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(h1, h2),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(h2, h3),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(h3, 1),
        )

    def forward(self, x):
        return self.net(x).squeeze(1)


class SoftMinTau(nn.Module):
    def __init__(self, init_tau):
        super().__init__()
        self.log_tau = nn.Parameter(torch.tensor(np.log(init_tau), dtype=torch.float32))

    def forward(self):
        return torch.nn.functional.softplus(self.log_tau) + 1e-6


model = SonarNet(input_dim, hidden1, hidden2, hidden3, drop_p).to(device)
tau_module = SoftMinTau(tau_init).to(device)
optimizer = torch.optim.Adam(list(model.parameters()) + list(tau_module.parameters()), lr=1e-3)
criterion_reg = nn.SmoothL1Loss()

best_val = float("inf")
best_state = None
pat_left = patience

for epoch in range(1, epochs + 1):
    model.train()
    tau_module.train()
    total_loss = 0.0
    for xb, prof_b in train_loader:
        xb = xb.to(device)
        prof_b = prof_b.to(device)
        optimizer.zero_grad()
        tau = tau_module()
        weights = torch.softmax(-prof_b / tau, dim=1)
        target = torch.sum(prof_b * weights, dim=1)
        target_log = torch.log1p(target)
        pred_log = model(xb)
        loss = criterion_reg(pred_log, target_log)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * xb.size(0)

    train_loss = total_loss / len(train_loader.dataset)

    model.eval()
    tau_module.eval()
    val_loss = 0.0
    with torch.no_grad():
        for xb, prof_b in val_loader:
            xb = xb.to(device)
            prof_b = prof_b.to(device)
            tau = tau_module()
            weights = torch.softmax(-prof_b / tau, dim=1)
            target = torch.sum(prof_b * weights, dim=1)
            target_log = torch.log1p(target)
            pred_log = model(xb)
            loss = criterion_reg(pred_log, target_log)
            val_loss += loss.item() * xb.size(0)

    val_loss /= len(val_loader.dataset)
    print(
        f"Epoch {epoch:03d} | train loss {train_loss:.5f} | val loss {val_loss:.5f}",
        flush=True,
    )

    if val_loss < best_val - 1e-6:
        best_val = val_loss
        best_state = {
            "model": {k: v.detach().cpu().clone() for k, v in model.state_dict().items()},
            "tau": {k: v.detach().cpu().clone() for k, v in tau_module.state_dict().items()},
        }
        pat_left = patience
    else:
        pat_left -= 1
        if pat_left <= 0:
            print("Early stop", flush=True)
            break

if best_state is not None:
    model.load_state_dict(best_state["model"])
    tau_module.load_state_dict(best_state["tau"])

# -----------------------------
# Evaluation and plots
# -----------------------------
model.eval()
tau_module.eval()
with torch.no_grad():
    tau_val = float(tau_module().cpu().numpy())
    weights_val = np.exp(-profile_val / tau_val)
    weights_val = weights_val / np.sum(weights_val, axis=1, keepdims=True)
    target_train = np.sum(profile_train * (np.exp(-profile_train / tau_val) / np.sum(np.exp(-profile_train / tau_val), axis=1, keepdims=True)), axis=1)
    target_val = np.sum(profile_val * weights_val, axis=1)
    pred_log = model(torch.from_numpy(X_val).to(device)).cpu().numpy()
    pred_val = np.expm1(pred_log)

mae_val = float(np.mean(np.abs(pred_val - target_val)))
print(f"Val MAE vs learned target (m): {mae_val:.3f}", flush=True)
print(f"Learned tau (soft-min): {tau_val:.4f}", flush=True)
print(f"Learned target mean (m): {float(np.mean(target_val)):.3f}", flush=True)
print(f"Closest visual distance mean (m): {float(np.mean(min_val)):.3f}", flush=True)

example_idx = 0
example_weights = np.exp(-profile_val[example_idx] / tau_val)
example_weights = example_weights / np.sum(example_weights)
plt.figure(figsize=(6, 4))
plt.plot(centers, example_weights, marker="o")
plt.xlabel("Azimuth (deg)")
plt.ylabel("Soft-min weight")
plt.title("Soft-min weights (example profile)")
plt.tight_layout()
plt.show()

plot_min = float(min(target_val.min(), pred_val.min()))
plot_max = float(max(target_val.max(), pred_val.max()))
lims = [plot_min, plot_max]

plt.figure(figsize=(6, 5))
rho = float(np.corrcoef(target_val, pred_val)[0, 1])
plt.scatter(target_val, pred_val, s=8, alpha=0.5)
plt.plot(lims, lims, "k--", linewidth=1)
plt.xlabel("Learned target distance (m)")
plt.ylabel("Predicted distance (m)")
plt.title(f"Learned target prediction (val) r={rho:.2f}")
plt.xlim(lims)
plt.ylim(lims)
plt.tight_layout()
plt.show()

plt.figure(figsize=(6, 5))
rho_min = float(np.corrcoef(min_val, target_val)[0, 1])
plt.scatter(min_val, target_val, s=8, alpha=0.5)
plt.xlabel("Closest visual distance (m)")
plt.ylabel("Learned target distance (m)")
plt.title(f"Learned target vs min distance r={rho_min:.2f}")
plt.tight_layout()
plt.show()
