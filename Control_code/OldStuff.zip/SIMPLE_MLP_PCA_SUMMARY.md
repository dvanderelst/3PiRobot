# Wider MLP with PCA for Sonar Distance Prediction

## Overview
This is an enhanced approach using a wider Multi-Layer Perceptron (MLP) with Principal Component Analysis (PCA) for dimensionality reduction. The wider architecture can capture more complex patterns while still being efficient due to the PCA preprocessing.

## Key Features

### 1. PCA for Dimensionality Reduction
- **Input**: 200 sonar features → **Output**: 50 principal components
- **Variance Preservation**: Typically captures 90-95% of the original variance
- **Benefits**: 
  - Faster training
  - Reduced risk of overfitting
  - Better interpretability
  - Noise reduction

### 2. Wider MLP Architecture
```
PCA Components (50) → FC Layer (128) → FC Layer (64) → FC Layer (32) → Output (1)
```
- **Activation**: ReLU
- **Regularization**: Dropout (0.2)
- **Optimizer**: Adam
- **Loss Function**: Mean Squared Error (MSE)
- **Capacity**: Increased width for better feature learning

### 3. Training Process
- **Batch Size**: 32
- **Epochs**: 50
- **Learning Rate**: 0.001
- **Train/Test Split**: 80/20

## Data Flow

1. **Load Data**: Sonar measurements and visual distance targets
2. **Clean Data**: Remove NaN values
3. **Normalize**: Standard scaling (mean=0, std=1)
4. **PCA**: Reduce from 200 to 50 dimensions
5. **Train MLP**: Simple 3-layer network
6. **Evaluate**: Calculate MSE, RMSE, MAE metrics
7. **Save Model**: Includes PCA and scaler parameters

## How to Run

```bash
cd /home/dieter/Dropbox/PythonRepos/3PiRobot/Control_code
python SCRIPT_TrainRobot.py
```

## Expected Output

1. **PCA Variance Plot**: Shows how much variance each component captures
2. **Training Curves**: Train and test loss over epochs
3. **Prediction Plot**: Actual vs predicted distances with correlation coefficient
4. **Correlation Analysis**: Standardized correlation plot
5. **Residual Plot**: Error distribution with MAE
6. **Correlation Metrics**: Pearson correlation (r) and R-squared (r²)
7. **Model File**: `simple_mlp_sonar_model.pth`

## Model Saving

The saved model includes:
- MLP weights and biases
- PCA parameters (mean, components)
- Scaler parameters (mean, scale)
- Input size information

This allows for complete end-to-end inference without needing to recompute PCA.

## Advantages of This Approach

1. **Simplicity**: Easy to understand and modify
2. **Speed**: Fast training due to dimensionality reduction
3. **Robustness**: PCA helps with noise reduction
4. **Interpretability**: Can analyze which sonar features contribute most
5. **Scalability**: Easy to add more data or adjust PCA components
6. **Comprehensive Evaluation**: Includes correlation analysis for better model understanding
7. **Model Checkpointing**: Automatically saves and restores the best validation model
8. **Configurable**: All key parameters are easily adjustable at the top of the script

## Parameters to Tune

- `n_pca_components`: Try values like 30, 50, 75, 100
- `n_epochs`: Number of training epochs (default: 100)
- `batch_size`: Try 16, 32, 64
- `learning_rate`: Try 0.001, 0.0005, 0.005
- `use_model_checkpointing`: Enable/disable best model restoration (default: True)

## Next Steps

Once this baseline works well, you can:
1. Increase PCA components for more detail
2. Deepen the MLP (add more layers)
3. Widen the MLP (add more neurons per layer)
4. Try different activation functions
5. Add more sophisticated regularization

This simple approach provides a solid foundation that's easy to build upon!