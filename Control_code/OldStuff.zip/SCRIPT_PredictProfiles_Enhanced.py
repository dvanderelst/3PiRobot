#
# SCRIPT_PredictProfiles_Enhanced: Predict wall distance profiles using the enhanced CNN model
#
# This script loads the trained enhanced sonar-to-profile CNN model and predicts wall distance
# profiles for sonar data from specified sessions. It supports both the original and enhanced
# model architectures.
#
# Usage: Set the session_to_predict variable to the session you want to analyze
#
# Input: Sonar data (N, 2, 200) from specified session
# Output: Predicted profile data (N, profile_steps)
#
# Dependencies: Requires a trained model in the specified output directory
#

# ============================================
# CONFIGURATION SETTINGS
# ============================================

# Prediction Configuration
session_to_predict = 'sessionB05'  # Session to predict profiles for
output_dir = 'Training_Optimized'    # Directory containing trained model

# Model Selection
use_enhanced_model = True          # Set to False to use original model architecture

# Profile Parameters (loaded automatically from training)
# These parameters are loaded from training_params.json - do not set them here!
# To change profile settings, modify the training script

# Visualization Configuration
plot_indices = [5, 50]  # Set to None to disable plotting, or specify range like [0, 5]
# Note: All selected indices are plotted on a single comprehensive plot in world coordinates
# Example: plot_indices = [0, 5] plots indices 0, 1, 2, 3, and 4 together

# ============================================
# IMPORTS
# ============================================

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import StandardScaler
import os
import joblib
from matplotlib import pyplot as plt

from Library import DataProcessor
from Library import Utils
from Library.DataProcessor import robot2world

# Set device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"🔥 Using device: {device}")

class SimpleResidualBlock(nn.Module):
    """Simplified residual block with better regularization."""
    def __init__(self, channels, kernel_size=5):
        super(SimpleResidualBlock, self).__init__()
        
        self.conv1 = nn.Sequential(
            nn.Conv1d(channels, channels, kernel_size, padding=kernel_size//2),
            nn.BatchNorm1d(channels),
            nn.ReLU()
        )
        
        self.conv2 = nn.Sequential(
            nn.Conv1d(channels, channels, kernel_size, padding=kernel_size//2),
            nn.BatchNorm1d(channels)
        )
        
        self.relu = nn.ReLU()
    
    def forward(self, x):
        residual = x
        out = self.conv1(x)
        out = self.conv2(out)
        out += residual  # Residual connection
        out = self.relu(out)
        return out

class SimpleTemporalAttention(nn.Module):
    """Simplified temporal attention mechanism."""
    def __init__(self, channels, reduction=8):
        super(SimpleTemporalAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, channels // reduction),
            nn.ReLU(),
            nn.Linear(channels // reduction, channels),
            nn.Sigmoid()
        )
    
    def forward(self, x):
        # x shape: (batch_size, channels, time_steps)
        b, c, _ = x.size()
        y = self.avg_pool(x).reshape(b, c)
        y = self.fc(y).reshape(b, c, 1)
        return x * y.expand_as(x)

class SonarToProfileCNN(nn.Module):
    """Original CNN model matching the basic training architecture."""
    def __init__(self, input_shape, output_shape, training_params=None):
        super(SonarToProfileCNN, self).__init__()
        
        # Input: (batch_size, channels=2, time_samples=200)
        # Use parameters from training if provided, otherwise use defaults
        if training_params is None:
            training_params = {
                'conv_filters': [32, 64, 128],
                'kernel_size': 5,
                'pool_size': 2,
                'dropout_rate': 0.3
            }
        
        conv_filters = training_params['conv_filters']  # number of filters in each conv layer
        kernel_size = training_params['kernel_size']    # convolution kernel size
        pool_size = training_params['pool_size']        # max pooling size
        dropout_rate = training_params['dropout_rate']   # dropout rate for regularization
        
        self.conv1 = nn.Sequential(
            nn.Conv1d(in_channels=2, out_channels=conv_filters[0], kernel_size=kernel_size),
            nn.BatchNorm1d(conv_filters[0]),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=pool_size),
            nn.Dropout(dropout_rate)
        )
        
        self.conv2 = nn.Sequential(
            nn.Conv1d(conv_filters[0], conv_filters[1], kernel_size=kernel_size),
            nn.BatchNorm1d(conv_filters[1]),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=pool_size),
            nn.Dropout(dropout_rate)
        )
        
        self.conv3 = nn.Sequential(
            nn.Conv1d(conv_filters[1], conv_filters[2], kernel_size=kernel_size),
            nn.BatchNorm1d(conv_filters[2]),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=pool_size),
            nn.Dropout(dropout_rate)
        )
        
        # Calculate the size after conv layers
        self._calculate_flattened_size(input_shape)
        
        self.fc = nn.Sequential(
            nn.Linear(self.flattened_size, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(128, output_shape)
        )
    
    def _calculate_flattened_size(self, input_shape):
        """Calculate the flattened size after convolutional layers."""
        with torch.no_grad():
            # Create a dummy input tensor
            dummy_input = torch.zeros(1, *input_shape)
            
            # Pass through conv layers
            x = self.conv1(dummy_input)
            x = self.conv2(x)
            x = self.conv3(x)
            
            # Flatten and get size
            self.flattened_size = x.reshape(x.size(0), -1).shape[1]
    
    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = x.reshape(x.size(0), -1)  # Flatten
        x = self.fc(x)
        return x

class ResidualBlock(nn.Module):
    """Residual block for better gradient flow."""
    def __init__(self, in_channels, out_channels, kernel_size=5):
        super(ResidualBlock, self).__init__()
        
        self.conv1 = nn.Sequential(
            nn.Conv1d(in_channels, out_channels, kernel_size, padding=kernel_size//2),
            nn.BatchNorm1d(out_channels),
            nn.ReLU()
        )
        
        self.conv2 = nn.Sequential(
            nn.Conv1d(out_channels, out_channels, kernel_size, padding=kernel_size//2),
            nn.BatchNorm1d(out_channels)
        )
        
        # Shortcut connection if dimensions change
        self.shortcut = nn.Sequential()
        if in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv1d(in_channels, out_channels, 1),
                nn.BatchNorm1d(out_channels)
            )
        
        self.relu = nn.ReLU()
    
    def forward(self, x):
        residual = self.shortcut(x)
        out = self.conv1(x)
        out = self.conv2(out)
        out += residual  # Residual connection
        out = self.relu(out)
        return out

class TemporalAttention(nn.Module):
    """Temporal attention mechanism for focusing on important time steps."""
    def __init__(self, channels, reduction=8):
        super(TemporalAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, channels // reduction),
            nn.ReLU(),
            nn.Linear(channels // reduction, channels),
            nn.Sigmoid()
        )
    
    def forward(self, x):
        # x shape: (batch_size, channels, time_steps)
        b, c, _ = x.size()
        y = self.avg_pool(x).reshape(b, c)
        y = self.fc(y).reshape(b, c, 1)
        return x * y.expand_as(x)

class MultiHeadAttention1D(nn.Module):
    """Multi-head attention for 1D temporal data."""
    def __init__(self, embed_dim, num_heads, dropout=0.1):
        super(MultiHeadAttention1D, self).__init__()
        self.attention = nn.MultiheadAttention(embed_dim, num_heads, dropout=dropout, batch_first=True)
    
    def forward(self, x):
        # x shape: (batch_size, channels, time_steps)
        b, c, t = x.size()
        
        # Reshape for attention: (batch_size, time_steps, channels)
        x_attn = x.permute(0, 2, 1)
        
        # Self-attention
        attn_output, _ = self.attention(x_attn, x_attn, x_attn)
        
        # Reshape back: (batch_size, channels, time_steps)
        return attn_output.permute(0, 2, 1)

class SonarToProfileCNNOptimized(nn.Module):
    """Optimized CNN model with balanced complexity."""
    def __init__(self, input_shape, output_shape, training_params=None):
        super(SonarToProfileCNNOptimized, self).__init__()
        
        # Use parameters from training if provided, otherwise use defaults
        if training_params is None:
            training_params = {
                'conv_filters': [48, 96, 144],
                'kernel_size': 5,
                'pool_size': 2,
                'dropout_rate': 0.25,
                'use_residual_connections': True,
                'use_simple_attention': True,
                'use_skip_connections': False
            }
        
        conv_filters = training_params['conv_filters']
        kernel_size = training_params['kernel_size']
        pool_size = training_params['pool_size']
        dropout_rate = training_params['dropout_rate']
        
        # Input: (batch_size, channels=2, time_samples=200)
        self.initial_conv = nn.Sequential(
            nn.Conv1d(in_channels=2, out_channels=conv_filters[0], kernel_size=kernel_size, padding=kernel_size//2),
            nn.BatchNorm1d(conv_filters[0]),
            nn.ReLU(),
            nn.Dropout(dropout_rate)
        )
        
        # First convolutional block
        self.conv_block1 = nn.Sequential(
            nn.Conv1d(conv_filters[0], conv_filters[0], kernel_size=kernel_size, padding=kernel_size//2),
            nn.BatchNorm1d(conv_filters[0]),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=pool_size),
            nn.Dropout(dropout_rate)
        )
        
        # Residual block with attention
        if training_params.get('use_residual_connections', True):
            self.res_block = SimpleResidualBlock(conv_filters[0])
        else:
            self.res_block = nn.Sequential(
                nn.Conv1d(conv_filters[0], conv_filters[0], kernel_size=kernel_size, padding=kernel_size//2),
                nn.BatchNorm1d(conv_filters[0]),
                nn.ReLU()
            )
        
        if training_params.get('use_simple_attention', True):
            self.attention = SimpleTemporalAttention(conv_filters[0])
        else:
            self.attention = nn.Identity()  # No-op if attention disabled
        
        # Second convolutional block
        self.conv_block2 = nn.Sequential(
            nn.Conv1d(conv_filters[0], conv_filters[1], kernel_size=kernel_size, padding=kernel_size//2),
            nn.BatchNorm1d(conv_filters[1]),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=pool_size),
            nn.Dropout(dropout_rate)
        )
        
        # Third convolutional block
        self.conv_block3 = nn.Sequential(
            nn.Conv1d(conv_filters[1], conv_filters[2], kernel_size=kernel_size, padding=kernel_size//2),
            nn.BatchNorm1d(conv_filters[2]),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=pool_size),
            nn.Dropout(dropout_rate)
        )
        
        # Calculate the size after conv layers
        self._calculate_flattened_size(input_shape)
        
        # Moderate fully connected layers
        self.fc = nn.Sequential(
            nn.Linear(self.flattened_size, 384),  # Reduced from 512
            nn.BatchNorm1d(384),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(384, 192),           # Reduced from 256
            nn.BatchNorm1d(192),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(192, output_shape)
        )
    
    def _calculate_flattened_size(self, input_shape):
        """Calculate the flattened size after convolutional layers."""
        with torch.no_grad():
            # Create a dummy input tensor
            dummy_input = torch.zeros(1, *input_shape)
            
            # Pass through all layers
            x = self.initial_conv(dummy_input)
            x = self.conv_block1(x)
            x = self.res_block(x)
            x = self.attention(x)
            x = self.conv_block2(x)
            x = self.conv_block3(x)
            
            # Flatten and get size
            self.flattened_size = x.reshape(x.size(0), -1).shape[1]
    
    def forward(self, x):
        # Initial convolution
        x = self.initial_conv(x)
        
        # First conv block
        x = self.conv_block1(x)
        
        # Residual block with attention
        x = self.res_block(x)
        x = self.attention(x)
        
        # Second and third conv blocks
        x = self.conv_block2(x)
        x = self.conv_block3(x)
        
        # Flatten for fully connected layers
        x = x.reshape(x.size(0), -1)
        
        # Fully connected layers
        x = self.fc(x)
        
        return x

class SonarToProfileCNNEnhanced(nn.Module):
    """Enhanced CNN model with residual connections and attention mechanisms."""
    def __init__(self, input_shape, output_shape, training_params=None):
        super(SonarToProfileCNNEnhanced, self).__init__()
        
        # Use parameters from training if provided, otherwise use defaults
        if training_params is None:
            training_params = {
                'conv_filters': [64, 128, 256],
                'kernel_size': 5,
                'pool_size': 2,
                'dropout_rate': 0.2,
                'attention_heads': 4,
                'attention_dropout': 0.1
            }
        
        conv_filters = training_params['conv_filters']
        kernel_size = training_params['kernel_size']
        pool_size = training_params['pool_size']
        dropout_rate = training_params['dropout_rate']
        attention_heads = training_params.get('attention_heads', 4)
        attention_dropout = training_params.get('attention_dropout', 0.1)
        
        # Input: (batch_size, channels=2, time_samples=200)
        self.initial_conv = nn.Sequential(
            nn.Conv1d(in_channels=2, out_channels=conv_filters[0], kernel_size=kernel_size, padding=kernel_size//2),
            nn.BatchNorm1d(conv_filters[0]),
            nn.ReLU(),
            nn.Dropout(dropout_rate)
        )
        
        # Residual blocks
        self.res_block1 = ResidualBlock(conv_filters[0], conv_filters[0])
        self.attention1 = TemporalAttention(conv_filters[0])
        
        self.downsample1 = nn.Sequential(
            nn.Conv1d(conv_filters[0], conv_filters[1], kernel_size=1, stride=2),
            nn.BatchNorm1d(conv_filters[1])
        )
        
        self.res_block2 = ResidualBlock(conv_filters[1], conv_filters[1])
        self.attention2 = TemporalAttention(conv_filters[1])
        
        self.downsample2 = nn.Sequential(
            nn.Conv1d(conv_filters[1], conv_filters[2], kernel_size=1, stride=2),
            nn.BatchNorm1d(conv_filters[2])
        )
        
        self.res_block3 = ResidualBlock(conv_filters[2], conv_filters[2])
        self.attention3 = TemporalAttention(conv_filters[2])
        
        # Multi-head attention for global temporal relationships
        self.multihead_attn = MultiHeadAttention1D(conv_filters[2], attention_heads, attention_dropout)
        
        # Calculate the size after conv layers
        self._calculate_flattened_size(input_shape)
        
        # Enhanced fully connected layers with skip connections
        self.fc1 = nn.Sequential(
            nn.Linear(self.flattened_size, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Dropout(dropout_rate)
        )
        
        self.fc2 = nn.Sequential(
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(dropout_rate)
        )
        
        self.fc3 = nn.Sequential(
            nn.Linear(256, output_shape)
        )
        
        # Skip connection from intermediate layer
        self.skip_fc = nn.Linear(self.flattened_size, output_shape)
    
    def _calculate_flattened_size(self, input_shape):
        """Calculate the flattened size after convolutional layers."""
        with torch.no_grad():
            # Create a dummy input tensor
            dummy_input = torch.zeros(1, *input_shape)
            
            # Pass through initial conv
            x = self.initial_conv(dummy_input)
            
            # Pass through residual blocks and downsampling
            x = self.res_block1(x)
            x = self.downsample1(x)
            
            x = self.res_block2(x)
            x = self.downsample2(x)
            
            x = self.res_block3(x)
            
            # Flatten and get size
            self.flattened_size = x.reshape(x.size(0), -1).shape[1]
    
    def forward(self, x):
        # Initial convolution
        x = self.initial_conv(x)
        
        # First residual block with attention
        x = self.res_block1(x)
        x = self.attention1(x)
        x = self.downsample1(x)
        
        # Second residual block with attention
        x = self.res_block2(x)
        x = self.attention2(x)
        x = self.downsample2(x)
        
        # Third residual block with attention
        x = self.res_block3(x)
        x = self.attention3(x)
        
        # Multi-head attention for global temporal relationships
        x = self.multihead_attn(x)
        
        # Flatten for fully connected layers
        x_flat = x.reshape(x.size(0), -1)
        
        # Fully connected layers with skip connection
        x_fc1 = self.fc1(x_flat)
        x_fc2 = self.fc2(x_fc1)
        
        # Main output
        main_output = self.fc3(x_fc2)
        
        # Skip connection from flattened features
        skip_output = self.skip_fc(x_flat)
        
        # Combine outputs
        return main_output + skip_output

def load_training_parameters():
    """Load training parameters from saved metadata."""
    params_path = f'{output_dir}/training_params.json'
    
    if os.path.exists(params_path):
        import json
        with open(params_path, 'r') as f:
            params = json.load(f)
        print(f"✅ Loaded training parameters from: {params_path}")
        return params
    else:
        print("⚠️  Training parameters file not found. Using default values.")
        print(f"   Expected file: {params_path}")
        print("   Make sure to run training script to generate this file.")
        # Return default values that should match typical training
        if use_enhanced_model:
            return {
                'profile_opening_angle': 30,
                'profile_steps': 11,
                'conv_filters': [64, 128, 256],
                'kernel_size': 5,
                'pool_size': 2,
                'dropout_rate': 0.2,
                'attention_heads': 4,
                'attention_dropout': 0.1
            }
        else:
            return {
                'profile_opening_angle': 30,
                'profile_steps': 11,
                'conv_filters': [32, 64, 128],
                'kernel_size': 5,
                'pool_size': 2,
                'dropout_rate': 0.3
            }

def load_scalers_from_training():
    """Load scalers from training metadata."""
    x_scaler_path = f'{output_dir}/x_scaler.joblib'
    y_scaler_path = f'{output_dir}/y_scaler.joblib'
    
    if os.path.exists(x_scaler_path) and os.path.exists(y_scaler_path):
        x_scaler = joblib.load(x_scaler_path)
        y_scaler = joblib.load(y_scaler_path)
        print(f"✅ Loaded scalers from: {output_dir}")
        return x_scaler, y_scaler
    else:
        print("❌ Scaler files not found. Please run training first.")
        print(f"   Expected files: {x_scaler_path}, {y_scaler_path}")
        print(f"   Current working directory: {os.getcwd()}")
        print(f"   Make sure {output_dir}/ directory exists and contains scaler files.")
        print(f"   Run training script first: python SCRIPT_Sonar2Profiles_Enhanced.py")
        raise FileNotFoundError("Scaler files not found. Please train the model first.")

def load_and_preprocess_data(profile_opening_angle, profile_steps):
    """Load and preprocess sonar data for prediction."""
    print(f"📡 Loading data for session: {session_to_predict}")
    
    # Load data for the specified session
    dc = DataProcessor.DataCollection([session_to_predict])
    sonar = dc.load_sonar(flatten=False)
    profiles, _ = dc.load_profiles(opening_angle=profile_opening_angle, steps=profile_steps)
    
    print(f"📊 Sonar data shape: {sonar.shape}")
    print(f"📊 Profile data shape: {profiles.shape}")
    
    # Remove NaN values
    nan_mask = ~np.isnan(profiles).any(axis=1)
    sonar = sonar[nan_mask]
    profiles = profiles[nan_mask]
    
    print(f"📊 Clean data shapes - Sonar: {sonar.shape}, Profiles: {profiles.shape}")
    
    return sonar, profiles

def preprocess_data(sonar, profiles, x_scaler, y_scaler):
    """Preprocess data using scalers from training."""
    print("🧹 Preprocessing data...")
    
    # Normalize profile data (target)
    y_scaled = y_scaler.transform(profiles)
    
    # Normalize sonar data (input)
    # Reshape to (N*200, 2) for scaling, then reshape back
    original_shape = sonar.shape
    X_reshaped = sonar.reshape(-1, 2)
    
    X_scaled = x_scaler.transform(X_reshaped).reshape(original_shape)
    
    # Convert to PyTorch tensors and move to device
    # PyTorch expects (N, C, L) format for Conv1D
    X_tensor = torch.FloatTensor(X_scaled).permute(0, 2, 1).to(device)
    y_tensor = torch.FloatTensor(y_scaled).to(device)
    
    # Create dataset and data loader
    dataset = TensorDataset(X_tensor, y_tensor)
    data_loader = DataLoader(dataset, batch_size=32, shuffle=False)
    
    return data_loader, x_scaler, y_scaler

def predict_profiles(model, data_loader, y_scaler):
    """Make predictions using the trained model."""
    print("📊 Making predictions...")
    
    model.eval()
    
    all_predictions = []
    all_targets = []
    
    with torch.no_grad():
        for inputs, targets in data_loader:
            outputs = model(inputs)
            
            all_predictions.append(outputs.cpu().numpy())
            all_targets.append(targets.cpu().numpy())
    
    # Concatenate all batches
    y_pred_scaled = np.concatenate(all_predictions, axis=0)
    y_test_scaled = np.concatenate(all_targets, axis=0)
    
    # Inverse transform to get actual values
    y_pred = y_scaler.inverse_transform(y_pred_scaled)
    y_test_actual = y_scaler.inverse_transform(y_test_scaled)
    
    return y_pred, y_test_actual

def transform_profiles_to_world(profile_distances, profile_azimuths, rob_x, rob_y, rob_yaw_deg):
    """Transform profile distances from robot-relative to world coordinates."""
    # Profile is a 1D array where each element is the distance at a specific azimuth
    # Transform each (azimuth, distance) pair to world coordinates
    x_world, y_world = robot2world(profile_azimuths, profile_distances, rob_x, rob_y, rob_yaw_deg)
    
    return x_world, y_world

def main():
    """Main prediction pipeline."""
    print("🚀 Starting profile prediction using trained CNN")
    print(f"   Session: {session_to_predict}")
    print(f"   Model: {output_dir}/best_model_pytorch.pth")
    print(f"   Using enhanced model: {use_enhanced_model}")
    
    # Load training parameters to ensure consistency
    training_params = load_training_parameters()
    
    # Extract parameters from training (these are NOT configurable in prediction script)
    profile_opening_angle = training_params['profile_opening_angle']
    profile_steps = training_params['profile_steps']
    
    print(f"📊 Using training parameters:")
    print(f"   Profile opening angle: {profile_opening_angle}°")
    print(f"   Profile steps: {profile_steps}")
    
    # Load and preprocess data
    sonar, profiles = load_and_preprocess_data(profile_opening_angle, profile_steps)
    
    # Load scalers (must exist from training)
    x_scaler, y_scaler = load_scalers_from_training()
    
    # Preprocess data using training scalers
    data_loader, _, _ = preprocess_data(sonar, profiles, x_scaler, y_scaler)
    
    # Build model with same architecture as training
    input_shape = (2, 200)  # (channels, time_samples)
    output_shape = profile_steps  # azimuth bins
    
    # Determine which model architecture to use based on training parameters
    if training_params.get('use_residual_connections', False) and training_params.get('use_simple_attention', False):
        # This is the optimized model architecture
        model = SonarToProfileCNNOptimized(input_shape, output_shape, training_params).to(device)
        model_type = "Optimized"
    elif training_params.get('attention_heads', 0) > 0:
        # This is the enhanced model architecture
        model = SonarToProfileCNNEnhanced(input_shape, output_shape, training_params).to(device)
        model_type = "Enhanced"
    else:
        # This is the original model architecture
        model = SonarToProfileCNN(input_shape, output_shape, training_params).to(device)
        model_type = "Original"
    
    print(f"🏗️ {model_type} Model architecture:")
    print(f"   Input shape: {input_shape}")
    print(f"   Output shape: {output_shape}")
    print(f"   Total parameters: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")
    
    # Load trained model
    model_path = f'{output_dir}/best_model_pytorch.pth'
    if os.path.exists(model_path):
        model.load_state_dict(torch.load(model_path))
        print(f"✅ Loaded trained model from: {model_path}")
    else:
        raise FileNotFoundError(f"Trained model not found at: {model_path}")
    
    # Make predictions
    predictions, targets = predict_profiles(model, data_loader, y_scaler)
    
    print("✅ Prediction complete!")
    print(f"📊 Predictions shape: {predictions.shape}")
    print(f"📊 Targets shape: {targets.shape}")
    
    # Calculate performance metrics
    mse = np.mean((predictions - targets) ** 2)
    mae = np.mean(np.abs(predictions - targets))
    rmse = np.sqrt(mse)
    
    # R-squared score
    ss_total = np.sum((targets - np.mean(targets, axis=0)) ** 2)
    ss_res = np.sum((targets - predictions) ** 2)
    r2 = 1 - (ss_res / ss_total)
    
    print(f"📊 Performance Metrics:")
    print(f"   MSE: {mse:.4f}")
    print(f"   RMSE: {rmse:.4f}")
    print(f"   MAE: {mae:.4f}")
    print(f"   R²: {np.mean(r2):.4f}")
    
    # Plot selected indices if requested
    if plot_indices is not None:
        print(f"📊 Plotting profiles for indices: {plot_indices}")
        
        # Load robot positions for plotting
        dc = DataProcessor.DataProcessor(session_to_predict)
        rob_x = dc.rob_x
        rob_y = dc.rob_y
        rob_yaw_deg = dc.rob_yaw_deg
        
        # Generate azimuth angles for the profile
        az_min = -0.5 * profile_opening_angle
        az_max = 0.5 * profile_opening_angle
        profile_azimuths = np.linspace(az_min, az_max, profile_steps)
        
        # Plot all requested indices on a single comprehensive plot
        if isinstance(plot_indices, list) and len(plot_indices) == 2:
            start_idx, end_idx = plot_indices
            plot_indices_range = range(start_idx, min(end_idx, len(predictions)))
            
            # Create a single plot with all selected indices
            plt.figure(figsize=(16, 12))
            
            # Plot each profile in the selected range
            for idx in plot_indices_range:
                # Transform profiles to world coordinates
                pred_x, pred_y = transform_profiles_to_world(
                    predictions[idx], profile_azimuths, rob_x[idx], rob_y[idx], rob_yaw_deg[idx]
                )
                real_x, real_y = transform_profiles_to_world(
                    targets[idx], profile_azimuths, rob_x[idx], rob_y[idx], rob_yaw_deg[idx]
                )
                
                # Plot robot position for this index
                plt.scatter(rob_x[idx], rob_y[idx], color='black', s=100, label=f'Robot {idx}' if idx == start_idx else '')
                
                # Plot orientation arrow
                dx = 100 * np.cos(np.deg2rad(rob_yaw_deg[idx]))
                dy = 100 * np.sin(np.deg2rad(rob_yaw_deg[idx]))
                plt.arrow(rob_x[idx], rob_y[idx], dx, dy, color='red', width=5, 
                         length_includes_head=True, head_width=20)
                
                # Plot predicted and real profiles
                plt.plot(pred_x, pred_y, 'g-', linewidth=2, alpha=0.7, label='Predicted' if idx == start_idx else '')
                plt.plot(real_x, real_y, 'b--', linewidth=2, alpha=0.7, label='Real' if idx == start_idx else '')
                
                # Add markers for profile points
                plt.scatter(pred_x, pred_y, color='green', s=40, alpha=0.5)
                plt.scatter(real_x, real_y, color='blue', s=40, alpha=0.5)
                
                # Add index label near robot position
                plt.text(rob_x[idx], rob_y[idx], f'{idx}', 
                         fontsize=12, ha='right', va='bottom', bbox=dict(facecolor='white', alpha=0.7))
            
            plt.title(f'{model_type} Model: Predicted vs Real Profiles for Indices {start_idx} to {end_idx-1}', fontsize=16)
            plt.xlabel('X (mm)', fontsize=14)
            plt.ylabel('Y (mm)', fontsize=14)
            plt.axis('equal')
            plt.grid(True, alpha=0.3)
            
            # Add legend (only show one entry for each type)
            handles, labels = plt.gca().get_legend_handles_labels()
            unique_labels = dict(zip(labels, handles))
            plt.legend(unique_labels.values(), unique_labels.keys(), fontsize=12)
            
            plt.tight_layout()
            plt.show()
        else:
            print(f"⚠️  Invalid plot_indices format. Expected [start, end], got {plot_indices}")
            print("   Example: plot_indices = [0, 5]  # Plot indices 0 through 4")
    
    return predictions, targets

if __name__ == "__main__":
    predictions, targets = main()