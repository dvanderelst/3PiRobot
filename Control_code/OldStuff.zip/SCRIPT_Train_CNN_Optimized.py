#!/usr/bin/env python3
"""
Optimized CNN Training Script

This script combines:
- Bounding box cropping (removes black borders)
- Right-sized model (smaller for cropped images)
- Balanced regularization
- Efficient training

Perfect for the cropped conical views!
"""

import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, BatchNormalization, Input
from tensorflow.keras.regularizers import l2
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from scipy.stats import pearsonr, spearmanr

# Import local modules
from Library import DataProcessor
from Library.DataProcessor import find_bounding_box_across_views

# Set random seeds
np.random.seed(42)
tf.random.set_seed(42)

def load_and_crop_data():
    """Load data and crop using bounding boxes."""
    print("📂 Loading and cropping data...")
    
    # Load data
    collection = DataProcessor.DataCollection(['session03', 'session04', 'session06'], cache_dir='cache')
    views = collection.load_views(radius_mm=4000, opening_deg=90, output_size=(256, 256))
    profiles, _ = collection.load_profiles(az_min=-45, az_max=45, az_steps=19)
    
    # Find bounding box
    print("   Finding bounding box...")
    bbox = find_bounding_box_across_views(views)
    
    if bbox:
        x_min, y_min, x_max, y_max = bbox
        print(f"   Bounding box: ({x_min}, {y_min}) to ({x_max}, {y_max})")
        
        # Crop all views
        views_cropped = views[:, y_min:y_max, x_min:x_max, :]
        print(f"   Cropped from {views.shape[1]}x{views.shape[2]} to {views_cropped.shape[1]}x{views_cropped.shape[2]}")
        views = views_cropped
    else:
        print("   No bounding box found, using full images")
    
    print(f"✅ Loaded {len(views)} samples with shape {views.shape[1:]}")
    return views, profiles

def prepare_data(views, profiles):
    """Prepare data for training."""
    print("🧹 Preparing data...")
    
    min_distances = np.min(profiles, axis=1, keepdims=True)
    
    # Normalize
    X = views.astype(np.float32) / 255.0
    scaler = StandardScaler()
    y = scaler.fit_transform(min_distances)
    
    # Split
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    
    print(f"📦 Data ready: {X_train.shape[0]} train, {X_val.shape[0]} val")
    print(f"   Input shape: {X_train.shape[1:]}")
    return X_train, X_val, y_train, y_val, scaler

def build_optimized_model(input_shape):
    """Build right-sized model for cropped images."""
    print("🏗️ Building optimized model...")
    
    # Balanced regularization for enhanced model
    l2_reg = 0.001  # Slightly stronger for larger model
    
    # Enhanced model with sufficient capacity (using modern Input layer)
    model = Sequential([
        Input(shape=input_shape),
        # Deeper architecture for better feature learning
        Conv2D(16, (3, 3), activation='relu', kernel_regularizer=l2(l2_reg)),
        BatchNormalization(),
        MaxPooling2D((2, 2)),
        Dropout(0.2),
        
        Conv2D(32, (3, 3), activation='relu', kernel_regularizer=l2(l2_reg)),
        BatchNormalization(),
        MaxPooling2D((2, 2)),
        Dropout(0.3),
        
        Conv2D(64, (3, 3), activation='relu', kernel_regularizer=l2(l2_reg)),
        BatchNormalization(),
        MaxPooling2D((2, 2)),
        Dropout(0.3),
        
        Flatten(),
        Dense(128, activation='relu', kernel_regularizer=l2(l2_reg)),
        BatchNormalization(),
        Dropout(0.4),
        
        Dense(64, activation='relu', kernel_regularizer=l2(l2_reg)),
        BatchNormalization(),
        Dropout(0.3),
        
        Dense(1, activation='linear')
    ])
    
    # Conservative learning rate to prevent overshooting
    optimizer = Adam(learning_rate=0.0005)
    model.compile(optimizer=optimizer, 
                 loss='mean_squared_error', 
                 metrics=['mean_absolute_error'])
    
    print("📋 Model summary:")
    model.summary()
    
    # Count parameters (model is already built by the Input layer)
    total_params = model.count_params()
    print(f"   Total parameters: {total_params:,}")
    if total_params < 100000:
        print("   ✅ Lightweight model (good for cropped images)")
    elif total_params < 500000:
        print("   ✅ Well-sized model (good capacity)")
    else:
        print("   ⚠️  Model might be too large for cropped input")
    
    return model

def train_model(model, X_train, y_train, X_val, y_val, epochs=25):
    """Train enhanced model with data augmentation and balanced hyperparameters."""
    print(f"🚀 Training for {epochs} epochs with batch_size=16, lr=0.0005, augmentation...")
    print("   🔄 Data augmentation: rotation, flipping, zooming")
    print("   🧠 Enhanced architecture: deeper CNN with better capacity")
    
    # Set up data augmentation
    datagen = ImageDataGenerator(
        rotation_range=10,      # ±10% rotation
        horizontal_flip=True,   # Random horizontal flipping
        zoom_range=0.1,        # ±10% zoom
        fill_mode='nearest'
    )
    
    # Custom callback to track learning rate
    class LearningRateTracker(tf.keras.callbacks.Callback):
        def on_epoch_end(self, epoch, logs=None):
            logs = logs or {}
            # Robust way to get current learning rate across TF versions
            try:
                # Try the modern way first
                lr = float(self.model.optimizer.learning_rate)
            except AttributeError:
                # Fallback for older versions
                lr = float(tf.keras.backend.get_value(self.model.optimizer.lr))
            logs['lr'] = lr
    
    callbacks = [
        EarlyStopping(monitor='val_loss', patience=8, restore_best_weights=True),
        ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=4, min_lr=1e-6),
        ModelCheckpoint('best_model_optimized.h5', monitor='val_loss', save_best_only=True),
        LearningRateTracker()
    ]
    
    # Use data augmentation for training data only
    history = model.fit(datagen.flow(X_train, y_train, batch_size=16),
                       validation_data=(X_val, y_val),
                       epochs=epochs,
                       steps_per_epoch=len(X_train) // 16,
                       callbacks=callbacks,
                       verbose=1)
    
    print("✅ Training completed!")
    
    # Debug: Check if model is learning (not predicting constant)
    final_predictions = model.predict(X_train[:10])
    print(f"🔍 Debug: Sample predictions range: {np.min(final_predictions):.1f} to {np.max(final_predictions):.1f}")
    print(f"🔍 Debug: Sample true values range: {np.min(y_train[:10]):.1f} to {np.max(y_train[:10]):.1f}")
    
    return model, history

def evaluate_optimized(model, X_val, y_val, scaler, history):
    """Evaluate with efficiency metrics."""
    print("📊 Evaluating...")
    
    y_pred = scaler.inverse_transform(model.predict(X_val))
    y_true = scaler.inverse_transform(y_val)
    
    errors = y_pred.flatten() - y_true.flatten()
    mae = np.mean(np.abs(errors))
    rmse = np.sqrt(np.mean(errors**2))
    
    # Calculate correlation metrics
    pearson_corr, pearson_p = pearsonr(y_true.flatten(), y_pred.flatten())
    spearman_corr, spearman_p = spearmanr(y_true.flatten(), y_pred.flatten())
    
    # Calculate R-squared (coefficient of determination)
    ss_res = np.sum(errors**2)
    ss_tot = np.sum((y_true.flatten() - np.mean(y_true.flatten()))**2)
    r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0
    
    print(f"📈 Performance metrics:")
    print(f"   MAE: {mae:.1f} mm")
    print(f"   RMSE: {rmse:.1f} mm")
    print(f"   R² (Coefficient of Determination): {r_squared:.3f}")
    
    print(f"\n🔗 Correlation analysis:")
    print(f"   Pearson correlation: {pearson_corr:.3f} (p={pearson_p:.3e})")
    print(f"   Spearman correlation: {spearman_corr:.3f} (p={spearman_p:.3e})")
    
    # Interpret correlation strength
    if abs(pearson_corr) > 0.9:
        correlation_strength = "🔥 Excellent"
    elif abs(pearson_corr) > 0.7:
        correlation_strength = "✅ Strong"
    elif abs(pearson_corr) > 0.5:
        correlation_strength = "⚠️  Moderate"
    else:
        correlation_strength = "❌ Weak"
    
    print(f"   Correlation strength: {correlation_strength}")
    
    # Efficiency metrics
    final_train_loss = history.history['loss'][-1]
    final_val_loss = history.history['val_loss'][-1]
    
    print(f"\n📊 Efficiency metrics:")
    print(f"   Train loss: {final_train_loss:.3f}")
    print(f"   Val loss: {final_val_loss:.3f}")
    print(f"   Loss ratio: {final_val_loss/final_train_loss:.2f}")
    
    if final_val_loss/final_train_loss < 1.2:
        print("   ✅ Excellent generalization")
    elif final_val_loss/final_train_loss < 1.5:
        print("   ✅ Good generalization")
    else:
        print("   ⚠️  Check for overfitting")
    
    # Plot results
    plt.figure(figsize=(12, 8))
    
    plt.subplot(2, 2, 1)
    plt.plot(history.history['loss'], label='Train')
    plt.plot(history.history['val_loss'], label='Val')
    plt.title('Training Efficiency')
    plt.xlabel('Epoch')
    plt.ylabel('MSE Loss')
    plt.legend()
    plt.grid(True)
    
    plt.subplot(2, 2, 2)
    plt.scatter(y_true, y_pred, alpha=0.5)
    plt.plot([min(y_true), max(y_true)], [min(y_true), max(y_true)], 'r--')
    plt.xlabel('Actual (mm)')
    plt.ylabel('Predicted (mm)')
    plt.title(f'Prediction vs Actual (R²: {r_squared:.2f}, ρ: {pearson_corr:.2f})')
    plt.grid(True)
    
    plt.subplot(2, 2, 3)
    plt.hist(errors, bins=25, alpha=0.7)
    plt.axvline(0, color='red', linestyle='--')
    plt.xlabel('Error (mm)')
    plt.ylabel('Frequency')
    plt.title('Error Distribution')
    plt.grid(True)
    
    plt.subplot(2, 2, 4)
    if 'lr' in history.history:
        plt.plot(history.history['lr'])
        plt.title('Learning Rate Adaptation')
        plt.xlabel('Epoch')
        plt.ylabel('Learning Rate')
    else:
        plt.text(0.5, 0.5, 'Learning rate data not available',
                ha='center', va='center')
        plt.title('Learning Rate Adaptation')
    plt.grid(True)
    
    # Add a new figure for detailed correlation analysis
    plt.figure(figsize=(12, 4))
    
    plt.subplot(1, 3, 1)
    plt.scatter(y_true, y_pred, alpha=0.5)
    plt.plot([min(y_true), max(y_true)], [min(y_true), max(y_true)], 'r--')
    plt.xlabel('Actual Distance (mm)')
    plt.ylabel('Predicted Distance (mm)')
    plt.title(f'Correlation Analysis\nPearson: {pearson_corr:.3f}, Spearman: {spearman_corr:.3f}')
    plt.grid(True)
    
    plt.subplot(1, 3, 2)
    residuals = y_true.flatten() - y_pred.flatten()
    plt.scatter(y_pred, residuals, alpha=0.5)
    plt.axhline(0, color='red', linestyle='--')
    plt.xlabel('Predicted Distance (mm)')
    plt.ylabel('Residuals (mm)')
    plt.title('Residual Analysis')
    plt.grid(True)
    
    plt.subplot(1, 3, 3)
    plt.hist2d(y_true.flatten(), y_pred.flatten(), bins=25, cmap='viridis')
    plt.colorbar(label='Frequency')
    plt.xlabel('Actual Distance (mm)')
    plt.ylabel('Predicted Distance (mm)')
    plt.title('Prediction Density')
    plt.grid(True)
    
    plt.tight_layout()
    
    plt.tight_layout()
    plt.show()
    
    # Print efficiency summary
    total_epochs = len(history.history['loss'])
    print(f"\n💡 Efficiency Summary:")
    print(f"   Epochs completed: {total_epochs}")
    if 'lr' in history.history:
        print(f"   Final learning rate: {history.history['lr'][-1]:.2e}")
    else:
        print(f"   Final learning rate: Not tracked")
    print(f"   Model size: {model.count_params():,} parameters")
    print(f"   Training completed successfully!")

def main():
    """Main pipeline."""
    print("🚀 Optimized CNN Training")
    print("=" * 35)
    print("Features: Bounding box cropping + Right-sized model")
    
    # Load and crop data
    views, profiles = load_and_crop_data()
    
    # Prepare data
    X_train, X_val, y_train, y_val, scaler = prepare_data(views, profiles)
    
    # Build optimized model
    model = build_optimized_model(input_shape=X_train.shape[1:])
    
    # Train
    model, history = train_model(model, X_train, y_train, X_val, y_val, epochs=10)
    
    # Evaluate
    evaluate_optimized(model, X_val, y_val, scaler, history)
    
    print("🎉 Optimized training complete!")

if __name__ == "__main__":
    main()