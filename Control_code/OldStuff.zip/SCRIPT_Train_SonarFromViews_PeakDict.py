from datetime import datetime
import os

import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from tensorflow.keras.layers import Conv2D, Dense, Flatten, Input, Lambda, MaxPooling2D, Reshape
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam

from Library import DataProcessor

FIRST_ECHO_SAMPLES = 40
EPOCHS = 100
DICT_NUM_CENTERS = 40
DICT_WIDTHS = (5, 10, 20)


def load_data():
    sessions = ["session03", "session04", "session06", "session07"]
    dc = DataProcessor.DataCollection(sessions)
    views = dc.load_views(radius_mm=4000, opening_deg=180, output_size=(256, 256), show_example=False)
    sonar_raw = dc.load_sonar(flatten=False, thresholded=False)
    sonar_thresholded = dc.load_sonar(flatten=False, thresholded=True)

    bbox = DataProcessor.find_bounding_box_across_views(views)
    if bbox is not None:
        x_min, y_min, x_max, y_max = bbox
        views = views[:, y_min:y_max, x_min:x_max, :]

    if len(views) != len(sonar_raw) or len(views) != len(sonar_thresholded):
        n = min(len(views), len(sonar_raw), len(sonar_thresholded))
        print(
            "Warning: view/sonar count mismatch "
            f"({len(views)} vs {len(sonar_raw)} vs {len(sonar_thresholded)}), truncating to {n}"
        )
        views = views[:n]
        sonar_raw = sonar_raw[:n]
        sonar_thresholded = sonar_thresholded[:n]

    return views, sonar_raw, sonar_thresholded


def mask_after_first_echo(sonar_raw, sonar_thresholded, window_samples):
    n, samples, channels = sonar_raw.shape
    if sonar_thresholded.shape != sonar_raw.shape:
        raise ValueError("Raw and thresholded sonar shapes do not match.")
    masked = np.empty((n, samples, channels), dtype=np.float32)
    for i in range(n):
        trace_thresh = sonar_thresholded[i]
        trace_raw = sonar_raw[i]
        above = np.where(np.any(trace_thresh > 0, axis=1))[0]
        min_val = np.min(trace_raw)
        masked[i].fill(min_val)
        if len(above) == 0:
            masked[i] = trace_raw
            continue
        start = int(above[0])
        end = min(start + window_samples, samples)
        masked[i, :end] = trace_raw[:end]
    return masked


def build_peak_dictionary(num_samples, num_centers, widths):
    centers = np.linspace(0, num_samples - 1, num_centers)
    t = np.arange(num_samples, dtype=np.float32)
    basis_list = []
    meta = []
    for width in widths:
        for center in centers:
            peak = np.exp(-0.5 * ((t - center) / width) ** 2)
            peak = peak / np.max(peak)
            basis_list.append(peak)
            meta.append((center, width))
    basis = np.stack(basis_list, axis=1)
    return basis, meta


def prepare_data(views, sonar_raw, sonar_thresholded, window_samples):
    X = views.astype(np.float32) / 255.0
    sonar_window = mask_after_first_echo(sonar_raw, sonar_thresholded, window_samples)
    target_scale = float(np.max(sonar_window))
    if target_scale <= 0:
        target_scale = 1.0
    y = (sonar_window / target_scale).astype(np.float32)

    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    return X_train, X_val, y_train, y_val, target_scale


def build_model(input_shape, num_samples, basis):
    num_peaks = basis.shape[1]
    basis_t = tf.constant(basis.T, dtype=tf.float32)

    inputs = Input(shape=input_shape)
    x = Conv2D(16, (3, 3), activation="relu")(inputs)
    x = MaxPooling2D((2, 2))(x)
    x = Conv2D(32, (3, 3), activation="relu")(x)
    x = MaxPooling2D((2, 2))(x)
    x = Conv2D(64, (3, 3), activation="relu")(x)
    x = MaxPooling2D((2, 2))(x)
    x = Flatten()(x)
    x = Dense(256, activation="relu")(x)

    weights = Dense(2 * num_peaks, activation="softplus")(x)
    weights = Reshape((2, num_peaks))(weights)
    bias = Dense(2, activation="linear")(x)

    def mix_peaks(args):
        w, b = args
        y = tf.einsum("bck,ks->bcs", w, basis_t)
        y = y + tf.expand_dims(b, axis=-1)
        return tf.transpose(y, perm=[0, 2, 1])

    outputs = Lambda(mix_peaks)([weights, bias])

    model = Model(inputs=inputs, outputs=outputs)
    model.compile(optimizer=Adam(learning_rate=1e-3), loss="mse", metrics=["mae"])
    return model


def train_model(model, X_train, y_train, X_val, y_val):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    model_path = f"models/cnn_sonar_peakdict_{timestamp}.h5"
    callbacks = [
        EarlyStopping(monitor="val_loss", patience=6, restore_best_weights=True),
        ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=3, min_lr=1e-6),
        ModelCheckpoint(model_path, monitor="val_loss", save_best_only=True),
    ]

    history = model.fit(
        X_train,
        y_train,
        validation_data=(X_val, y_val),
        epochs=EPOCHS,
        batch_size=16,
        callbacks=callbacks,
        verbose=1,
    )
    return model, history, model_path


def evaluate(model, X_val, y_val, target_scale):
    y_pred = model.predict(X_val)
    y_pred = y_pred * target_scale
    y_true = y_val * target_scale
    errors = y_pred - y_true
    mae = np.mean(np.abs(errors))
    rmse = np.sqrt(np.mean(errors ** 2))

    print(f"Validation MAE: {mae:.1f}")
    print(f"Validation RMSE: {rmse:.1f}")
    return y_true, y_pred


def plot_diagnostics(history, y_true, y_pred, output_dir, samples_to_plot=3):
    os.makedirs(output_dir, exist_ok=True)

    plt.figure(figsize=(10, 6))
    plt.plot(history.history["loss"], label="train")
    plt.plot(history.history["val_loss"], label="val")
    plt.xlabel("Epoch")
    plt.ylabel("MSE loss")
    plt.title("Training/Validation Loss")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "loss_curve.png"), dpi=150)
    plt.show()

    num_samples = min(samples_to_plot, y_true.shape[0])
    indices = np.random.choice(y_true.shape[0], size=num_samples, replace=False)
    for i, idx in enumerate(indices):
        plt.figure(figsize=(10, 5))
        plt.plot(y_true[idx, :, 0], label="true_left", color="blue")
        plt.plot(y_pred[idx, :, 0], label="pred_left", color="blue", linestyle="--")
        plt.plot(y_true[idx, :, 1], label="true_right", color="red")
        plt.plot(y_pred[idx, :, 1], label="pred_right", color="red", linestyle="--")
        plt.xlabel("Sample index")
        plt.ylabel("Intensity (a.u.)")
        plt.title(f"Peak dictionary prediction {i + 1}")
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, f"sonar_prediction_{i + 1}.png"), dpi=150)
        plt.show()


def save_preprocessors(path, target_scale, basis, basis_meta):
    centers = np.array([m[0] for m in basis_meta], dtype=np.float32)
    widths = np.array([m[1] for m in basis_meta], dtype=np.float32)
    np.savez(
        path,
        target_scale=target_scale,
        basis=basis,
        basis_centers=centers,
        basis_widths=widths,
    )


def main():
    np.random.seed(42)
    tf.random.set_seed(42)

    views, sonar_raw, sonar_thresholded = load_data()
    X_train, X_val, y_train, y_val, target_scale = prepare_data(
        views, sonar_raw, sonar_thresholded, FIRST_ECHO_SAMPLES
    )

    num_samples = y_train.shape[1]
    basis, basis_meta = build_peak_dictionary(num_samples, DICT_NUM_CENTERS, DICT_WIDTHS)

    model = build_model(input_shape=X_train.shape[1:], num_samples=num_samples, basis=basis)
    model, history, model_path = train_model(model, X_train, y_train, X_val, y_val)

    y_true, y_pred = evaluate(model, X_val, y_val, target_scale)
    save_preprocessors(model_path.replace(".h5", "_preprocess.npz"), target_scale, basis, basis_meta)

    output_dir = os.path.join("Plots", f"sonar_peakdict_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    plot_diagnostics(history, y_true, y_pred, output_dir, samples_to_plot=3)


if __name__ == "__main__":
    main()
