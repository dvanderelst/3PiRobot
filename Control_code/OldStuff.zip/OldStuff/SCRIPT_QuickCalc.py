speed = 2.5 #m/s
call_rate = 20 # per second

print('distance per call', speed / call_rate)