import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from Library import DataProcessor

torch.set_num_threads(1)  # avoids MKL thread stalls on some systems
torch.set_num_interop_threads(1)  # same

# -----------------------------
# Reproducibility
# -----------------------------
seed = 123
np.random.seed(seed)
torch.manual_seed(seed)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device, flush=True)

# -----------------------------
# Load data
# -----------------------------
processor1 = DataProcessor.DataProcessor('session6')
collated1 = processor1.collate_data(az_min=-60, az_max=60, az_steps=5)

processor2 = DataProcessor.DataProcessor('session7')
collated2 = processor2.collate_data(az_min=-60, az_max=60, az_steps=5)

sonar_block1 = collated1['sonar_block']  # (N, 100, 2)
profile_data1 = collated1['profiles']  # (N, 10)

sonar_block2 = collated2['sonar_block']  # (N, 100, 2)
profile_data2 = collated2['profiles']  # (N, 10)

# -----------------------------
# Concatenate sessions then random split
# -----------------------------
X_all = np.concatenate((sonar_block1, sonar_block2), axis=0).astype(np.float32)
y_all = np.concatenate((profile_data1, profile_data2), axis=0).astype(np.float32)

flat = y_all.reshape(-1, 1)
plt.figure()
plt.hist(flat, bins=100)
plt.show()

X_train, X_val, y_train, y_val = train_test_split(
    X_all, y_all, test_size=0.2, random_state=seed, shuffle=True
)

# -----------------------------
# Scale X per channel (fit on train only)
# -----------------------------
x_scaler0 = StandardScaler()
x_scaler1 = StandardScaler()
X_train[:, :, 0] = x_scaler0.fit_transform(X_train[:, :, 0])
X_val[:, :, 0] = x_scaler0.transform(X_val[:, :, 0])
X_train[:, :, 1] = x_scaler1.fit_transform(X_train[:, :, 1])
X_val[:, :, 1] = x_scaler1.transform(X_val[:, :, 1])

# -----------------------------
# Scale y (fit on train only)
# -----------------------------
y_scaler = MinMaxScaler((-1, 1))
y_train = y_scaler.fit_transform(y_train)
y_val = y_scaler.transform(y_val)


# -----------------------------
# Torch dataset
# -----------------------------
class SonarDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.from_numpy(X)  # (N, 100, 2)
        self.y = torch.from_numpy(y)  # (N, 10)

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        # Conv1d expects (C, L) per sample → transpose (100,2) -> (2,100)
        x = self.X[idx].transpose(0, 1)  # (2, 100)
        return x, self.y[idx]


train_ds = SonarDataset(X_train, y_train)
val_ds = SonarDataset(X_val, y_val)

train_loader = DataLoader(train_ds, batch_size=32, shuffle=True, drop_last=False)
val_loader = DataLoader(val_ds, batch_size=128, shuffle=False, drop_last=False)

# -----------------------------
# 1D CNN model with residual blocks
# -----------------------------
class ResidualBlock(nn.Module):
    def __init__(self, channels, kernel_size=5, drop_p=0.1):
        super().__init__()
        pad = kernel_size // 2
        self.block = nn.Sequential(
            nn.Conv1d(channels, channels, kernel_size=kernel_size, padding=pad),
            nn.BatchNorm1d(channels),
            nn.ReLU(),
            nn.Conv1d(channels, channels, kernel_size=kernel_size, padding=pad),
            nn.BatchNorm1d(channels),
            nn.Dropout(drop_p),
        )
        self.act = nn.ReLU()

    def forward(self, x):
        return self.act(x + self.block(x))


class SonarCNN(nn.Module):
    def __init__(self, out_dim=10, bottleneck=32, drop_p=0.2):
        super().__init__()
        # Multi-scale stem: parallel kernels capture fine + coarse structure.
        self.stem_3 = nn.Conv1d(2, 16, kernel_size=3, padding=1)
        self.stem_7 = nn.Conv1d(2, 16, kernel_size=7, padding=3)
        self.stem_15 = nn.Conv1d(2, 16, kernel_size=15, padding=7)
        self.stem_bn = nn.BatchNorm1d(48)
        self.stem_act = nn.ReLU()

        self.res_blocks = nn.Sequential(
            ResidualBlock(48, kernel_size=7, drop_p=0.1),
            ResidualBlock(48, kernel_size=5, drop_p=0.1),
            ResidualBlock(48, kernel_size=5, drop_p=0.1),
        )
        self.pool = nn.Sequential(
            nn.AvgPool1d(kernel_size=2),  # length 100 -> 50
            nn.Conv1d(48, 64, kernel_size=5, padding=2),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1),  # (B, 64, 1)
        )
        self.head = nn.Sequential(
            nn.Flatten(),  # (B, 64)
            nn.Linear(64, bottleneck),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(bottleneck, out_dim)
        )

    def forward(self, x):
        # x: (B, 2, 100)
        z = torch.cat([self.stem_3(x), self.stem_7(x), self.stem_15(x)], dim=1)
        z = self.stem_act(self.stem_bn(z))
        z = self.res_blocks(z)
        z = self.pool(z)
        return self.head(z)


model = SonarCNN(out_dim=y_train.shape[1], bottleneck=64, drop_p=0.2).to(device)

criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=3e-4, weight_decay=1e-4)

# -----------------------------
# Train / eval loops
# -----------------------------
def eval_rmse(model, loader):
    model.eval()
    ys, yps = [], []
    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            yp = model(xb)
            ys.append(yb.cpu().numpy())
            yps.append(yp.cpu().numpy())
    ys = np.vstack(ys)
    yps = np.vstack(yps)
    rmse = np.sqrt(mean_squared_error(ys, yps))
    return rmse, ys, yps


def per_bin_corr(y_true, y_pred):
    corrs = []
    for j in range(y_true.shape[1]):
        yt = y_true[:, j]
        yp = y_pred[:, j]
        yt_std = yt.std()
        yp_std = yp.std()
        if yt_std < 1e-12 or yp_std < 1e-12:
            corrs.append(np.nan)
            continue
        cov = np.mean((yt - yt.mean()) * (yp - yp.mean()))
        corrs.append(cov / (yt_std * yp_std))
    return np.array(corrs, dtype=float)


epochs = 200
best_val = np.inf
best_state = None
patience = 20
pat = 0

scheduler = torch.optim.lr_scheduler.OneCycleLR(
    optimizer,
    max_lr=1e-3,
    epochs=epochs,
    steps_per_epoch=len(train_loader),
    pct_start=0.2,
)

_, y_true_pre, y_pred_pre = eval_rmse(model, val_loader)
pre_corr = per_bin_corr(y_true_pre, y_pred_pre)
print("Per-azimuth correlation before training (random init):",
      np.round(pre_corr, 3))

for ep in range(1, epochs + 1):
    model.train()
    losses = []
    for xb, yb in train_loader:
        xb = xb.to(device)
        yb = yb.to(device)

        optimizer.zero_grad()
        yp = model(xb)
        loss = criterion(yp, yb)
        loss.backward()
        optimizer.step()
        scheduler.step()
        losses.append(loss.item())

    train_loss = float(np.mean(losses))
    val_rmse, _, _ = eval_rmse(model, val_loader)

    print(f"Epoch {ep:03d} | train loss {train_loss:.5f} | val RMSE {val_rmse:.5f}")

    # simple early stopping
    if val_rmse < best_val - 1e-5:
        best_val = val_rmse
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        pat = 0
    else:
        pat += 1
        if pat >= patience:
            print(f"Early stop (best val RMSE {best_val:.5f})")
            break

# Restore best model
if best_state is not None:
    model.load_state_dict(best_state)

cnn_rmse, y_true_val, y_pred_val = eval_rmse(model, val_loader)
print(f"\nCNN val RMSE: {cnn_rmse:.3f}")

# -----------------------------
# Per-azimuth correlation (val)
# -----------------------------
az_corr = per_bin_corr(y_true_val, y_pred_val)
print("Per-azimuth correlation (val):", np.round(az_corr, 3))

# -----------------------------
# Mean-profile baseline (computed on TRAIN)
# -----------------------------
mean_profile = y_train.mean(axis=0)
y_pred_mean = np.tile(mean_profile, (len(y_val), 1))
rmse_mean = np.sqrt(mean_squared_error(y_val, y_pred_mean))
print(f"Mean-profile RMSE: {rmse_mean:.3f}")

#%%
# -----------------------------
# Diagnostic plot (one validation example) in original scale
# -----------------------------
idx = np.random.randint(y_true_val.shape[0])

y_true_orig = y_scaler.inverse_transform(y_true_val)
y_pred_orig = y_scaler.inverse_transform(y_pred_val)
mean_profile_orig = y_scaler.inverse_transform(mean_profile.reshape(1, -1))[0]

plt.figure()
plt.plot(y_true_orig[idx], 'k-o', label='True (val)')
plt.plot(y_pred_orig[idx], 'r--o', label='CNN pred (val)')
plt.plot(mean_profile_orig, 'b:', label='Mean (train)')
plt.xlabel('Azimuth bin')
plt.ylabel('Distance (original scale)')
plt.title(f'Validation example {idx}')
plt.legend()
plt.ylim(0, 3000)
plt.tight_layout()
plt.show()
#%%
# -----------------------------
# Correlation plot (per azimuth)
# -----------------------------
plt.figure()
plt.plot(np.arange(len(az_corr)), az_corr, 'g-o')
plt.ylim(0, 1.0)
plt.xlabel('Azimuth bin')
plt.ylabel('Pearson r (val)')
plt.title('Per-azimuth correlation')
plt.tight_layout()
plt.show()

#%%
n_bins = y_true_orig.shape[1]
plt.figure()
for i in range(n_bins):
    plt.subplot(2, 3, i + 1)
    plt.scatter(y_true_orig[:,i], y_pred_orig[:, i])
plt.tight_layout()
plt.show()

#%%
plt.figure()
for i in range(n_bins):
    plt.subplot(2, 3, i + 1)
    errors = y_pred_orig[:, i] - y_true_orig[:, i]
    plt.hist(errors)
    plt.xlim([-1000, 1000])
plt.tight_layout()
plt.show()