import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import Dataset, DataLoader
from Library import DataProcessor
from Library import Guidance
from matplotlib import pyplot as plt

seed = 123
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
np.random.seed(seed)
torch.manual_seed(seed)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device, flush=True)

# -----------------------------
# Prepare sonar + yaw_error data
# -----------------------------
processor1 = DataProcessor.DataProcessor('session6')
processor2 = DataProcessor.DataProcessor('session7')
collated1 = processor1.collate_data(az_min=-45, az_max=45, az_steps=10)
collated2 = processor2.collate_data(az_min=-45, az_max=45, az_steps=10)

sonar_block1 = collated1["sonar_block"]  # (N, 100, 2)
sonar_block2 = collated2["sonar_block"]  # (N, 100, 2)

polyline = Guidance.build_polyline_from_xy(processor1.path_x, processor1.path_y, plot=False)
d0 = 50

df1 = Guidance.guidance_vector_field_batch(
    collated1["x_positions"],
    collated1["y_positions"],
    collated1["yaw_positions"],
    polyline,
    d0,
    visualize=False,
)
df2 = Guidance.guidance_vector_field_batch(
    collated2["x_positions"],
    collated2["y_positions"],
    collated2["yaw_positions"],
    polyline,
    d0,
    visualize=False,
)

yaw_err1 = df1["yaw_err_deg"].to_numpy(dtype=np.float32)
yaw_err2 = df2["yaw_err_deg"].to_numpy(dtype=np.float32)





n_prev = 5  # number of previous sonar frames to include (window uses n_prev + current)


def build_sequence_features(sonar_block, yaw_err_deg, n_prev):
    n = sonar_block.shape[0]
    if n <= n_prev:
        raise ValueError("Not enough samples to build sequences")
    X_seq = []
    y_seq = []
    for i in range(n_prev, n):
        window = sonar_block[i - n_prev:i + 1]  # (n_prev+1, 100, 2)
        window = np.transpose(window, (1, 2, 0))  # (100, 2, n_prev+1)
        window = window.reshape(100, 2 * (n_prev + 1))  # (100, 2*(n_prev+1))
        X_seq.append(window)
        y_seq.append(yaw_err_deg[i])
    X_seq = np.array(X_seq, dtype=np.float32)
    y_seq = np.array(y_seq, dtype=np.float32)
    yaw_err_rad = np.deg2rad(y_seq)
    y_enc = np.column_stack([np.sin(yaw_err_rad), np.cos(yaw_err_rad)]).astype(np.float32)
    return X_seq, y_enc


X_seq1, y_seq1 = build_sequence_features(sonar_block1, yaw_err1, n_prev)
X_seq2, y_seq2 = build_sequence_features(sonar_block2, yaw_err2, n_prev)

X_all = np.concatenate((X_seq1, X_seq2), axis=0).astype(np.float32)
y_all = np.concatenate((y_seq1, y_seq2), axis=0).astype(np.float32)

# plt.figure()
# plt.hist(y_all)
# plt.show()

X_train, X_val, y_train, y_val = train_test_split(
    X_all, y_all, test_size=0.2, random_state=seed, shuffle=True
)

flat_train = X_train.reshape(-1, X_train.shape[2])
x_mean = flat_train.mean(axis=0, keepdims=True)
x_std = flat_train.std(axis=0, keepdims=True) + 1e-8
X_train = (X_train - x_mean) / x_std
X_val = (X_val - x_mean) / x_std

class SonarYawDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.from_numpy(X)
        self.y = torch.from_numpy(y)

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        x = self.X[idx].transpose(0, 1)  # (2*(n_prev+1), 100)
        return x, self.y[idx]


train_ds = SonarYawDataset(X_train, y_train)
val_ds = SonarYawDataset(X_val, y_val)

train_loader = DataLoader(train_ds, batch_size=32, shuffle=True, drop_last=False)
val_loader = DataLoader(val_ds, batch_size=128, shuffle=False, drop_last=False)


class YawCNN(nn.Module):
    def __init__(self, in_channels, drop_p=0.2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(in_channels, 32, kernel_size=5, padding=2),
            nn.ReLU(),
            nn.Conv1d(32, 64, kernel_size=5, padding=2),
            nn.ReLU(),
            nn.Conv1d(64, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1),
            nn.Flatten(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(64, 2),
        )

    def forward(self, x):
        return self.net(x)


model = YawCNN(in_channels=2 * (n_prev + 1), drop_p=0.2).to(device)
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=3e-4, weight_decay=1e-4)


def eval_metrics(model, loader):
    model.eval()
    ys, yps = [], []
    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            yp = model(xb)
            yp_norm = yp / (yp.norm(dim=1, keepdim=True) + 1e-8)
            ys.append(yb.cpu().numpy())
            yps.append(yp_norm.cpu().numpy())
    ys = np.vstack(ys)
    yps = np.vstack(yps)
    cos_loss = float(1.0 - np.mean(np.sum(ys * yps, axis=1)))
    ang_true = np.arctan2(ys[:, 0], ys[:, 1])
    ang_pred = np.arctan2(yps[:, 0], yps[:, 1])
    diff = (ang_pred - ang_true + np.pi) % (2 * np.pi) - np.pi
    ang_mae_deg = float(np.mean(np.abs(np.rad2deg(diff))))
    return cos_loss, ang_mae_deg, ys, yps


epochs = 250
best_val = np.inf
best_state = None
patience = 25
pat = 0
for ep in range(1, epochs + 1):
    model.train()
    losses = []
    for xb, yb in train_loader:
        xb = xb.to(device)
        yb = yb.to(device)
        optimizer.zero_grad()
        yp = model(xb)
        yp_norm = yp / (yp.norm(dim=1, keepdim=True) + 1e-8)
        loss = 1.0 - torch.mean(torch.sum(yp_norm * yb, dim=1))
        loss.backward()
        optimizer.step()
        losses.append(loss.item())

    train_loss = float(np.mean(losses))
    val_cos, val_ang_mae, _, _ = eval_metrics(model, val_loader)
    print(
        f"Epoch {ep:03d} | train loss {train_loss:.5f} | "
        f"val cos loss {val_cos:.5f} | val ang MAE {val_ang_mae:.2f} deg"
    )

    if val_cos < best_val - 1e-5:
        best_val = val_cos
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        pat = 0
    else:
        pat += 1
        if pat >= patience:
            print(f"Early stop (best val cos loss {best_val:.5f})")
            break

if best_state is not None:
    model.load_state_dict(best_state)

# -----------------------------
# Diagnostics: scatter plot
# -----------------------------
y_cos, y_ang_mae, y_true_val, y_pred_val = eval_metrics(model, val_loader)

y_true_angle = np.rad2deg(np.arctan2(y_true_val[:, 0], y_true_val[:, 1]))
y_pred_angle = np.rad2deg(np.arctan2(y_pred_val[:, 0], y_pred_val[:, 1]))

plt.figure()
plt.scatter(y_true_angle, y_pred_angle, s=8, alpha=0.5)
lims = [
    min(y_true_angle.min(), y_pred_angle.min()),
    max(y_true_angle.max(), y_pred_angle.max()),
]
plt.plot(lims, lims, "k--", linewidth=1)
plt.xlabel("Yaw error true (deg)")
plt.ylabel("Yaw error predicted (deg)")
plt.title("Yaw error prediction scatter (val)")
plt.tight_layout()
plt.show()
