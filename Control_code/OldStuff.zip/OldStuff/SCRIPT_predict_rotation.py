#%%
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import Dataset, DataLoader
from Library import DataProcessor

torch.set_num_threads(1)
torch.set_num_interop_threads(1)

seed = 123
np.random.seed(seed)
torch.manual_seed(seed)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device, flush=True)

# -----------------------------
# Load data
# -----------------------------
processor1 = DataProcessor.DataProcessor("session6")
processor2 = DataProcessor.DataProcessor("session7")

collated1 = processor1.collate_data(az_min=-45, az_max=45, az_steps=10)
collated2 = processor2.collate_data(az_min=-45, az_max=45, az_steps=10)

sonar_block1 = collated1["sonar_block"]  # (N, 100, 2)
sonar_block2 = collated2["sonar_block"]  # (N, 100, 2)

_, rotations1 = processor1.get_motion()
_, rotations2 = processor2.get_motion()
rotations1 = np.asarray(rotations1, dtype=np.float32)
rotations2 = np.asarray(rotations2, dtype=np.float32)

iids1 = processor1.get_field('sonar_package', 'corrected_iid')
iids2 = processor2.get_field('sonar_package', 'corrected_iid')


X_all = np.concatenate((sonar_block1, sonar_block2), axis=0).astype(np.float32)
y_all = np.concatenate((rotations1, rotations2), axis=0).astype(np.float32).reshape(-1, 1)

# -----------------------------
# Train/val split
# -----------------------------
X_train, X_val, y_train, y_val = train_test_split(
    X_all, y_all, test_size=0.2, random_state=seed, shuffle=True
)

# -----------------------------
# Standardize channels using train stats
# -----------------------------
flat_train = X_train.reshape(-1, X_train.shape[-1])
x_mean = flat_train.mean(axis=0, keepdims=True)
x_std = flat_train.std(axis=0, keepdims=True) + 1e-8
X_train = (X_train - x_mean) / x_std
X_val = (X_val - x_mean) / x_std

# -----------------------------
# Scale target rotations
# -----------------------------
y_scaler = StandardScaler()
y_train = y_scaler.fit_transform(y_train)
y_val = y_scaler.transform(y_val)


class SonarRotationDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.from_numpy(X)
        self.y = torch.from_numpy(y)

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        x = self.X[idx].transpose(0, 1)  # (2, 100)
        return x, self.y[idx]


train_ds = SonarRotationDataset(X_train, y_train)
val_ds = SonarRotationDataset(X_val, y_val)

train_loader = DataLoader(train_ds, batch_size=32, shuffle=True, drop_last=False)
val_loader = DataLoader(val_ds, batch_size=128, shuffle=False, drop_last=False)


class RotationCNN(nn.Module):
    def __init__(self, drop_p=0.2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(2, 32, kernel_size=5, padding=2),
            nn.ReLU(),
            nn.Conv1d(32, 64, kernel_size=5, padding=2),
            nn.ReLU(),
            nn.Conv1d(64, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1),
            nn.Flatten(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(64, 1),
        )

    def forward(self, x):
        return self.net(x)


model = RotationCNN(drop_p=0.2).to(device)
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=3e-4, weight_decay=1e-4)


def eval_rmse(model, loader):
    model.eval()
    ys, yps = [], []
    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            yp = model(xb)
            ys.append(yb.cpu().numpy())
            yps.append(yp.cpu().numpy())
    ys = np.vstack(ys)
    yps = np.vstack(yps)
    rmse = float(np.sqrt(np.mean((ys - yps) ** 2)))
    return rmse, ys, yps


epochs = 100
best_val = np.inf
best_state = None
patience = 15
pat = 0

for ep in range(1, epochs + 1):
    model.train()
    losses = []
    for xb, yb in train_loader:
        xb = xb.to(device)
        yb = yb.to(device)
        optimizer.zero_grad()
        yp = model(xb)
        loss = criterion(yp, yb)
        loss.backward()
        optimizer.step()
        losses.append(loss.item())

    train_loss = float(np.mean(losses))
    val_rmse, _, _ = eval_rmse(model, val_loader)
    print(f"Epoch {ep:03d} | train loss {train_loss:.5f} | val RMSE {val_rmse:.5f}")

    if val_rmse < best_val - 1e-5:
        best_val = val_rmse
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        pat = 0
    else:
        pat += 1
        if pat >= patience:
            print(f"Early stop (best val RMSE {best_val:.5f})")
            break

if best_state is not None:
    model.load_state_dict(best_state)

# -----------------------------
# Diagnostics
# -----------------------------
val_rmse, y_true_val, y_pred_val = eval_rmse(model, val_loader)
print(f"Final val RMSE (scaled): {val_rmse:.5f}")

# Back to original units
y_true_orig = y_scaler.inverse_transform(y_true_val).ravel()
y_pred_orig = y_scaler.inverse_transform(y_pred_val).ravel()

plt.figure()
plt.scatter(y_true_orig, y_pred_orig, s=8, alpha=0.5)
lims = [
    min(y_true_orig.min(), y_pred_orig.min()),
    max(y_true_orig.max(), y_pred_orig.max()),
]
plt.plot(lims, lims, "k--", linewidth=1)
plt.xlabel("Rotation true")
plt.ylabel("Rotation predicted")
plt.title("Rotation prediction scatter (val)")
plt.tight_layout()
plt.show()
