import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from matplotlib import pyplot as plt
from Library import DataProcessor
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_squared_error

processor = DataProcessor.DataProcessor('session6')
collated = processor.collate_data()

sonar_data = collated['sonar']
profile_data = collated['profiles']

print('Sonar data', sonar_data.shape)
print('Profile data', profile_data.shape)


#%%
X = sonar_data
y = profile_data.astype(float)
y = y / np.nanmax(y)

X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=0)

scaler = StandardScaler()
X_train_z = scaler.fit_transform(X_train)
X_val_z   = scaler.transform(X_val)

pca = PCA(n_components=10)
X_train_pca = pca.fit_transform(X_train_z)
X_val_pca   = pca.transform(X_val_z)

ridge = Ridge(alpha=1.0)
ridge.fit(X_train_pca, y_train)

y_pred = ridge.predict(X_val_pca)
rmse = np.sqrt(mean_squared_error(y_val, y_pred))
print(f"PCA(10)+Ridge RMSE: {rmse:.3f}")

mean_profile = y_train.mean(axis=0)
y_pred_mean = np.tile(mean_profile, (len(y_val), 1))
rmse_mean = np.sqrt(((y_val - y_pred_mean) ** 2).mean())
print(f"Mean-profile RMSE: {rmse_mean:.3f}")

selected = 10
plt.figure()
plt.plot(y_val[selected, :], label="True (val)")
plt.plot(y_pred[selected, :], label="Pred (val)")
plt.legend()
plt.show()