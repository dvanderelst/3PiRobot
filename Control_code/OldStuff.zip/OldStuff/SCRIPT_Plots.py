from Library import DataProcessor
from Library import Guidance
from matplotlib import pyplot as plt

processor1 = DataProcessor.DataProcessor('session6')
processor2 = DataProcessor.DataProcessor('session7')

processor1.print_data_overview()

d = 250
field1 = Guidance.get_guidance_field(processor1, plots=True, d=d)
field2 = Guidance.get_guidance_field(processor2, plots=True, d=d)

_, rotations1 = processor1.get_motion()
_, rotations2 = processor2.get_motion()

iids1 = processor1.get_field('sonar_package', 'corrected_iid')
iids2 = processor2.get_field('sonar_package', 'corrected_iid')

#%%
x = processor1.get_sonar_data_at(20)
plt.figure()
plt.plot(x[0:100])
plt.plot(x[100:])
plt.show()

plt.figure()
plt.scatter(iids1, rotations1, color='red')
plt.scatter(iids2, rotations2, color='blue')
plt.show()
