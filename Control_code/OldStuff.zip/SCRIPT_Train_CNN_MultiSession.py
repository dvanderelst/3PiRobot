#!/usr/bin/env python3
"""
Multi-Session CNN Training Script for Distance Prediction

This script trains a CNN using data from multiple sessions (03, 04, 06, 07)
for improved generalization and performance.

Key Features:
- Uses DataCollection for efficient multi-session data loading
- Leverages cached data for fast iteration
- Includes comprehensive evaluation and visualization
"""

import numpy as np
import os
import matplotlib.pyplot as plt
from datetime import datetime
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, BatchNormalization
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Import local modules
from Library import DataProcessor

# Set random seeds for reproducibility
np.random.seed(42)
tf.random.set_seed(42)

def load_multi_session_data(sessions=['session03', 'session04', 'session06', 'session07'], 
                          cache_dir='cache', force_recompute=False):
    """
    Load data from multiple sessions using DataCollection.
    
    Args:
        sessions: List of session names to load
        cache_dir: Directory for caching
        force_recompute: If True, recompute all data
        
    Returns:
        views, profiles, sonar data from all sessions
    """
    print(f"📂 Loading data from {len(sessions)} sessions: {', '.join(sessions)}...")
    
    # Create DataCollection
    collection = DataProcessor.DataCollection(
        sessions, 
        cache_dir=cache_dir, 
        force_recompute=force_recompute
    )
    
    # Load all data
    print("🎯 Loading conical views...")
    views = collection.load_views(radius_mm=2500, opening_deg=90, output_size=(512, 512), 
                                  force_recompute=force_recompute)
    
    print("📊 Loading distance profiles...")
    profiles, centers = collection.load_profiles(az_min=-45, az_max=45, az_steps=19, 
                                               force_recompute=force_recompute)
    
    print("📡 Loading sonar data...")
    sonar = collection.load_sonar(flatten=False, force_recompute=force_recompute)
    
    print(f"✅ Loaded data from all sessions:")
    print(f"   Total samples: {len(views)}")
    print(f"   Views shape: {views.shape}")
    print(f"   Profiles shape: {profiles.shape}")
    print(f"   Sonar shape: {sonar.shape}")
    
    return views, profiles, centers, sonar

def prepare_data(views, profiles):
    """
    Prepare data for training.
    
    Args:
        views: Conical view images from all sessions
        profiles: Distance profiles from all sessions
        
    Returns:
        X_train, X_val, y_train, y_val: Split and normalized data
    """
    print("🧹 Preparing data...")
    
    # Calculate minimum distances (target variable)
    min_distances = np.min(profiles, axis=1, keepdims=True)  # Shape: (N, 1)
    
    print(f"📊 Target statistics:")
    print(f"   Min distance range: {np.min(min_distances):.1f} - {np.max(min_distances):.1f} mm")
    print(f"   Mean min distance: {np.mean(min_distances):.1f} mm")
    print(f"   Std min distance: {np.std(min_distances):.1f} mm")
    
    # Normalize input images to [0, 1] range
    X = views.astype(np.float32) / 255.0
    
    # Normalize target values (standard scaling)
    scaler = StandardScaler()
    y = scaler.fit_transform(min_distances)
    
    # Split data into training and validation sets
    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.2, random_state=42, shuffle=True
    )
    
    print(f"📦 Data split:")
    print(f"   Training: {X_train.shape[0]} samples")
    print(f"   Validation: {X_val.shape[0]} samples")
    
    return X_train, X_val, y_train, y_val, scaler

def build_cnn_model(input_shape=(512, 512, 3)):
    """
    Build CNN model for distance prediction.
    
    Architecture optimized for multi-session data.
    """
    print("🏗️ Building CNN model...")
    
    model = Sequential([
        # Input layer
        Conv2D(32, (3, 3), activation='relu', input_shape=input_shape),
        BatchNormalization(),
        MaxPooling2D((2, 2)),
        Dropout(0.2),
        
        # Second convolutional layer
        Conv2D(64, (3, 3), activation='relu'),
        BatchNormalization(),
        MaxPooling2D((2, 2)),
        Dropout(0.3),
        
        # Third convolutional layer
        Conv2D(128, (3, 3), activation='relu'),
        BatchNormalization(),
        MaxPooling2D((2, 2)),
        Dropout(0.4),
        
        # Fourth convolutional layer
        Conv2D(256, (3, 3), activation='relu'),
        BatchNormalization(),
        MaxPooling2D((2, 2)),
        Dropout(0.5),
        
        # Flatten and dense layers
        Flatten(),
        Dense(512, activation='relu'),
        BatchNormalization(),
        Dropout(0.5),
        
        # Output layer (single value regression)
        Dense(1, activation='linear')
    ])
    
    # Compile model with lower learning rate for stability
    optimizer = Adam(learning_rate=0.0005)
    model.compile(
        optimizer=optimizer,
        loss='mean_squared_error',
        metrics=['mean_absolute_error', 'mean_squared_error']
    )
    
    print("📋 Model summary:")
    model.summary()
    
    return model

def train_model(model, X_train, y_train, X_val, y_val, epochs=100, batch_size=8):
    """
    Train the CNN model with callbacks.
    
    Uses enhanced callbacks for multi-session training.
    """
    print("🚀 Starting training...")
    
    # Create callbacks
    callbacks = [
        EarlyStopping(
            monitor='val_loss', 
            patience=20, 
            restore_best_weights=True,
            verbose=1
        ),
        ReduceLROnPlateau(
            monitor='val_loss', 
            factor=0.5, 
            patience=8, 
            min_lr=1e-7,
            verbose=1
        ),
        ModelCheckpoint(
            'best_model_multisession.h5', 
            monitor='val_loss', 
            save_best_only=True,
            save_weights_only=False,
            verbose=1
        )
    ]
    
    # Train the model
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=epochs,
        batch_size=batch_size,
        callbacks=callbacks,
        verbose=1
    )
    
    print("🎉 Training completed!")
    return model, history

def evaluate_model(model, X_val, y_val, scaler, views, min_distances, session_info):
    """
    Enhanced evaluation with multi-session analysis.
    """
    print("📊 Evaluating model...")
    
    # Make predictions
    y_pred_scaled = model.predict(X_val)
    y_pred = scaler.inverse_transform(y_pred_scaled)
    y_true = scaler.inverse_transform(y_val)
    
    # Calculate metrics
    mae = np.mean(np.abs(y_pred - y_true))
    rmse = np.sqrt(np.mean((y_pred - y_true)**2))
    
    print(f"📈 Validation metrics:")
    print(f"   MAE: {mae:.1f} mm")
    print(f"   RMSE: {rmse:.1f} mm")
    print(f"   R² Score: {1 - (np.sum((y_pred - y_true)**2) / np.sum((y_true - np.mean(y_true))**2)):.3f}")
    
    # Show example predictions from different sessions
    plt.figure(figsize=(15, 12))
    
    # Get indices of some interesting predictions
    errors = np.abs(y_pred.flatten() - y_true.flatten())
    sorted_indices = np.argsort(errors)
    
    # Show 6 examples: 3 best, 3 worst
    example_indices = []
    example_indices.extend(sorted_indices[:3])  # Best predictions
    example_indices.extend(sorted_indices[-3:])  # Worst predictions
    
    for i, idx in enumerate(example_indices):
        plt.subplot(2, 3, i+1)
        plt.imshow(views[idx])
        session_id = session_info[idx] if idx < len(session_info) else 'Unknown'
        plt.title(f"Session: {session_id}\nTrue: {y_true[idx][0]:.0f}mm\nPred: {y_pred[idx][0]:.0f}mm\nErr: {errors[idx]:.0f}mm")
        plt.axis('off')
    
    plt.suptitle('Example Predictions Across Sessions (Top: Best, Bottom: Worst)', y=1.02)
    plt.tight_layout()
    plt.show()
    
    # Plot training history
    plt.figure(figsize=(12, 6))
    
    plt.subplot(1, 2, 1)
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.title('Training History - Loss')
    plt.xlabel('Epoch')
    plt.ylabel('MSE Loss')
    plt.legend()
    
    plt.subplot(1, 2, 2)
    plt.plot(history.history['mean_absolute_error'], label='Training MAE')
    plt.plot(history.history['val_mean_absolute_error'], label='Validation MAE')
    plt.title('Training History - MAE')
    plt.xlabel('Epoch')
    plt.ylabel('MAE (mm)')
    plt.legend()
    
    plt.tight_layout()
    plt.show()
    
    # Plot prediction vs actual with session coloring
    plt.figure(figsize=(12, 8))
    
    # Create session colors for visualization
    unique_sessions = np.unique(session_info)
    session_colors = plt.cm.tab10(np.linspace(0, 1, len(unique_sessions)))
    
    for i, session in enumerate(unique_sessions):
        session_mask = (session_info == session)
        plt.scatter(y_true[session_mask], y_pred[session_mask], 
                   color=session_colors[i], alpha=0.6, label=f'Session {session}')
    
    plt.plot([min(y_true), max(y_true)], [min(y_true), max(y_true)], 'r--', label='Perfect prediction')
    plt.xlabel('Actual Minimum Distance (mm)')
    plt.ylabel('Predicted Minimum Distance (mm)')
    plt.title('Actual vs Predicted Minimum Distances by Session')
    plt.legend()
    plt.grid(True)
    plt.show()

def create_session_info(views, session_sizes):
    """
    Create session labels for visualization.
    """
    session_info = []
    cumulative = 0
    
    for i, size in enumerate(session_sizes):
        session_label = f"S{i+1}"  # S1, S2, S3, etc.
        session_info.extend([session_label] * size)
        cumulative += size
    
    return np.array(session_info)

def main():
    """
    Main training pipeline for multi-session data.
    """
    print("🚀 Starting Multi-Session CNN Training for Distance Prediction")
    print("=" * 70)
    
    # Define sessions to use
    sessions = ['session03', 'session04', 'session06', 'session07']
    
    # Load data from all sessions
    views, profiles, centers, sonar = load_multi_session_data(sessions)
    
    # Create session information for visualization
    session_sizes = [250, 500, 200, 500]  # Approximate sizes, adjust if needed
    session_info = create_session_info(views, session_sizes)
    
    # Prepare data
    X_train, X_val, y_train, y_val, scaler = prepare_data(views, profiles)
    
    # Build model
    model = build_cnn_model(input_shape=X_train.shape[1:])
    
    # Train model
    model, history = train_model(model, X_train, y_train, X_val, y_val, epochs=100, batch_size=8)
    
    # Evaluate model
    evaluate_model(model, X_val, y_val, scaler, views, np.min(profiles, axis=1), session_info)
    
    # Save final model
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    model.save(f'cnn_distance_predictor_multisession_{timestamp}.h5')
    print(f"💾 Model saved as: cnn_distance_predictor_multisession_{timestamp}.h5")
    
    print("🎉 Multi-session training complete!")

if __name__ == "__main__":
    main()