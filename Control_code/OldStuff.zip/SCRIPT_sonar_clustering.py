#!/usr/bin/env python3
"""
Sonar Sequence Clustering: Find recurring sonar patterns/sequences
"""
import numpy as np
from Library import DataProcessor
from matplotlib import pyplot as plt
from scipy.stats import wasserstein_distance
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
import pandas as pd

# Load data
print("Loading data...")
sessions = ['session03']
collection = DataProcessor.DataCollection(sessions, az_min=-45, az_max=45, az_steps=121)
sonar_data = collection.get_field('sonar_data')
rob_x = collection.get_field('rob_x')
rob_y = collection.get_field('rob_y')
rob_yaw_deg = collection.get_field('rob_yaw_deg')

print(f"Data: {sonar_data.shape[0]} samples, {sonar_data.shape[1]} features")

def split_sonar_channels(sonar_data):
    """Split concatenated left+right sonar data"""
    half_point = sonar_data.shape[1] // 2
    return sonar_data[:, :half_point], sonar_data[:, half_point:]

def extract_sequence_features(sonar_data, window_size=5):
    """Extract features from sequences of sonar measurements"""
    n_samples = sonar_data.shape[0]
    left_chan, right_chan = split_sonar_channels(sonar_data)
    
    features_list = []
    
    for i in range(0, n_samples - window_size + 1):
        window_left = left_chan[i:i+window_size]
        window_right = right_chan[i:i+window_size]
        
        # Feature 1: Mean profile
        mean_left = window_left.mean(axis=0)
        mean_right = window_right.mean(axis=0)
        
        # Feature 2: Variability
        std_left = window_left.std(axis=0)
        std_right = window_right.std(axis=0)
        
        # Feature 3: Temporal changes (differences)
        diff_left = np.diff(window_left, axis=0).mean(axis=0)
        diff_right = np.diff(window_right, axis=0).mean(axis=0)
        
        # Feature 4: Energy
        energy_left = (window_left**2).sum(axis=0)
        energy_right = (window_right**2).sum(axis=0)
        
        # Combine all features
        sequence_features = np.concatenate([
            mean_left, std_left, diff_left, energy_left,
            mean_right, std_right, diff_right, energy_right
        ])
        
        features_list.append(sequence_features)
    
    return np.array(features_list)

# Extract sequence features
window_sizes = [3, 5, 10]  # Test different sequence lengths
all_results = {}

for window_size in window_sizes:
    print(f"\n=== Analyzing sequences of length {window_size} ===")
    
    # Extract features
    sequence_features = extract_sequence_features(sonar_data, window_size=window_size)
    print(f"Extracted {sequence_features.shape[0]} sequences with {sequence_features.shape[1]} features")
    
    # Reduce dimensionality
    pca = PCA(n_components=min(50, sequence_features.shape[1]))
    features_pca = pca.fit_transform(sequence_features)
    print(f"PCA explains {pca.explained_variance_ratio_.sum():.3f} of variance")
    
    # Standardize
    scaler = StandardScaler()
    features_scaled = scaler.fit_transform(features_pca)
    
    # Try different clustering methods
    methods = {
        'kmeans': KMeans(n_clusters=min(10, len(sequence_features)//5), random_state=42),
        'agglomerative': AgglomerativeClustering(n_clusters=min(10, len(sequence_features)//5)),
        'dbscan': DBSCAN(eps=1.5, min_samples=5)
    }
    
    clustering_results = {}
    
    for method_name, clusterer in methods.items():
        print(f"  Clustering with {method_name}...")
        
        if method_name == 'dbscan':
            labels = clusterer.fit_predict(features_scaled)
            n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
        else:
            labels = clusterer.fit_predict(features_scaled)
            n_clusters = len(set(labels))
        
        # Evaluate clustering
        if n_clusters > 1:
            silhouette = silhouette_score(features_scaled, labels)
        else:
            silhouette = -1
        
        clustering_results[method_name] = {
            'labels': labels,
            'n_clusters': n_clusters,
            'silhouette': silhouette,
            'features': features_scaled
        }
        
        print(f"    Found {n_clusters} clusters, silhouette score: {silhouette:.3f}")
    
    all_results[window_size] = {
        'features': sequence_features,
        'features_pca': features_pca,
        'clustering': clustering_results,
        'window_size': window_size
    }

# Visualize results for the best window size
best_window = max(window_sizes, key=lambda ws: all_results[ws]['clustering']['kmeans']['silhouette'])
print(f"\n=== Best results with window size {best_window} ===")

results = all_results[best_window]
kmeans_results = results['clustering']['kmeans']
labels = kmeans_results['labels']
features_2d = results['features_pca'][:, :2]

# Plot clustering results
plt.figure(figsize=(15, 10))

# Plot 1: Cluster distribution in feature space
plt.subplot(2, 2, 1)
scatter = plt.scatter(features_2d[:, 0], features_2d[:, 1], c=labels, cmap='tab20', alpha=0.6)
plt.colorbar(scatter, label='Cluster')
plt.title(f'Sequence Clusters in Feature Space (window={best_window})')
plt.xlabel('PCA Component 1')
plt.ylabel('PCA Component 2')
plt.grid(True)

# Plot 2: Cluster frequency
plt.subplot(2, 2, 2)
unique, counts = np.unique(labels, return_counts=True)
plt.bar(unique, counts)
plt.xlabel('Cluster')
plt.ylabel('Frequency')
plt.title('Cluster Frequency Distribution')
plt.grid(True)

# Plot 3: Cluster occurrence along trajectory
plt.subplot(2, 1, 2)
plt.plot(labels, '.-', markersize=8)
plt.xlabel('Sequence Index')
plt.ylabel('Cluster')
plt.title('Cluster Assignment Along Trajectory')
plt.grid(True)

plt.tight_layout()
plt.show()

# Find recurring clusters (appear in multiple locations)
cluster_positions = {}
for i, label in enumerate(labels):
    if label not in cluster_positions:
        cluster_positions[label] = []
    cluster_positions[label].append(i)

# Identify clusters that recur (appear in non-consecutive sequences)
recurring_clusters = []
for cluster_id, positions in cluster_positions.items():
    if len(positions) > 1:
        # Check if positions are not all consecutive
        gaps = np.diff(positions) > 10  # At least 10 sequences apart
        if np.any(gaps):
            recurring_clusters.append((cluster_id, len(positions), positions))

print(f"\nFound {len(recurring_clusters)} recurring cluster patterns:")
for cluster_id, count, positions in sorted(recurring_clusters, key=lambda x: x[1], reverse=True)[:5]:
    print(f"  Cluster {cluster_id}: {count} occurrences at positions {positions[:5]}...")

# Visualize recurring clusters on trajectory
if recurring_clusters:
    plt.figure(figsize=(12, 6))
    
    # Plot full trajectory
    plt.plot(rob_x, rob_y, 'k-', alpha=0.2, label='Full trajectory')
    
    # Highlight recurring cluster positions
    colors = plt.cm.tab20(np.linspace(0, 1, len(recurring_clusters)))
    
    for idx, (cluster_id, count, positions) in enumerate(recurring_clusters[:5]):
        # Get the center positions of these sequences
        sequence_length = best_window
        center_indices = [pos + sequence_length//2 for pos in positions]
        
        plt.scatter(rob_x[center_indices], rob_y[center_indices], 
                   color=colors[idx], s=100, alpha=0.7, 
                   label=f'Cluster {cluster_id} ({count}×)', edgecolors='k')
    
    plt.title(f'Recurring Sonar Patterns in Space (window={best_window})')
    plt.xlabel('X position (mm)')
    plt.ylabel('Y position (mm)')
    plt.axis('equal')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.show()

print("\n=== INTERPRETATION ===")
if len(recurring_clusters) > 3:
    print("✓ Found multiple recurring sonar patterns!")
    print("  These could represent 'acoustic landmarks' or characteristic echo patterns")
    print("  The robot encounters similar sonar signatures at different locations")
else:
    print("✗ Few recurring patterns found")
    print("  Sonar sequences are mostly unique to their locations")

print(f"\nBest clustering (window={best_window}):")
print(f"  Silhouette score: {kmeans_results['silhouette']:.3f}")
print(f"  Number of clusters: {kmeans_results['n_clusters']}")
print(f"  Recurring clusters: {len(recurring_clusters)}")
