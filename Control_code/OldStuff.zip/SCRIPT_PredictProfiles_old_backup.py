#
# SCRIPT_PredictProfiles: Predict wall distance profiles using a trained CNN
#
# This script loads a trained sonar-to-profile CNN model and predicts wall distance
# profiles for sonar data from specified sessions.
#
# Usage: Set the session_to_predict variable to the session you want to analyze
#
# Input: Sonar data (N, 2, 200) from specified session
# Output: Predicted profile data (N, profile_steps)
#
# Dependencies: Requires a trained model in the Training/ directory
#

# ============================================
# CONFIGURATION SETTINGS
# ============================================

# Prediction Configuration
session_to_predict = 'sessionB05'  # Session to predict profiles for
output_dir = 'Training'            # Directory containing trained model

# Profile Parameters (loaded automatically from training)
# These parameters are loaded from training_params.json - do not set them here!
# To change profile settings, modify the training script (SCRIPT_Sonar2Profiles.py)

# Visualization Configuration
plot_indices = [100, 150]  # Set to None to disable plotting, or specify range like [0, 5]
# IMPORTS
# Note: All selected indices are plotted on a single comprehensive plot in world coordinates
# Example: plot_indices = [0, 5] plots indices 0, 1, 2, 3, and 4 together

# 2D Density Plot Configuration
create_density_plots = True  # Set to False to disable density visualizations
density_plot_gridsize = 75     # Hexbin grid resolution (higher = more detail)
density_plot_colormap = 'viridis'  # Color scheme ('viridis', 'plasma', 'inferno', 'magma', 'coolwarm')
density_plot_bins = 'log'      # Color scaling ('log' or 'linear')
density_plot_alpha = 0.8       # Transparency (0.0-1.0)

# ============================================
# IMPORTS
# ========================================================================================
# IMPORTS
# ============================================

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import StandardScaler
import os
import joblib
from matplotlib import pyplot as plt

from Library import DataProcessor
from Library import Utils
from Library.DataProcessor import robot2world

# Set device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"🔥 Using device: {device}")

class SonarToProfileCNN(nn.Module):
    """CNN model matching the training architecture."""
    def __init__(self, input_shape, output_shape, training_params=None):
        super(SonarToProfileCNN, self).__init__()
        
        # Input: (batch_size, channels=2, time_samples=200)
        # Use parameters from training if provided, otherwise use defaults
        if training_params is None:
            training_params = {
                'conv_filters': [32, 64, 128],
                'kernel_size': 5,
                'pool_size': 2,
                'dropout_rate': 0.3
            }
        
        conv_filters = training_params['conv_filters']  # number of filters in each conv layer
        kernel_size = training_params['kernel_size']    # convolution kernel size
        pool_size = training_params['pool_size']        # max pooling size
        dropout_rate = training_params['dropout_rate']   # dropout rate for regularization
        
        self.conv1 = nn.Sequential(
            nn.Conv1d(in_channels=2, out_channels=conv_filters[0], kernel_size=kernel_size),
            nn.BatchNorm1d(conv_filters[0]),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=pool_size),
            nn.Dropout(dropout_rate)
        )
        
        self.conv2 = nn.Sequential(
            nn.Conv1d(conv_filters[0], conv_filters[1], kernel_size=kernel_size),
            nn.BatchNorm1d(conv_filters[1]),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=pool_size),
            nn.Dropout(dropout_rate)
        )
        
        self.conv3 = nn.Sequential(
            nn.Conv1d(conv_filters[1], conv_filters[2], kernel_size=kernel_size),
            nn.BatchNorm1d(conv_filters[2]),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=pool_size),
            nn.Dropout(dropout_rate)
        )
        
        # Calculate the size after conv layers
        self._calculate_flattened_size(input_shape)
        
        self.fc = nn.Sequential(
            nn.Linear(self.flattened_size, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(128, output_shape)
        )
    
    def _calculate_flattened_size(self, input_shape):
        """Calculate the flattened size after convolutional layers."""
        with torch.no_grad():
            # Create a dummy input tensor
            dummy_input = torch.zeros(1, *input_shape)
            
            # Pass through conv layers
            x = self.conv1(dummy_input)
            x = self.conv2(x)
            x = self.conv3(x)
            
            # Flatten and get size
            self.flattened_size = x.view(x.size(0), -1).shape[1]
    
    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = x.view(x.size(0), -1)  # Flatten
        x = self.fc(x)
        return x

def load_training_parameters():
    """Load training parameters from saved metadata."""
    params_path = f'{output_dir}/training_params.json'
    
    if os.path.exists(params_path):
        import json
        with open(params_path, 'r') as f:
            params = json.load(f)
        print(f"✅ Loaded training parameters from: {params_path}")
        return params
    else:
        print("⚠️  Training parameters file not found. Using default values.")
        print(f"   Expected file: {params_path}")
        print("   Make sure to run training script to generate this file.")
        # Return default values that should match typical training
        return {
            'profile_opening_angle': 30,
            'profile_steps': 11,
            'conv_filters': [32, 64, 128],
            'kernel_size': 5,
            'pool_size': 2,
            'dropout_rate': 0.3
        }

def load_scalers_from_training():
    """Load scalers from training metadata."""
    x_scaler_path = f'{output_dir}/x_scaler.joblib'
    y_scaler_path = f'{output_dir}/y_scaler.joblib'
    
    if os.path.exists(x_scaler_path) and os.path.exists(y_scaler_path):
        x_scaler = joblib.load(x_scaler_path)
        y_scaler = joblib.load(y_scaler_path)
        print(f"✅ Loaded scalers from: {output_dir}")
        return x_scaler, y_scaler
    else:
        print("❌ Scaler files not found. Please run training first.")
        print(f"   Expected files: {x_scaler_path}, {y_scaler_path}")
        print(f"   Current working directory: {os.getcwd()}")
        print(f"   Make sure Training/ directory exists and contains scaler files.")
        print(f"   Run training script first: python SCRIPT_Sonar2Profiles.py")
        raise FileNotFoundError("Scaler files not found. Please train the model first.")

def load_and_preprocess_data(profile_opening_angle, profile_steps):
    """Load and preprocess sonar data for prediction."""
    print(f"📡 Loading data for session: {session_to_predict}")
    
    # Load data for the specified session
    dc = DataProcessor.DataCollection([session_to_predict])
    sonar = dc.load_sonar(flatten=False)
    profiles, _ = dc.load_profiles(opening_angle=profile_opening_angle, steps=profile_steps)
    
    print(f"📊 Sonar data shape: {sonar.shape}")
    print(f"📊 Profile data shape: {profiles.shape}")
    
    # Remove NaN values
    nan_mask = ~np.isnan(profiles).any(axis=1)
    sonar = sonar[nan_mask]
    profiles = profiles[nan_mask]
    
    print(f"📊 Clean data shapes - Sonar: {sonar.shape}, Profiles: {profiles.shape}")
    
    return sonar, profiles

def preprocess_data(sonar, profiles, x_scaler, y_scaler):
    """Preprocess data using scalers from training."""
    print("🧹 Preprocessing data...")
    
    # Normalize profile data (target)
    y_scaled = y_scaler.transform(profiles)
    
    # Normalize sonar data (input)
    # Reshape to (N*200, 2) for scaling, then reshape back
    original_shape = sonar.shape
    X_reshaped = sonar.reshape(-1, 2)
    
    X_scaled = x_scaler.transform(X_reshaped).reshape(original_shape)
    
    # Convert to PyTorch tensors and move to device
    # PyTorch expects (N, C, L) format for Conv1D
    X_tensor = torch.FloatTensor(X_scaled).permute(0, 2, 1).to(device)
    y_tensor = torch.FloatTensor(y_scaled).to(device)
    
    # Create dataset and data loader
    dataset = TensorDataset(X_tensor, y_tensor)
    data_loader = DataLoader(dataset, batch_size=32, shuffle=False)
    
    return data_loader, x_scaler, y_scaler

def predict_profiles(model, data_loader, y_scaler):
    """Make predictions using the trained model."""
    print("📊 Making predictions...")
    
    model.eval()
    
    all_predictions = []
    all_targets = []
    
    with torch.no_grad():
        for inputs, targets in data_loader:
            outputs = model(inputs)
            
            all_predictions.append(outputs.cpu().numpy())
            all_targets.append(targets.cpu().numpy())
    
    # Concatenate all batches
    y_pred_scaled = np.concatenate(all_predictions, axis=0)
    y_test_scaled = np.concatenate(all_targets, axis=0)
    
    # Inverse transform to get actual values
    y_pred = y_scaler.inverse_transform(y_pred_scaled)
    y_test_actual = y_scaler.inverse_transform(y_test_scaled)
    
    return y_pred, y_test_actual

def transform_profiles_to_world(profile_distances, profile_azimuths, rob_x, rob_y, rob_yaw_deg):
    """Transform profile distances from robot-relative to world coordinates."""
    # Profile is a 1D array where each element is the distance at a specific azimuth
    # Transform each (azimuth, distance) pair to world coordinates
    x_world, y_world = robot2world(profile_azimuths, profile_distances, rob_x, rob_y, rob_yaw_deg)
    
    return x_world, y_world



def main():
    """Main prediction pipeline."""
    print("🚀 Starting profile prediction using trained CNN")
    print(f"   Session: {session_to_predict}")
    print(f"   Model: {output_dir}/best_model_pytorch.pth")
    
    # Load training parameters to ensure consistency
    training_params = load_training_parameters()
    
    # Extract parameters from training (these are NOT configurable in prediction script)
    profile_opening_angle = training_params['profile_opening_angle']
    profile_steps = training_params['profile_steps']
    
    print(f"📊 Using training parameters:")
    print(f"   Profile opening angle: {profile_opening_angle}°")
    print(f"   Profile steps: {profile_steps}")
    
    # Load and preprocess data
    sonar, profiles = load_and_preprocess_data(profile_opening_angle, profile_steps)
    
    # Load scalers (must exist from training)
    x_scaler, y_scaler = load_scalers_from_training()
    
    # Preprocess data using training scalers
    data_loader, _, _ = preprocess_data(sonar, profiles, x_scaler, y_scaler)
    
    # Build model with same architecture as training
    input_shape = (2, 200)  # (channels, time_samples)
    output_shape = profile_steps  # azimuth bins
    
    model = SonarToProfileCNN(input_shape, output_shape, training_params).to(device)
    print(f"🏗️ Model architecture:")
    print(f"   Input shape: {input_shape}")
    print(f"   Output shape: {output_shape}")
    print(f"   Total parameters: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")
    
    # Load trained model
    model_path = f'{output_dir}/best_model_pytorch.pth'
    if os.path.exists(model_path):
        model.load_state_dict(torch.load(model_path))
        print(f"✅ Loaded trained model from: {model_path}")
    else:
        raise FileNotFoundError(f"Trained model not found at: {model_path}")
    
    # Make predictions
    predictions, targets = predict_profiles(model, data_loader, y_scaler)
    
    print("✅ Prediction complete!")
    print(f"📊 Predictions shape: {predictions.shape}")
    print(f"📊 Targets shape: {targets.shape}")
    
    # Plot selected indices if requested
    if plot_indices is not None:
        print(f"📊 Plotting profiles for indices: {plot_indices}")
        
        # Load robot positions for plotting
        dc = DataProcessor.DataProcessor(session_to_predict)
        rob_x = dc.rob_x
        rob_y = dc.rob_y
        rob_yaw_deg = dc.rob_yaw_deg
        
        # Generate azimuth angles for the profile
        az_min = -0.5 * profile_opening_angle
        az_max = 0.5 * profile_opening_angle
        profile_azimuths = np.linspace(az_min, az_max, profile_steps)
        
        # Plot all requested indices on a single comprehensive plot
        if isinstance(plot_indices, list) and len(plot_indices) == 2:
            start_idx, end_idx = plot_indices
            plot_indices_range = range(start_idx, min(end_idx, len(predictions)))
            
            # Create a single plot with all selected indices
            plt.figure(figsize=(16, 12))
            
            # Plot each profile in the selected range
            for idx in plot_indices_range:
                # Transform profiles to world coordinates
                pred_x, pred_y = transform_profiles_to_world(
                    predictions[idx], profile_azimuths, rob_x[idx], rob_y[idx], rob_yaw_deg[idx]
                )
                real_x, real_y = transform_profiles_to_world(
                    targets[idx], profile_azimuths, rob_x[idx], rob_y[idx], rob_yaw_deg[idx]
                )
                
                # Plot robot position for this index
                plt.scatter(rob_x[idx], rob_y[idx], color='black', s=100, label=f'Robot {idx}' if idx == start_idx else '')
                
                # Plot orientation arrow
                dx = 100 * np.cos(np.deg2rad(rob_yaw_deg[idx]))
                dy = 100 * np.sin(np.deg2rad(rob_yaw_deg[idx]))
                plt.arrow(rob_x[idx], rob_y[idx], dx, dy, color='red', width=5, 
                         length_includes_head=True, head_width=20)
                
                # Plot predicted and real profiles
                plt.plot(pred_x, pred_y, 'g-', linewidth=2, alpha=0.7, label='Predicted' if idx == start_idx else '')
                plt.plot(real_x, real_y, 'b--', linewidth=2, alpha=0.7, label='Real' if idx == start_idx else '')
                
                # Add markers for profile points
                plt.scatter(pred_x, pred_y, color='green', s=40, alpha=0.5)
                plt.scatter(real_x, real_y, color='blue', s=40, alpha=0.5)
                
                # Add index label near robot position
                plt.text(rob_x[idx], rob_y[idx], f'{idx}', 
                         fontsize=12, ha='right', va='bottom', bbox=dict(facecolor='white', alpha=0.7))
            
            plt.title(f'Predicted vs Real Profiles for Indices {start_idx} to {end_idx-1}', fontsize=16)
            plt.xlabel('X (mm)', fontsize=14)
            plt.ylabel('Y (mm)', fontsize=14)
            plt.axis('equal')
            plt.grid(True, alpha=0.3)
            
            # Add legend (only show one entry for each type)
            handles, labels = plt.gca().get_legend_handles_labels()
            unique_labels = dict(zip(labels, handles))
            plt.legend(unique_labels.values(), unique_labels.keys(), fontsize=12)
            
            plt.tight_layout()
            plt.show()
        else:
            print(f"⚠️  Invalid plot_indices format. Expected [start, end], got {plot_indices}")
            print("   Example: plot_indices = [0, 5]  # Plot indices 0 through 4")
    
    # Create 2D density plot of all predicted profile points
    if create_density_plots:
        print("📊 Creating 2D density plot of predicted profiles...")
        
        # Check if we have valid predictions
        if len(predictions) == 0:
            print("⚠️  No valid predictions to plot")
            return predictions, targets
        
        # Load robot positions for density plot
        dc = DataProcessor.DataProcessor(session_to_predict)
    
    # Recreate the nan mask to filter robot positions consistently
    dc.load_profiles(opening_angle=profile_opening_angle, steps=profile_steps)
    profiles_full = dc.profiles  # Get profiles from instance variable
    nan_mask = ~np.isnan(profiles_full).any(axis=1)
    
    rob_x = dc.rob_x[nan_mask]  # Use same mask as predictions
    rob_y = dc.rob_y[nan_mask]
    rob_yaw_deg = dc.rob_yaw_deg[nan_mask]
    
    # Generate azimuth angles for the profile
    az_min = -0.5 * profile_opening_angle
    az_max = 0.5 * profile_opening_angle
    profile_azimuths = np.linspace(az_min, az_max, profile_steps)
    
    # Transform all predicted profiles to world coordinates
    all_pred_x = []
    all_pred_y = []
    
    for i in range(len(predictions)):
        try:
            pred_x, pred_y = transform_profiles_to_world(
                predictions[i], profile_azimuths, rob_x[i], rob_y[i], rob_yaw_deg[i]
            )
            # Check if we got valid arrays
            if pred_x is not None and pred_y is not None and len(pred_x) > 0 and len(pred_y) > 0:
                all_pred_x.extend(pred_x)
                all_pred_y.extend(pred_y)
            else:
                print(f"⚠️  Empty or invalid profile at index {i}")
        except Exception as e:
            print(f"⚠️  Error transforming profile {i}: {e}")
    
    # Create 2D density plot
    if len(all_pred_x) == 0 or len(all_pred_y) == 0:
        print(f"⚠️  No valid prediction points to create density plot (got {len(all_pred_x)} x-coords, {len(all_pred_y)} y-coords)")
    else:
        print(f"📊 Creating density plot with {len(all_pred_x)} prediction points...")
        
        # Convert to numpy arrays and clean data
        try:
            all_pred_x_array = np.array(all_pred_x)
            all_pred_y_array = np.array(all_pred_y)
            
            # Remove NaN and Inf values
            valid_mask = np.isfinite(all_pred_x_array) & np.isfinite(all_pred_y_array)
            clean_x = all_pred_x_array[valid_mask]
            clean_y = all_pred_y_array[valid_mask]
            
            if clean_x.size == 0 or clean_y.size == 0:
                print("⚠️  No valid finite points after cleaning")
            elif clean_x.ndim == 0 or clean_y.ndim == 0:
                print("⚠️  Cleaned arrays are 0-dimensional (scalars)")
            else:
                plt.figure(figsize=(12, 10))
                
                # Create hexbin plot for density visualization
                # Note: Removed bins parameter to avoid compatibility issues
                hb = plt.hexbin(clean_x, clean_y, 
                               gridsize=density_plot_gridsize, 
                               cmap=density_plot_colormap,
                               mincnt=1,
                               alpha=density_plot_alpha)
        except Exception as e:
            print(f"⚠️  Error creating hexbin plot: {e}")
            return predictions, targets
        
        # Add colorbar with appropriate label
        bins_label = 'Log Density' if density_plot_bins == 'log' else 'Count'
        cb = plt.colorbar(hb, label=bins_label)
        
        # Plot robot positions for context
        plt.scatter(rob_x, rob_y, color='red', s=30, alpha=0.6, label='Robot Positions')
        
        plt.title(f'2D Density Plot of All Predicted Profile Points ({len(predictions)} profiles)', fontsize=16)
        plt.xlabel('X (mm)', fontsize=14)
        plt.ylabel('Y (mm)', fontsize=14)
        plt.axis('equal')
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.tight_layout()
        plt.show()
    
    # Create smoothed density plot using KDE
    print("📊 Creating smoothed density plot using KDE...")
    
    try:
        from scipy.stats import gaussian_kde
        
        # Create KDE of the predicted points (use cleaned arrays)
        xy = np.vstack([clean_x, clean_y])
        z = gaussian_kde(xy)(xy)
        
        # Sort points by density for smooth plotting
        idx = z.argsort()
        x_smooth, y_smooth, z_smooth = clean_x[idx], clean_y[idx], z[idx]
        
        plt.figure(figsize=(12, 10))
        
        # Plot KDE contours
        plt.scatter(x_smooth, y_smooth, c=z_smooth, s=5, cmap='viridis', alpha=0.5)
        
        # Add robot positions
        plt.scatter(rob_x, rob_y, color='red', s=30, alpha=0.6, label='Robot Positions')
        
        plt.title(f'Smoothed Density Plot of Predicted Profiles (KDE)', fontsize=16)
        plt.xlabel('X (mm)', fontsize=14)
        plt.ylabel('Y (mm)', fontsize=14)
        plt.axis('equal')
        plt.grid(True, alpha=0.3)
        plt.colorbar(label='Density')
        plt.legend()
        plt.tight_layout()
        plt.show()
        
    except ImportError:
        print("⚠️  scipy not available for KDE smoothing, showing hexbin only")
    except Exception as e:
        print(f"⚠️  Error creating KDE plot: {e}")
    
    return predictions, targets

if __name__ == "__main__":
    predictions, targets = main()