import numpy as np
from Library import Utils
from Library import DataProcessor
from matplotlib import pyplot as plt
import pandas as pd
from scipy.stats import wasserstein_distance
from sklearn.metrics import pairwise_distances


def split_sonar_channels(sonar_data):
    """Split concatenated left+right sonar data into separate channels"""
    n_samples = sonar_data.shape[0]
    half_point = sonar_data.shape[1] // 2
    left_channel = sonar_data[:, :half_point]
    right_channel = sonar_data[:, half_point:]
    return left_channel, right_channel


def wasserstein_profile_distance(profile1, profile2):
    """Calculate Wasserstein distance between two sonar profiles"""
    # Normalize to make them probability distributions
    p1 = profile1 / (profile1.sum() + 1e-10)
    p2 = profile2 / (profile2.sum() + 1e-10)
    
    # Create position vectors (uniform sampling)
    n = len(profile1)
    positions = np.arange(n)
    
    return wasserstein_distance(positions, positions, p1, p2)


def spatial_wasserstein_analysis(sonar_data, positions, window_size=5):
    """
    Analyze spatial information using Wasserstein distance on sliding windows
    
    Parameters:
    - sonar_data: 2D array of sonar measurements (n_samples × n_features)
    - positions: 2D array of (x,y) positions (n_samples × 2)
    - window_size: number of consecutive measurements to analyze
    
    Returns:
    - DataFrame with spatial-Wasserstein correlation analysis
    """
    n_samples = sonar_data.shape[0]
    left_chan, right_chan = split_sonar_channels(sonar_data)
    
    results = []
    
    for i in range(0, n_samples - window_size + 1):
        # Get window data
        window_left = left_chan[i:i+window_size]
        window_right = right_chan[i:i+window_size]
        window_pos = positions[i:i+window_size]
        
        # Calculate spatial distances within window
        spatial_dists = np.linalg.norm(window_pos[1:] - window_pos[:-1], axis=1)
        
        # Calculate Wasserstein distances for left and right channels
        wasserstein_left = np.array([
            wasserstein_profile_distance(window_left[j], window_left[j+1])
            for j in range(window_size-1)
        ])
        
        wasserstein_right = np.array([
            wasserstein_profile_distance(window_right[j], window_right[j+1])
            for j in range(window_size-1)
        ])
        
        # Combine channels (average or other combination)
        wasserstein_combined = (wasserstein_left + wasserstein_right) / 2
        
        # Calculate correlation between spatial movement and sonar changes
        corr_left = np.corrcoef(spatial_dists, wasserstein_left)[0,1]
        corr_right = np.corrcoef(spatial_dists, wasserstein_right)[0,1]
        corr_combined = np.corrcoef(spatial_dists, wasserstein_combined)[0,1]
        
        results.append({
            'window_start': i,
            'window_end': i+window_size-1,
            'spatial_variance': np.var(spatial_dists),
            'wasserstein_mean': np.mean(wasserstein_combined),
            'correlation_left': corr_left,
            'correlation_right': corr_right,
            'correlation_combined': corr_combined,
            'center_x': np.mean(window_pos[:,0]),
            'center_y': np.mean(window_pos[:,1])
        })
    
    return pd.DataFrame(results)


def plot_wasserstein_analysis(results, rob_x, rob_y):
    """Visualize Wasserstein spatial correlation results"""
    plt.figure(figsize=(15, 5))
    
    # Plot 1: Correlation along trajectory
    plt.subplot(1, 3, 1)
    plt.plot(results['window_start'], results['correlation_combined'], '.-')
    plt.axhline(0, color='red', linestyle='--', alpha=0.3)
    plt.xlabel('Measurement index')
    plt.ylabel('Spatial-Wasserstein Correlation')
    plt.title('Correlation along trajectory')
    plt.grid(True)
    
    # Plot 2: Spatial distribution of correlation
    plt.subplot(1, 3, 2)
    scatter = plt.scatter(results['center_x'], results['center_y'], 
                        c=results['correlation_combined'], 
                        cmap='coolwarm', vmin=-1, vmax=1, alpha=0.7)
    plt.colorbar(scatter, label='Correlation')
    plt.scatter(rob_x, rob_y, s=5, alpha=0.2, color='gray', label='Full path')
    plt.xlabel('X position (mm)')
    plt.ylabel('Y position (mm)')
    plt.title('Spatial distribution of correlation')
    plt.axis('equal')
    plt.legend()
    
    # Plot 3: Correlation histograms
    plt.subplot(1, 3, 3)
    plt.hist(results['correlation_left'], bins=20, alpha=0.5, label='Left channel')
    plt.hist(results['correlation_right'], bins=20, alpha=0.5, label='Right channel')
    plt.hist(results['correlation_combined'], bins=20, alpha=0.5, label='Combined')
    plt.xlabel('Correlation coefficient')
    plt.ylabel('Frequency')
    plt.title('Correlation distributions')
    plt.legend()
    plt.grid(True)
    
    plt.tight_layout()


az_steps = 121
max_extent = 45
extents = [35, 34, 33, 32, 31, 30]

sessions = ['session03']
collection = DataProcessor.DataCollection(sessions, az_min=-max_extent, az_max=max_extent, az_steps=az_steps)

# Getting data
sonar_data = collection.get_field('sonar_data')
rob_x = collection.get_field('rob_x')
rob_y = collection.get_field('rob_y')
rob_yaw_deg = collection.get_field('rob_yaw_deg')

# Prepare positions for analysis
positions = np.column_stack((rob_x, rob_y))

# Run Wasserstein spatial analysis with a single window size for efficiency
window_size = 7
print(f"\nAnalyzing with window size = {window_size}")
results = spatial_wasserstein_analysis(sonar_data, positions, window_size=window_size)

# Print summary statistics
print(f"Window size {window_size} results:")
print(f"  Mean correlation (combined): {results['correlation_combined'].mean():.3f}")
print(f"  Mean correlation (left): {results['correlation_left'].mean():.3f}")
print(f"  Mean correlation (right): {results['correlation_right'].mean():.3f}")
print(f"  Max correlation: {results['correlation_combined'].max():.3f}")
print(f"  Min correlation: {results['correlation_combined'].min():.3f}")
print(f"  Positive correlation windows: {(results['correlation_combined'] > 0.3).sum()} / {len(results)}")

# Visualize results
plot_wasserstein_analysis(results, rob_x, rob_y)
plt.suptitle(f'Wasserstein Spatial Analysis (window size = {window_size})', y=1.02)
plt.show()

def create_sonar_embedding(sonar_data, n_components=2, method='pca'):
    """Create low-dimensional embedding of sonar data"""
    from sklearn.decomposition import PCA
    from sklearn.manifold import MDS, TSNE
    
    # Split channels and compute Wasserstein distances
    left_chan, right_chan = split_sonar_channels(sonar_data)
    
    # Create distance matrix using Wasserstein
    n_samples = sonar_data.shape[0]
    sample_size = min(100, n_samples)  # For efficiency
    sample_indices = np.random.choice(n_samples, sample_size, replace=False)
    
    print(f"Computing embedding for {sample_size} samples...")
    
    # Compute pairwise Wasserstein distances
    wasserstein_dist = np.zeros((sample_size, sample_size))
    for i in range(sample_size):
        for j in range(i, sample_size):
            idx1, idx2 = sample_indices[i], sample_indices[j]
            
            # Combine left and right channel distances
            dist_left = wasserstein_profile_distance(left_chan[idx1], left_chan[idx2])
            dist_right = wasserstein_profile_distance(right_chan[idx1], right_chan[idx2])
            combined_dist = (dist_left + dist_right) / 2
            
            wasserstein_dist[i,j] = combined_dist
            wasserstein_dist[j,i] = combined_dist
    
    # Create embedding
    if method == 'pca':
        # Use PCA on flattened sonar data
        sonar_flat = sonar_data[sample_indices].reshape(sample_size, -1)
        embedding = PCA(n_components=n_components).fit_transform(sonar_flat)
    elif method == 'mds':
        # Use MDS on Wasserstein distances
        embedding = MDS(n_components=n_components, dissimilarity='precomputed', random_state=42).fit_transform(wasserstein_dist)
    elif method == 'tsne':
        # Use t-SNE on Wasserstein distances (need to use spectral init)
        embedding = TSNE(n_components=n_components, metric='precomputed', init='random', random_state=42).fit_transform(wasserstein_dist)
    
    return embedding, sample_indices


def plot_embedding_vs_space(embedding, positions, sample_indices):
    """Compare embedding space with physical space"""
    sample_positions = positions[sample_indices]
    
    plt.figure(figsize=(15, 6))
    
    # Plot 1: Embedding space
    plt.subplot(1, 3, 1)
    plt.scatter(embedding[:, 0], embedding[:, 1], c=range(len(embedding)), cmap='viridis')
    plt.colorbar(label='Sample index')
    plt.title('Sonar Embedding Space')
    plt.xlabel('Dimension 1')
    plt.ylabel('Dimension 2')
    plt.grid(True)
    
    # Plot 2: Physical space
    plt.subplot(1, 3, 2)
    plt.scatter(sample_positions[:, 0], sample_positions[:, 1], c=range(len(sample_positions)), cmap='viridis')
    plt.colorbar(label='Sample index')
    plt.title('Physical Space')
    plt.xlabel('X position (mm)')
    plt.ylabel('Y position (mm)')
    plt.axis('equal')
    plt.grid(True)
    
    # Plot 3: Embedding vs Physical correlation
    plt.subplot(1, 3, 3)
    
    # Compute spatial distances in both spaces
    spatial_dists = pairwise_distances(sample_positions)
    embedding_dists = pairwise_distances(embedding)
    
    # Flatten and plot
    plt.scatter(spatial_dists.flatten(), embedding_dists.flatten(), alpha=0.1)
    plt.xlabel('Spatial Distance (mm)')
    plt.ylabel('Embedding Distance')
    plt.title('Distance Correlation')
    plt.grid(True)
    
    # Compute and display correlation
    corr = np.corrcoef(spatial_dists.flatten(), embedding_dists.flatten())[0,1]
    plt.text(0.05, 0.95, f'Correlation: {corr:.3f}', transform=plt.gca().transAxes,
             bbox=dict(facecolor='white', alpha=0.8))
    
    plt.tight_layout()


# Additional analysis: Find regions with strong spatial correlation
strong_correlation_results = results[results['correlation_combined'] > 0.3]
print(f"\nFound {len(strong_correlation_results)} windows with strong spatial correlation (>0.3)")

if len(strong_correlation_results) > 0:
    plt.figure(figsize=(10, 6))
    plt.scatter(rob_x, rob_y, s=5, alpha=0.2, color='gray', label='Full path')
    plt.scatter(strong_correlation_results['center_x'], strong_correlation_results['center_y'], 
                c=strong_correlation_results['correlation_combined'], 
                cmap='viridis', s=100, alpha=0.8, label='Strong correlation regions')
    plt.colorbar(label='Correlation strength')
    plt.title('Regions with Strong Spatial Information')
    plt.xlabel('X position (mm)')
    plt.ylabel('Y position (mm)')
    plt.axis('equal')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.show()

# Create and analyze sonar embeddings
print("\n=== SONAR EMBEDDING ANALYSIS ===")

# Test different embedding methods
methods = ['pca', 'mds', 'tsne']
embeddings = {}

for method in methods:
    print(f"\nCreating {method.upper()} embedding...")
    embedding, sample_indices = create_sonar_embedding(sonar_data, method=method)
    embeddings[method] = (embedding, sample_indices)
    
    # Plot comparison
    plot_embedding_vs_space(embedding, positions, sample_indices)
    plt.suptitle(f'{method.upper()} Embedding vs Physical Space', y=1.05)
    plt.show()