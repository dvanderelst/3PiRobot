import numpy as np
import torch
import torch.nn as nn

def load_network(model_path):
    # Load neural network model
    print("Loading neural network model...")
    try:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        nn_model, nn_meta = load_distance_side_model(model_path, device)
        print(f"✓ Loaded NN model from {model_path} on {device}")
        return nn_model, nn_meta
    except Exception as e: print(f"✗ Could not load NN model: {e}")



class TwinTowerNet(nn.Module):
    def __init__(self, in_len, drop_p=0.0, binary_classification=True):
        super().__init__()
        if in_len % 2 != 0:
            raise ValueError("Expected even feature length for left/right split.")
        self.half = in_len // 2
        self.binary_classification = binary_classification
        self.tower = nn.Sequential(
            nn.Linear(self.half, 128),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(128, 64),
            nn.ReLU(),
        )
        self.fuse = nn.Sequential(
            nn.Linear(64 * 2, 128),
            nn.ReLU(),
            nn.Dropout(drop_p),
        )
        self.reg_head = nn.Linear(128, 1)
        # Binary classification (left/right) instead of 3-class (left/center/right)
        self.side_head = nn.Linear(128, 1 if binary_classification else 3)

    def forward(self, x):
        left = x[:, : self.half]
        right = x[:, self.half :]
        z_left = self.tower(left)
        z_right = self.tower(right)
        z = torch.cat([z_left, z_right], dim=1)
        z = self.fuse(z)
        return self.reg_head(z).squeeze(1), self.side_head(z)


class EnhancedTwinTowerNet(nn.Module):
    def __init__(self, in_len, drop_p=0.0, binary_classification=True, use_batch_norm=True):
        super().__init__()
        if in_len % 2 != 0:
            raise ValueError("Expected even feature length for left/right split.")
        self.half = in_len // 2
        self.binary_classification = binary_classification
        self.use_batch_norm = use_batch_norm
        
        # Enhanced tower architecture
        tower_layers = []
        tower_layers.append(nn.Linear(self.half, 256))
        if use_batch_norm:
            tower_layers.append(nn.BatchNorm1d(256))
        tower_layers.append(nn.ReLU())
        tower_layers.append(nn.Dropout(drop_p))
        
        tower_layers.append(nn.Linear(256, 128))
        if use_batch_norm:
            tower_layers.append(nn.BatchNorm1d(128))
        tower_layers.append(nn.ReLU())
        tower_layers.append(nn.Dropout(drop_p))
        
        tower_layers.append(nn.Linear(128, 64))
        if use_batch_norm:
            tower_layers.append(nn.BatchNorm1d(64))
        tower_layers.append(nn.ReLU())
        
        self.tower = nn.Sequential(*tower_layers)
        
        # Enhanced fusion
        fuse_layers = []
        fuse_layers.append(nn.Linear(64 * 2, 256))
        if use_batch_norm:
            fuse_layers.append(nn.BatchNorm1d(256))
        fuse_layers.append(nn.ReLU())
        fuse_layers.append(nn.Dropout(drop_p))
        
        fuse_layers.append(nn.Linear(256, 128))
        if use_batch_norm:
            fuse_layers.append(nn.BatchNorm1d(128))
        fuse_layers.append(nn.ReLU())
        fuse_layers.append(nn.Dropout(drop_p))
        
        self.fuse = nn.Sequential(*fuse_layers)
        
        # Prediction heads
        self.reg_head = nn.Sequential(
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )
        
        self.side_head = nn.Sequential(
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 1 if binary_classification else 3)
        )

    def forward(self, x):
        left = x[:, : self.half]
        right = x[:, self.half :]
        z_left = self.tower(left)
        z_right = self.tower(right)
        z = torch.cat([z_left, z_right], dim=1)
        z = self.fuse(z)
        return self.reg_head(z).squeeze(1), self.side_head(z)


def load_distance_side_model(checkpoint_path, device=None):
    if device is None:
        device = torch.device("cpu")
    ckpt = torch.load(checkpoint_path, map_location=device)
    
    # Determine model architecture
    model_arch = ckpt.get("model_architecture", "TwinTowerNet")
    
    # Determine if this is a binary or multi-class model based on the saved weights
    # Handle both original and enhanced model architectures
    side_head_weight_key = "side_head.weight" if "side_head.weight" in ckpt["model_state"] else "side_head.2.weight"
    side_head_weight = ckpt["model_state"][side_head_weight_key]
    binary_classification = side_head_weight.shape[0] == 1  # Binary if output size is 1
    
    # Load appropriate model architecture
    if model_arch == "EnhancedTwinTowerNet":
        use_batch_norm = True  # Enhanced model uses batch norm
        model = EnhancedTwinTowerNet(
            ckpt["input_len"], drop_p=0.0, 
            binary_classification=binary_classification, 
            use_batch_norm=use_batch_norm
        ).to(device)
    else:
        # Default to original architecture
        model = TwinTowerNet(
            ckpt["input_len"], drop_p=0.0, 
            binary_classification=binary_classification
        ).to(device)
    
    model.load_state_dict(ckpt["model_state"])
    model.eval()
    
    meta = {
        "scaler_mean": ckpt["scaler_mean"],
        "scaler_scale": ckpt["scaler_scale"],
        "y_reg_mean": ckpt["y_reg_mean"],
        "y_reg_std": ckpt["y_reg_std"],
        "same_thresh_mm": ckpt.get("same_thresh_mm", None),
        "binary_classification": binary_classification,
        "use_spectral_features": ckpt.get("use_spectral_features", False),
        "model_architecture": model_arch,
    }
    return model, meta


def processNN(left_sonar, right_sonar, model, meta, device=None):
    if device is None:
        device = torch.device("cpu")
    left = np.asarray(left_sonar, dtype=np.float32).ravel()
    right = np.asarray(right_sonar, dtype=np.float32).ravel()
    
    # Handle spectral features if the model was trained with them
    if meta.get("use_spectral_features", False):
        # Add spectral features to match training
        x = np.zeros((1, len(meta["scaler_mean"])), dtype=np.float32)
        x[0, :200] = np.concatenate([left, right], axis=0)
        
        # Add spectral features (same as training)
        x[0, 200] = np.mean(left)      # Left mean
        x[0, 201] = np.std(left)       # Left std
        x[0, 202] = np.max(left)       # Left max
        x[0, 203] = np.mean(right)     # Right mean
        x[0, 204] = np.std(right)      # Right std
        x[0, 205] = np.max(right)      # Right max
        x[0, 206] = np.mean(left - right)  # Mean difference
        x[0, 207] = np.std(left - right)   # Std difference
    else:
        x = np.concatenate([left, right], axis=0)[None, :]
    
    if x.shape[1] != len(meta["scaler_mean"]):
        raise ValueError(f"Input length {x.shape[1]} does not match model scaler length {len(meta['scaler_mean'])}. Model uses spectral features: {meta.get('use_spectral_features', False)}")
    
    x = (x - meta["scaler_mean"]) / meta["scaler_scale"]
    xb = torch.tensor(x, dtype=torch.float32, device=device)
    with torch.no_grad():
        pred_reg_n, pred_side = model(xb)
    pred_reg_n = pred_reg_n.cpu().numpy()[0]
    pred_side = pred_side.cpu().numpy()[0]
    pred_reg_log = pred_reg_n * meta["y_reg_std"] + meta["y_reg_mean"]
    pred_dist = float(np.expm1(pred_reg_log))
    
    # Handle binary vs multi-class output
    if meta.get("binary_classification", True):
        # Binary classification: single output, use sigmoid threshold
        side_sign = 1 if pred_side > 0 else -1
    else:
        # Multi-class: use argmax and convert to sign
        side_idx = int(np.argmax(pred_side))
        side_sign = side_idx - 1
    
    return pred_dist, side_sign
