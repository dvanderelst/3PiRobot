import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
from sklearn.decomposition import FastICA, PCA
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import Dataset, DataLoader
from Library import DataProcessor
from Library import Guidance


torch.set_num_threads(1)
torch.set_num_interop_threads(1)

seed = 123
np.random.seed(seed)
torch.manual_seed(seed)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device, flush=True)

# -----------------------------
# Settings
# -----------------------------
n_prev = 0  # previous frames (window uses n_prev + current)
use_rotation_history = False
base_components = 75
reduction = "pca"  # "pca" or "ica"
d0 = 250
batch_size_train = 64
batch_size_val = 128
drop_p = 0.2
epochs = 1000
patience = 50
use_log_profile = False
max_scatter_points = 30000

# -----------------------------
# Load and collate data
# -----------------------------
processor1 = DataProcessor.DataProcessor("session6")
processor2 = DataProcessor.DataProcessor("session7")

collated1 = processor1.collate_data(d=d0, az_min=-50,az_max=50, az_steps=5)
collated2 = processor2.collate_data(d=d0, az_min=-50,az_max=50, az_steps=5)

sonar_flat1 = collated1["sonar_data"]
sonar_flat2 = collated2["sonar_data"]
rotations1 = collated1['rotations']
rotations2 = collated2['rotations']

vector_field1 = collated1['vector_field']
vector_field2 = collated2['vector_field']


max_directions1 = collated1['max_directions']
max_directions2 = collated2['max_directions']
profile1 = collated1['profiles']
profile2 = collated2['profiles']

profile1[profile1 > 1500] = 1500
profile2[profile2 > 1500] = 1500

centers = collated1['centers']
rob_x1, rob_y1, rob_yaw_deg1 = processor1.rob_x, processor1.rob_y, processor1.rob_yaw_deg
rob_x2, rob_y2, rob_yaw_deg2 = processor2.rob_x, processor2.rob_y, processor2.rob_yaw_deg

def build_sequence_features(sonar_flat, profiles, n_prev, rob_x, rob_y, rob_yaw_deg):
    n = sonar_flat.shape[0]
    if profiles.shape[0] != n:
        raise ValueError("profiles length must match sonar length")
    if rob_x.shape[0] != n or rob_y.shape[0] != n or rob_yaw_deg.shape[0] != n:
        raise ValueError("pose length must match sonar length")
    if n <= n_prev:
        raise ValueError("Not enough samples to build sequences")
    X_seq = []
    y_seq = []
    x_seq = []
    y_seq_pos = []
    yaw_seq = []
    for i in range(n_prev, n):
        window = sonar_flat[i - n_prev:i + 1]
        X_seq.append(window.reshape(-1))
        y_seq.append(profiles[i])
        x_seq.append(rob_x[i])
        y_seq_pos.append(rob_y[i])
        yaw_seq.append(rob_yaw_deg[i])
    X_seq = np.array(X_seq, dtype=np.float32)
    y_seq = np.array(y_seq, dtype=np.float32)
    return (
        X_seq,
        y_seq,
        np.array(x_seq, dtype=np.float32),
        np.array(y_seq_pos, dtype=np.float32),
        np.array(yaw_seq, dtype=np.float32),
    )


if profile1.ndim == 1:
    profile1 = profile1[:, None]
if profile2.ndim == 1:
    profile2 = profile2[:, None]

X_seq1, y_seq1, x_pos1, y_pos1, yaw_deg1 = build_sequence_features(
    sonar_flat1, profile1, n_prev, rob_x1, rob_y1, rob_yaw_deg1
)
X_seq2, y_seq2, x_pos2, y_pos2, yaw_deg2 = build_sequence_features(
    sonar_flat2, profile2, n_prev, rob_x2, rob_y2, rob_yaw_deg2
)

if use_log_profile:
    y_seq1 = np.log1p(y_seq1)
    y_seq2 = np.log1p(y_seq2)

X_all = np.concatenate((X_seq1, X_seq2), axis=0).astype(np.float32)
y_all = np.concatenate((y_seq1, y_seq2), axis=0).astype(np.float32)
x_all = np.concatenate((x_pos1, x_pos2), axis=0).astype(np.float32)
y_all_pos = np.concatenate((y_pos1, y_pos2), axis=0).astype(np.float32)
yaw_all = np.concatenate((yaw_deg1, yaw_deg2), axis=0).astype(np.float32)

profile_dim = y_all.shape[1]

# -----------------------------
# Train/val split
# -----------------------------
X_train, X_val, y_train, y_val, x_train, x_val, y_train_pos, y_val_pos, yaw_train, yaw_val = train_test_split(
    X_all,
    y_all,
    x_all,
    y_all_pos,
    yaw_all,
    test_size=0.2,
    random_state=seed,
    shuffle=True,
)

# -----------------------------
# Standardize features using train stats
# -----------------------------
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_val = scaler.transform(X_val)

# -----------------------------
# Dimensionality reduction
# -----------------------------
n_components = base_components * (n_prev + 1)
n_components = min(n_components, X_train.shape[1])
if reduction == "pca":
    reducer = PCA(n_components=n_components, random_state=seed)
    X_train = reducer.fit_transform(X_train)
    X_val = reducer.transform(X_val)
    print(f"PCA explained variance: {reducer.explained_variance_ratio_.sum():.3f}")
else:
    reducer = FastICA(n_components=n_components, random_state=seed, max_iter=1000)
    X_train = reducer.fit_transform(X_train)
    X_val = reducer.transform(X_val)
    print(f"ICA components: {n_components}")


class SonarProfileDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.from_numpy(X)
        self.y = torch.from_numpy(y)

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


train_loader = DataLoader(
    SonarProfileDataset(X_train, y_train),
    batch_size=batch_size_train,
    shuffle=True,
    drop_last=False,
)
val_loader = DataLoader(
    SonarProfileDataset(X_val, y_val),
    batch_size=batch_size_val,
    shuffle=False,
    drop_last=False,
)

input_dim = X_train.shape[1]
hidden1 = max(128, input_dim * 2)
hidden2 = max(64, input_dim)

model = nn.Sequential(
    nn.Linear(input_dim, hidden1),
    nn.ReLU(),
    nn.Dropout(drop_p),
    nn.Linear(hidden1, hidden2),
    nn.ReLU(),
    nn.Dropout(drop_p),
    nn.Linear(hidden2, profile_dim),
).to(device)

optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
criterion = nn.MSELoss()

best_val = float("inf")
best_state = None
pat_left = patience

for epoch in range(1, epochs + 1):
    model.train()
    total_loss = 0.0
    for xb, yb in train_loader:
        xb = xb.to(device)
        yb = yb.to(device)
        optimizer.zero_grad()
        pred = model(xb)
        loss = criterion(pred, yb)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * xb.size(0)

    train_loss = total_loss / len(train_loader.dataset)

    model.eval()
    val_loss = 0.0
    with torch.no_grad():
        for xb, yb in val_loader:
            xb = xb.to(device)
            yb = yb.to(device)
            pred = model(xb)
            loss = criterion(pred, yb)
            val_loss += loss.item() * xb.size(0)
    val_loss /= len(val_loader.dataset)
    val_rmse = float(np.sqrt(val_loss))

    print(
        f"Epoch {epoch:03d} | train loss {train_loss:.5f} | val RMSE {val_rmse:.5f}",
        flush=True,
    )

    if val_loss < best_val - 1e-6:
        best_val = val_loss
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        pat_left = patience
    else:
        pat_left -= 1
        if pat_left <= 0:
            print(f"Early stop (best val RMSE {np.sqrt(best_val):.5f})", flush=True)
            break

if best_state is not None:
    model.load_state_dict(best_state)

model.eval()
with torch.no_grad():
    y_pred = model(torch.from_numpy(X_val).to(device)).cpu().numpy()

if use_log_profile:
    y_val_plot = np.expm1(y_val)
    y_pred_plot = np.expm1(y_pred)
else:
    y_val_plot = y_val
    y_pred_plot = y_pred

flat_true = y_val_plot.reshape(-1)
flat_pred = y_pred_plot.reshape(-1)

if flat_true.size > 1:
    corr = float(np.corrcoef(flat_true, flat_pred)[0, 1])
    print(f"Scatter correlation: {corr:.4f}", flush=True)

plt.figure(figsize=(6, 6))
plt.scatter(flat_true, flat_pred, s=8, alpha=0.5)
lims = [min(flat_true.min(), flat_pred.min()), max(flat_true.max(), flat_pred.max())]
plt.plot(lims, lims, "k--", linewidth=1)
plt.xlabel("Profile true")
plt.ylabel("Profile predicted")
plt.title("Profile prediction scatter (val)")
plt.tight_layout()
plt.show()

centers = collated1.get("centers")
if centers is None:
    centers = np.arange(profile_dim, dtype=np.float32)

sample_idx = np.linspace(0, y_val.shape[0] - 1, num=min(6, y_val.shape[0]), dtype=int)
plt.figure(figsize=(8, 6))
colors = plt.cm.tab10(np.linspace(0, 1, len(sample_idx)))
for color, idx in zip(colors, sample_idx):
    plt.plot(centers, y_val_plot[idx], color=color, alpha=0.8)
    plt.plot(centers, y_pred_plot[idx], color=color, alpha=0.8, linestyle="--")
plt.xlabel("Azimuth index")
plt.ylabel("Distance to wall")
plt.title("Profile predictions (val samples)")
plt.tight_layout()
plt.show()

centers_deg = centers.astype(np.float32)
theta = np.deg2rad(centers_deg[None, :] + yaw_val[:, None])
px = x_val[:, None] + y_pred_plot * np.cos(theta)
py = y_val_pos[:, None] + y_pred_plot * np.sin(theta)

px = px.reshape(-1)
py = py.reshape(-1)
if px.size > max_scatter_points:
    idx = np.random.choice(px.size, size=max_scatter_points, replace=False)
    px = px[idx]
    py = py[idx]

plt.figure(figsize=(6, 6))
plt.scatter(px, py, s=2, alpha=0.5)
plt.xlabel("X")
plt.ylabel("Y")
plt.title("Predicted profile points (val)")
plt.axis("equal")
plt.tight_layout()
plt.show()
