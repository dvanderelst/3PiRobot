from Library import DataProcessor
from Library import Utils
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# Parameters
az_extent = 90
az_steps = 19  # Number of azimuth steps in profiles
sessions = ['session03', 'session04']


collection = DataProcessor.DataCollection(sessions, az_min=-az_extent, az_max=az_extent, az_steps=az_steps)

profiles = collection.get_field('profiles')
corrected_distances = collection.get_field('corrected_distance')
motion = collection.get_field('rotations')
#%%
p = corrected_distances * np.sign(motion)

plt.figure()
plt.plot(p, alpha=0.25)
plt.show()