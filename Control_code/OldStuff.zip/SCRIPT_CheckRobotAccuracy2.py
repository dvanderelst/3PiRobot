#%%
"""
This script calculates the correspondence between the layout of the environment and the
distance/side of closest obstacle as inferred from the the sonar data.
"""
import numpy
import numpy as np
from Library import Utils
from Library import DataProcessor
from matplotlib import pyplot as plt
import pandas as pd
import seaborn as sn

az_steps = 111
max_extent = 35
chip_steps = 8

processor = DataProcessor.DataProcessor("session7")
collated = processor.collate_data(az_min=-max_extent, az_max=max_extent, az_steps=az_steps)



centers = collated['centers']
profiles = collated['profiles']
sonar_iid = collated['corrected_iid']
sonar_distance = collated['corrected_distance']
sonar_block = collated['sonar_block']

rob_x = collated['rob_x']
rob_y = collated['rob_y']
rob_yaw_deg = collated['rob_yaw_deg']
wall_x = processor.wall_x
wall_y = processor.wall_y

sonar_iid_sign = np.sign(sonar_iid)
centers = np.round(centers)




#%%


indices = Utils.get_extrema_positions(profiles, 'min')
closest_visual_direction = centers[indices]
closest_visual_distance = Utils.get_extrema_values(profiles, 'min') / 1000
closest_visual_side = np.sign(closest_visual_direction) * -1
sign_matches = closest_visual_side == sonar_iid_sign

differences = closest_visual_distance - sonar_distance
overshoots = np.where(differences > 0.5)[0]
undershoots = np.where(differences < -0.5)[0]
#%%
error_index = 12
plt.close('all')

plt.figure()
plt.scatter(closest_visual_distance, sonar_distance)
plt.plot([0,1.5], [0, 1.5], color='black')
plt.plot([0,1.5], [0-0.05, 1.5-0.05], color='black')
plt.xlabel('closest visual distance')
plt.ylabel('sonar distance')
plt.show()

matches = numpy.nanmean(sign_matches)
print('percentage matches: ', matches)


selected = overshoots[error_index]
selected_profile = profiles[selected, :]
selected_sonar_distance = sonar_distance[selected]
selected_visual_distance = closest_visual_distance[selected]

selected_rob_x = rob_x[selected]
selected_rob_y = rob_y[selected]
selected_rob_yaw = rob_yaw_deg[selected]
selected_sonar = sonar_block[selected, :, :]


proj_x, proj_y  = DataProcessor.robot2world(0, 50, selected_rob_x, selected_rob_y, selected_rob_yaw)


plt.figure()
plt.plot(centers, selected_profile)
plt.title(f'{selected}, SN {selected_sonar_distance}, VS {selected_visual_distance}')
plt.show()

processor.plot_arena(show=False)
plt.scatter(rob_x[selected], rob_y[selected], color='blue')
plt.scatter(proj_x, proj_y, color='green', s=10)
plt.show()

plt.figure()
plt.plot(selected_sonar)
plt.show()


