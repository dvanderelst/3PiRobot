import numpy as np
import matplotlib.pyplot as plt
from matplotlib import image as mpimg
from scipy.ndimage import distance_transform_edt, binary_dilation, binary_closing, label

seed = 123
np.random.seed(seed)

# -----------------------------
# Settings
# -----------------------------
image_path = "test.png"
green_margin = 0.15  # min delta above R/B to classify as green
min_green = 0.25  # absolute green threshold
dilate_iter = 2  # thicken wall mask to close gaps
close_iter = 2  # close small gaps in wall outline
quiver_step = 20  # downsample for visualization
quiver_scale = 40
seed_xy = None  # (x, y) in image coords; None uses image center


def load_image(path):
    img = mpimg.imread(path)
    if img.dtype == np.uint8:
        img = img.astype(np.float32) / 255.0
    if img.shape[-1] == 4:
        img = img[..., :3]
    return img


def segment_green_walls(img):
    r = img[..., 0]
    g = img[..., 1]
    b = img[..., 2]
    wall = (g > min_green) & (g > r + green_margin) & (g > b + green_margin)
    if close_iter > 0:
        wall = binary_closing(wall, iterations=close_iter)
    if dilate_iter > 0:
        wall = binary_dilation(wall, iterations=dilate_iter)
    return wall


def compute_distance_field(wall_mask, seed_xy=None):
    # distance_transform_edt computes distance to the nearest zero.
    # Use free space as True and walls as False to get distance to walls.
    free = ~wall_mask
    labeled, num = label(free)
    if num == 0:
        raise ValueError("No free space detected in wall mask")
    border_labels = np.unique(
        np.concatenate(
            [
                labeled[0, :],
                labeled[-1, :],
                labeled[:, 0],
                labeled[:, -1],
            ]
        )
    )
    outside = np.isin(labeled, border_labels)
    inside_candidates = free & ~outside
    if seed_xy is not None:
        h, w = wall_mask.shape
        sx = int(np.clip(seed_xy[0], 0, w - 1))
        sy = int(np.clip(seed_xy[1], 0, h - 1))
        if labeled[sy, sx] == 0:
            ys, xs = np.nonzero(free)
            if xs.size == 0:
                raise ValueError("No free pixels found")
            d2 = (xs - sx) ** 2 + (ys - sy) ** 2
            idx = int(np.argmin(d2))
            sx = int(xs[idx])
            sy = int(ys[idx])
        main_label = labeled[sy, sx]
        inside = labeled == main_label
    elif inside_candidates.any():
        labels_inside = labeled * inside_candidates
        label_ids, counts = np.unique(labels_inside[labels_inside > 0], return_counts=True)
        main_label = label_ids[np.argmax(counts)]
        inside = labeled == main_label
    else:
        inside = free
    dist = distance_transform_edt(inside).astype(np.float32)
    return dist, inside


def compute_repulsive_field(dist):
    # Gradient points toward increasing distance (away from walls).
    grad_y, grad_x = np.gradient(dist)
    mag = np.hypot(grad_x, grad_y)
    mag = np.maximum(mag, 1e-6)
    vx = grad_x / mag
    vy = grad_y / mag
    return vx, vy


def desired_heading_at(x, y, vx, vy):
    # x, y in image coordinates (x to the right, y downward).
    h, w = vx.shape
    xi = int(np.clip(x, 0, w - 1))
    yi = int(np.clip(y, 0, h - 1))
    return float(vx[yi, xi]), float(vy[yi, xi])


img = load_image(image_path)
wall_mask = segment_green_walls(img)
h, w = wall_mask.shape
if seed_xy is None:
    seed_xy = (w * 0.5, h * 0.5)
dist, inside_mask = compute_distance_field(wall_mask, seed_xy=seed_xy)
vx, vy = compute_repulsive_field(dist)

# -----------------------------
# Visualization
# -----------------------------
plt.figure(figsize=(8, 6))
plt.imshow(img)
plt.contour(wall_mask, levels=[0.5], colors="lime", linewidths=1)
plt.title("Walls segmentation overlay")
plt.axis("off")
plt.tight_layout()
plt.show()

plt.figure(figsize=(8, 6))
plt.imshow(dist, cmap="magma")
plt.title("Distance to wall (pixels)")
plt.axis("off")
plt.tight_layout()
plt.show()

h, w = dist.shape
ys = np.arange(0, h, quiver_step)
xs = np.arange(0, w, quiver_step)
X, Y = np.meshgrid(xs, ys)
U = vx[::quiver_step, ::quiver_step]
V = vy[::quiver_step, ::quiver_step]
inside_quiver = inside_mask[::quiver_step, ::quiver_step]
U = np.where(inside_quiver, U, np.nan)
V = np.where(inside_quiver, V, np.nan)

plt.figure(figsize=(8, 6))
plt.imshow(img, alpha=0.6)
# Flip V to account for image coordinates (y increases downward).
plt.quiver(X, Y, U, -V, color="cyan", scale=quiver_scale, width=0.003)
plt.title("Repulsive direction field (image coords)")
plt.axis("off")
plt.tight_layout()
plt.show()

# Example query
ex_x, ex_y = w * 0.5, h * 0.5
dx, dy = desired_heading_at(ex_x, ex_y, vx, vy)
print(f"Example heading at center: dx={dx:.3f}, dy={dy:.3f}", flush=True)
