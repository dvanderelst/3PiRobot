#%%
"""
Train a small neural network to map binaural sonar measurements to the sides
of the closest (min distance) and farthest (max distance) obstacles derived
from the overhead camera system.
"""
import numpy as np
import torch
import torch.nn as nn
from sklearn.decomposition import FastICA, PCA
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import Dataset, DataLoader
from Library import Utils
from Library import DataProcessor
from matplotlib import pyplot as plt


torch.set_num_threads(1)
torch.set_num_interop_threads(1)

seed = 123
np.random.seed(seed)
torch.manual_seed(seed)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device, flush=True)

# -----------------------------
# Settings
# -----------------------------
az_steps = 2
max_extent = 30
use_raw_sonar = True
drop_center_class = True  # drop samples where either side == 0
reduction = "pca"  # "pca", "ica", or None
base_components = 100
batch_size_train = 64
batch_size_val = 128
drop_p = 0.1
epochs = 400
patience = 50

# -----------------------------
# Load and collate data
# -----------------------------
processor1 = DataProcessor.DataProcessor("session6")
processor2 = DataProcessor.DataProcessor("session7")
processor3 = DataProcessor.DataProcessor("session8")

collated1 = processor1.collate_data(az_min=-max_extent, az_max=max_extent, az_steps=az_steps)
collated2 = processor2.collate_data(az_min=-max_extent, az_max=max_extent, az_steps=az_steps)
collated3 = processor3.collate_data(az_min=-max_extent, az_max=max_extent, az_steps=az_steps)

collated_results = [collated1, collated2, collated3]
all_centers = np.round(collated1["centers"])
profiles = DataProcessor.collect(collated_results, "profiles")
sonar_flat = DataProcessor.collect(collated_results, "sonar_data")  # flattened L/R echoes
sonar_iid = DataProcessor.collect(collated_results, "corrected_iid")  # dB
sonar_distance = DataProcessor.collect(collated_results, "corrected_distance")  # meters

# -----------------------------
# Ground-truth targets from camera data
# -----------------------------
indices_min = Utils.get_extrema_positions(profiles, "min")
indices_max = Utils.get_extrema_positions(profiles, "max")
min_direction = all_centers[indices_min].astype(np.float32)
max_direction = all_centers[indices_max].astype(np.float32)
min_side = np.sign(min_direction) * -1  # -1, 0, 1
max_side = np.sign(max_direction) * -1  # -1, 0, 1

# -----------------------------
# Build feature matrix
# -----------------------------
if use_raw_sonar:
    X = sonar_flat.astype(np.float32)
else:
    raise ValueError("No sonar features selected.")

y_min = np.full_like(min_side, fill_value=-1, dtype=np.int64)
y_min[min_side < 0] = 0
y_min[min_side > 0] = 1

y_max = np.full_like(max_side, fill_value=-1, dtype=np.int64)
y_max[max_side < 0] = 0
y_max[max_side > 0] = 1

valid = np.isfinite(X).all(axis=1)
valid &= np.isfinite(min_side)
valid &= np.isfinite(max_side)
if drop_center_class:
    valid &= (min_side != 0) & (max_side != 0)

X = X[valid]
y_min = y_min[valid]
y_max = y_max[valid]
sonar_iid = sonar_iid[valid]
sonar_distance = sonar_distance[valid]

# -----------------------------
# Train/val split
# -----------------------------
X_train, X_val, y_min_train, y_min_val, y_max_train, y_max_val, sonar_iid_train, sonar_iid_val, sonar_dist_train, sonar_dist_val = train_test_split(
    X,
    y_min,
    y_max,
    sonar_iid,
    sonar_distance,
    test_size=0.2,
    random_state=seed,
    shuffle=True,
    stratify=y_min,
)

# -----------------------------
# Standardize features using train stats
# -----------------------------
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_val = scaler.transform(X_val)

# -----------------------------
# Optional dimensionality reduction
# -----------------------------
if reduction in ("pca", "ica"):
    n_components = base_components
    n_components = min(n_components, X_train.shape[1])
    if reduction == "pca":
        reducer = PCA(n_components=n_components, random_state=seed)
    else:
        reducer = FastICA(n_components=n_components, random_state=seed, max_iter=1000)
    X_train = reducer.fit_transform(X_train)
    X_val = reducer.transform(X_val)


class SonarDataset(Dataset):
    def __init__(self, X, y_min, y_max):
        self.X = torch.from_numpy(X.astype(np.float32))
        self.y_min = torch.from_numpy(y_min.astype(np.int64))
        self.y_max = torch.from_numpy(y_max.astype(np.int64))

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        return self.X[idx], self.y_min[idx], self.y_max[idx]


train_loader = DataLoader(
    SonarDataset(X_train, y_min_train, y_max_train),
    batch_size=batch_size_train,
    shuffle=True,
    drop_last=False,
)
val_loader = DataLoader(
    SonarDataset(X_val, y_min_val, y_max_val),
    batch_size=batch_size_val,
    shuffle=False,
    drop_last=False,
)

input_dim = X_train.shape[1]
hidden1 = max(128, min(512, input_dim * 2))
hidden2 = max(96, min(320, input_dim))
hidden3 = max(48, min(160, input_dim // 2))


class SonarNet(nn.Module):
    def __init__(self, in_dim, h1, h2, h3, drop_p):
        super().__init__()
        self.backbone = nn.Sequential(
            nn.Linear(in_dim, h1),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(h1, h2),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(h2, h3),
            nn.ReLU(),
            nn.Dropout(drop_p),
        )
        self.head_min = nn.Linear(h3, 2)
        self.head_max = nn.Linear(h3, 2)

    def forward(self, x):
        z = self.backbone(x)
        return self.head_min(z), self.head_max(z)


model = SonarNet(input_dim, hidden1, hidden2, hidden3, drop_p).to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

min_counts = np.bincount(y_min_train, minlength=2).astype(np.float32)
max_counts = np.bincount(y_max_train, minlength=2).astype(np.float32)
min_weights = min_counts.sum() / np.clip(min_counts, 1.0, None)
max_weights = max_counts.sum() / np.clip(max_counts, 1.0, None)
min_weights = torch.from_numpy(min_weights).to(device)
max_weights = torch.from_numpy(max_weights).to(device)
criterion_min = nn.CrossEntropyLoss(weight=min_weights)
criterion_max = nn.CrossEntropyLoss(weight=max_weights)

best_val = float("inf")
best_state = None
pat_left = patience

for epoch in range(1, epochs + 1):
    model.train()
    total_loss = 0.0
    for xb, yb_min, yb_max in train_loader:
        xb = xb.to(device)
        yb_min = yb_min.to(device)
        yb_max = yb_max.to(device)
        optimizer.zero_grad()
        logits_min, logits_max = model(xb)
        loss_min = criterion_min(logits_min, yb_min)
        loss_max = criterion_max(logits_max, yb_max)
        loss = loss_min + loss_max
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * xb.size(0)

    train_loss = total_loss / len(train_loader.dataset)

    model.eval()
    val_loss = 0.0
    min_correct = 0
    max_correct = 0
    total = 0
    with torch.no_grad():
        for xb, yb_min, yb_max in val_loader:
            xb = xb.to(device)
            yb_min = yb_min.to(device)
            yb_max = yb_max.to(device)
            logits_min, logits_max = model(xb)
            loss_min = criterion_min(logits_min, yb_min)
            loss_max = criterion_max(logits_max, yb_max)
            loss = loss_min + loss_max
            val_loss += loss.item() * xb.size(0)
            preds_min = logits_min.argmax(dim=1)
            preds_max = logits_max.argmax(dim=1)
            min_correct += int((preds_min == yb_min).sum().item())
            max_correct += int((preds_max == yb_max).sum().item())
            total += yb_min.size(0)

    val_loss /= len(val_loader.dataset)
    min_acc = min_correct / max(1, total)
    max_acc = max_correct / max(1, total)

    print(
        f"Epoch {epoch:03d} | train loss {train_loss:.5f} | val loss {val_loss:.5f} | "
        f"min acc {min_acc:.3f} | max acc {max_acc:.3f}",
        flush=True,
    )

    if val_loss < best_val - 1e-6:
        best_val = val_loss
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        pat_left = patience
    else:
        pat_left -= 1
        if pat_left <= 0:
            print("Early stop", flush=True)
            break

if best_state is not None:
    model.load_state_dict(best_state)

# -----------------------------
# Evaluation and plots
# -----------------------------
model.eval()
with torch.no_grad():
    logits_min, logits_max = model(torch.from_numpy(X_val).to(device))
    pred_min = logits_min.argmax(dim=1).cpu().numpy()
    pred_max = logits_max.argmax(dim=1).cpu().numpy()

min_acc = float(np.mean(pred_min == y_min_val))
max_acc = float(np.mean(pred_max == y_max_val))
print(f"Val min-side accuracy: {min_acc:.3f}", flush=True)
print(f"Val max-side accuracy: {max_acc:.3f}", flush=True)

sonar_iid_sign = np.sign(sonar_iid_val)
sonar_iid_pred = np.full_like(sonar_iid_sign, fill_value=0, dtype=np.int64)
sonar_iid_pred[sonar_iid_sign < 0] = 0
sonar_iid_pred[sonar_iid_sign > 0] = 1
baseline_min = float(np.mean(sonar_iid_pred == y_min_val))
baseline_max = float(np.mean(sonar_iid_pred == y_max_val))
print(f"Baseline IID sign accuracy (min): {baseline_min:.3f}", flush=True)
print(f"Baseline IID sign accuracy (max): {baseline_max:.3f}", flush=True)

conf_min = np.zeros((2, 2), dtype=int)
for t, p in zip(y_min_val, pred_min):
    conf_min[int(t), int(p)] += 1

plt.figure(figsize=(4, 3))
plt.imshow(conf_min, cmap="Blues")
plt.xticks([0, 1], ["left", "right"])
plt.yticks([0, 1], ["left", "right"])
plt.xlabel("Predicted")
plt.ylabel("True")
plt.title("Min-side classification (val)")
for i in range(2):
    for j in range(2):
        plt.text(j, i, str(conf_min[i, j]), ha="center", va="center", color="black")
plt.tight_layout()
plt.show()

conf_max = np.zeros((2, 2), dtype=int)
for t, p in zip(y_max_val, pred_max):
    conf_max[int(t), int(p)] += 1

plt.figure(figsize=(4, 3))
plt.imshow(conf_max, cmap="Blues")
plt.xticks([0, 1], ["left", "right"])
plt.yticks([0, 1], ["left", "right"])
plt.xlabel("Predicted")
plt.ylabel("True")
plt.title("Max-side classification (val)")
for i in range(2):
    for j in range(2):
        plt.text(j, i, str(conf_max[i, j]), ha="center", va="center", color="black")
plt.tight_layout()
plt.show()

# Accuracy vs sonar distance (binned)
bin_count = 10
dist_min = float(np.nanmin(sonar_dist_val))
dist_max = float(np.nanmax(sonar_dist_val))
dist_edges = np.linspace(dist_min, dist_max, bin_count + 1)
dist_centers = 0.5 * (dist_edges[:-1] + dist_edges[1:])
min_acc_by_bin = []
max_acc_by_bin = []
for i in range(bin_count):
    in_bin = (sonar_dist_val >= dist_edges[i]) & (sonar_dist_val < dist_edges[i + 1])
    if not np.any(in_bin):
        min_acc_by_bin.append(np.nan)
        max_acc_by_bin.append(np.nan)
        continue
    min_acc_by_bin.append(float(np.mean(pred_min[in_bin] == y_min_val[in_bin])))
    max_acc_by_bin.append(float(np.mean(pred_max[in_bin] == y_max_val[in_bin])))

plt.figure(figsize=(6, 4))
plt.plot(dist_centers, min_acc_by_bin, marker="o", label="Min-side")
plt.plot(dist_centers, max_acc_by_bin, marker="o", label="Max-side")
plt.xlabel("Sonar distance (m)")
plt.ylabel("Accuracy")
plt.title("Side accuracy vs sonar distance")
plt.ylim(0.0, 1.0)
plt.legend()
plt.tight_layout()
plt.show()
