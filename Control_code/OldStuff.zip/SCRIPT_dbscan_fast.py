#!/usr/bin/env python3
"""
Fast DBSCAN clustering - no interactive plots, tries multiple eps values
"""
import numpy as np
from Library import DataProcessor
from matplotlib import pyplot as plt
from sklearn.decomposition import PCA
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler

def split_sonar_channels(sonar_data):
    half_point = sonar_data.shape[1] // 2
    return sonar_data[:, :half_point], sonar_data[:, half_point:]

def extract_features(sonar_data, window_size=5):
    """Simple feature extraction"""
    left_chan, right_chan = split_sonar_channels(sonar_data)
    n_samples = sonar_data.shape[0]
    
    features = []
    for i in range(0, n_samples - window_size + 1):
        mean_left = left_chan[i:i+window_size].mean(axis=0)
        mean_right = right_chan[i:i+window_size].mean(axis=0)
        features.append(np.concatenate([mean_left, mean_right]))
    
    return np.array(features)

# Load data
print("Loading data...")
sessions = ['session03']
collection = DataProcessor.DataCollection(sessions, az_min=-45, az_max=45, az_steps=121)
sonar_data = collection.get_field('sonar_data')
rob_x = collection.get_field('rob_x')
rob_y = collection.get_field('rob_y')

print(f"Data: {sonar_data.shape[0]} samples")

# Use window size 5
window_size = 5
features = extract_features(sonar_data, window_size)
print(f"Extracted {features.shape[0]} sequences")

# PCA and scale
pca = PCA(n_components=20)
features_pca = pca.fit_transform(features)
scaler = StandardScaler()
features_scaled = scaler.fit_transform(features_pca)

print(f"PCA variance: {pca.explained_variance_ratio_.sum():.3f}")

# Try multiple eps values
eps_values = [1.5, 2.0, 2.5, 3.0]
min_samples = 4  # Smaller min_samples to allow more clusters

print(f"\nTrying multiple eps values with min_samples={min_samples}...")

all_results = []

for eps in eps_values:
    print(f"  eps={eps}...")
    dbscan = DBSCAN(eps=eps, min_samples=min_samples)
    labels = dbscan.fit_predict(features_scaled)
    
    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
    n_noise = list(labels).count(-1)
    
    # Find recurring clusters
    cluster_positions = {}
    for i, label in enumerate(labels):
        if label != -1:
            if label not in cluster_positions:
                cluster_positions[label] = []
            cluster_positions[label].append(i)
    
    recurring = []
    for cluster_id, positions in cluster_positions.items():
        if len(positions) > 1:
            gaps = np.diff(positions) > 10  # Non-consecutive
            if np.any(gaps):
                recurring.append((cluster_id, len(positions), positions))
    
    result = {
        'eps': eps,
        'n_clusters': n_clusters,
        'n_noise': n_noise,
        'recurring': len(recurring),
        'labels': labels,
        'cluster_positions': cluster_positions
    }
    all_results.append(result)
    
    print(f"    eps={eps}: {n_clusters} clusters, {n_noise} noise ({n_noise/len(labels)*100:.1f}%), {len(recurring)} recurring")

# Find best eps (balance between clusters and recurring patterns)
best_result = max(all_results, key=lambda x: x['recurring'] - x['n_noise']/50)

print(f"\n=== BEST RESULT ===")
print(f"eps={best_result['eps']}")
print(f"Clusters: {best_result['n_clusters']}")
print(f"Noise: {best_result['n_noise']} ({best_result['n_noise']/len(best_result['labels'])*100:.1f}%)")
print(f"Recurring patterns: {best_result['recurring']}")

# Save plots to files instead of showing interactively
plt.ioff()  # Turn off interactive mode

# Plot 1: Feature space clustering
plt.figure(figsize=(12, 6))
features_2d = features_scaled[:, :2]

for cluster_id in range(best_result['n_clusters']):
    if cluster_id in best_result['cluster_positions']:
        indices = best_result['cluster_positions'][cluster_id]
        plt.scatter(features_2d[indices, 0], features_2d[indices, 1], 
                   label=f'Cluster {cluster_id}', alpha=0.6)

noise_indices = np.where(np.array(best_result['labels']) == -1)[0]
plt.scatter(features_2d[noise_indices, 0], features_2d[noise_indices, 1], 
           color='gray', alpha=0.3, label='Noise')

plt.title(f'DBSCAN Clustering (window={window_size}, eps={best_result["eps"]}, min_samples={min_samples})')
plt.xlabel('PCA Component 1')
plt.ylabel('PCA Component 2')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig('dbscan_feature_space.png', dpi=150, bbox_inches='tight')
plt.close()

# Plot 2: Spatial distribution
plt.figure(figsize=(12, 6))
plt.plot(rob_x, rob_y, 'k-', alpha=0.2)

recurring_clusters = []
for cluster_id, positions in best_result['cluster_positions'].items():
    gaps = np.diff(positions) > 10
    if len(positions) > 1 and np.any(gaps):
        recurring_clusters.append((cluster_id, len(positions), positions))

colors = plt.cm.tab20(np.linspace(0, 1, len(recurring_clusters)))

for idx, (cluster_id, count, positions) in enumerate(recurring_clusters[:8]):
    center_indices = [pos + window_size//2 for pos in positions]
    plt.scatter(rob_x[center_indices], rob_y[center_indices],
               color=colors[idx], s=60, alpha=0.8,
               label=f'Cluster {cluster_id} ({count}×)', edgecolors='k')

plt.title(f'Recurring Sonar Patterns (window={window_size}, eps={best_result["eps"]})')
plt.xlabel('X position (mm)')
plt.ylabel('Y position (mm)')
plt.axis('equal')
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('dbscan_spatial_distribution.png', dpi=150, bbox_inches='tight')
plt.close()

print(f"\nSaved plots to:")
print(f"  - dbscan_feature_space.png")
print(f"  - dbscan_spatial_distribution.png")

print(f"\n=== COMPARISON: DBSCAN vs KMeans ===")
print(f"DBSCAN (this script):")
print(f"  - Only forms clusters when sequences are truly similar")
print(f"  - Allows noise points (unique sequences)")
print(f"  - Found {best_result['n_clusters']} coherent clusters")
print(f"  - {best_result['recurring']} of these recur at different locations")

print(f"\nKMeans (previous script):")
print(f"  - Forced every sequence into a cluster")
print(f"  - Found 7 clusters, all assigned")
print(f"  - Some 'recurring patterns' may have been artificial")

if best_result['recurring'] > 2:
    print(f"\n✓ DBSCAN found {best_result['recurring']} coherent recurring patterns!")
    print(f"  These represent truly similar sonar sequences that repeat")
    print(f"  {best_result['n_noise']/len(best_result['labels'])*100:.1f}% of sequences are unique/noise")
else:
    print(f"\n✗ DBSCAN found few coherent patterns")
    print(f"  Most sonar sequences are unique to their context")
    print(f"  The KMeans 'patterns' may have been somewhat forced")
