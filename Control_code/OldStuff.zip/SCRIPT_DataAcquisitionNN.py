"""
Data Acquisition script using Neural Network predictions for sonar processing.
This script runs alongside the traditional SCRIPT_DataAcquisition.py but uses
the trained TwinTowerNet model for distance and side predictions.
"""
import time
from matplotlib import pyplot as plt

from Library import Dialog
from Library import Client
from Library import Utils
from Library import LorexTracker
from Library import DataStorage
from Library import PauseControl
from Library import SonarNN
from LorexLib.Environment import capture_environment_layout

# Configuration
robot_number = 1
session = 'session_nn_test'  # Use a different session name for NN data
wait_for_confirmation = False
do_rotation = False
do_translation = False
do_plot = True
max_steps = 5

# Initialize components
control = PauseControl.PauseControl()
client = Client.Client(robot_number=robot_number)
tracker = LorexTracker.LorexTracker()
writer = DataStorage.DataWriter(session, autoclear=True, verbose=False)
writer.add_file('Library/Settings.py')
snapshot = capture_environment_layout(save_root=f'Data/{session}')
nn_model, nn_meta = SonarNN.load_network("Models/distance_side_twin_enhanced.pt")

rotation = 0  # Initialize to avoid pycharm warnings

distances = []

for step in range(max_steps):
    control.wait_if_paused()
    
    # Data acquisition
    client.acquire('ping')
    Utils.sleep_ms(0, 50)
    sonar_package = client.read_and_process(do_ping=False, plot=do_plot, selection_mode='first')
    # Get classic measurements
    corrected_iid = sonar_package['corrected_iid']
    corrected_distance = sonar_package['corrected_distance']
    side_code = sonar_package['side_code']

    # Get position
    position = tracker.get_position(robot_number)
    rob_x = position['x']
    rob_y = position['y']
    rob_yaw_deg = position['yaw_deg']

    # Get nn measurements
    nn_side_code = 'C'
    sonar_data = sonar_package.get('sonar_data', None)
    left_sonar = sonar_data[:, 1]  # Left channel
    right_sonar = sonar_data[:, 2]  # Right channel
    nn_distance, nn_side = SonarNN.processNN(left_sonar, right_sonar, nn_model, nn_meta)
    # nn_side = -1 means obstacle closer on LEFT, nn_side = 1 means obstacle closer on RIGHT
    if nn_side == -1: nn_side_code = 'L'
    if nn_side == 1:  nn_side_code = 'R'


    print(f"Step {step}: IID {corrected_iid}, Distance {corrected_distance:.2f},Side {side_code} ")
    print(f"NN: {nn_distance:.2f} m, {nn_side}, {nn_side_code}")
    print(f"Position X:{rob_x}, Y:{rob_y}, Yaw:{rob_yaw_deg}")

    # Robot control logic (same as original but using selected measurements)
    step_distance = 0.20
    rotation_magnitude = 10

    #nn_side_code = side_code
    #nn_distance = corrected_distance
    
    if do_rotation:
        if nn_distance < 1: rotation_magnitude = 20
        if nn_distance < 0.25: rotation_magnitude = 35
        if nn_side_code == 'L': rotation = rotation_magnitude *  1
        if nn_side_code == 'R': rotation = rotation_magnitude * -1
        client.step(angle=rotation)
    
    if do_translation:
        if nn_distance < 1: step_distance = 0.10
        if nn_distance < 0.25: step_distance = 0.05
        client.step(distance=step_distance)

    # Wait or confirm
    if wait_for_confirmation:
        response = Dialog.ask_yes_no("Continue", min_size=(400, 200))
        if response[0] == 'No': break
    else:
        time.sleep(0.5)
    
    # Save data
    motion = {'distance': step_distance, 'rotation': rotation}
    nn_package = {'nn_distance': nn_distance, 'nn_side_code': nn_side_code, 'nn_side': nn_side}
    writer.save_data(sonar_package=sonar_package, position=position, motion=motion, nn_package=nn_package)
    distances.append(nn_distance)
print("Data acquisition completed.")

plt.figure()
plt.plot(distances)
plt.show()