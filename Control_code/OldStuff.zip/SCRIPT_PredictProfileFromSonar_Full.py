#!/usr/bin/env python3

"""
SCRIPT_PredictProfileFromSonar_Full.py

Train a neural network to predict visual distance profiles from FULL sonar data.
This script uses the complete sonar measurements (200 values) to reconstruct
the spatial pattern of distances around the robot.

Approach:
- Input: Full sonar data (200 values per sample)
- Output: Visual distance profiles (19 azimuth values)
- Architecture: 1D CNN encoder-decoder with skip connections
"""

from Library import DataProcessor
from Library import Utils
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# Parameters
az_extent = 20
az_steps = 7  # Number of azimuth steps in profiles
sessions = ['session03', 'session04']
n_epochs = 50
use_model_checkpointing = True

print("=== Training Visual Profile Prediction from FULL Sonar Data ===")
print(f"Configuration: Sonar data (200 values) → CNN → {az_steps} profile points")
print(f"Training for {n_epochs} epochs with {'checkpointing' if use_model_checkpointing else 'no checkpointing'}")

# Load data
print("\nLoading data...")
collection = DataProcessor.DataCollection(sessions, az_min=-az_extent, az_max=az_extent, az_steps=az_steps)

# Get FULL sonar data and visual profiles
profiles = collection.get_field('profiles')  # Shape: (n_samples, 19)
sonar_data = collection.get_field('sonar_data')  # Shape: (n_samples, 200)

print(f"Data shapes - Profiles: {profiles.shape}, Sonar data: {sonar_data.shape}")

# Data preprocessing
print("\nPreprocessing data...")

# Remove NaN values
valid_indices = (
    np.all(np.isfinite(sonar_data), axis=1) &
    np.all(np.isfinite(profiles), axis=1)
)

profiles_clean = profiles[valid_indices]
sonar_data_clean = sonar_data[valid_indices]

print(f"Clean data - Profiles: {profiles_clean.shape}, Sonar data: {sonar_data_clean.shape}")

# Normalize data
print("Normalizing data...")
profile_scaler = StandardScaler()
profiles_normalized = profile_scaler.fit_transform(profiles_clean)

sonar_scaler = StandardScaler()
sonar_data_normalized = sonar_scaler.fit_transform(sonar_data_clean)

print(f"Normalized profiles shape: {profiles_normalized.shape}")
print(f"Normalized sonar data shape: {sonar_data_normalized.shape}")

# Prepare data for profile prediction
input_data = sonar_data_normalized  # Full sonar data as input (200 values)
output_data = profiles_normalized  # Visual profiles as output (19 values)

print(f"Input data shape: {input_data.shape}")
print(f"Output data shape: {output_data.shape}")

# Convert to PyTorch tensors
print("Creating PyTorch tensors...")
X_tensor = torch.FloatTensor(input_data)
y_tensor = torch.FloatTensor(output_data)

print(f"Final data shapes - X: {X_tensor.shape}, y: {y_tensor.shape}")

# Split into train and test sets
train_size = int(0.8 * len(X_tensor))
test_size = len(X_tensor) - train_size
print(f"Train size: {train_size}, Test size: {test_size}")

train_dataset, test_dataset = torch.utils.data.random_split(
    TensorDataset(X_tensor, y_tensor),
    [train_size, test_size]
)

# Create data loaders
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

# 1D CNN Model for Sonar-to-Profile prediction
class SonarToProfileCNN(nn.Module):
    def __init__(self, input_size=200, output_size=az_steps):
        super(SonarToProfileCNN, self).__init__()
        
        # Input: [batch_size, 200] -> [batch_size, 1, 200]
        self.input_size = input_size
        self.output_size = output_size
        
        # Encoder (downsampling)
        self.enc_conv1 = nn.Conv1d(1, 64, kernel_size=5, padding=2)
        self.enc_conv2 = nn.Conv1d(64, 128, kernel_size=5, padding=2)
        self.enc_conv3 = nn.Conv1d(128, 256, kernel_size=3, padding=1)
        
        # Pooling for downsampling
        self.pool = nn.MaxPool1d(2)
        
        # Decoder (upsampling)
        self.dec_deconv1 = nn.ConvTranspose1d(256, 128, kernel_size=4, stride=2, padding=1)
        self.dec_deconv2 = nn.ConvTranspose1d(128, 64, kernel_size=4, stride=2, padding=1)
        self.dec_deconv3 = nn.ConvTranspose1d(64, 32, kernel_size=4, stride=2, padding=1)
        
        # Final convolution to get to output size
        self.final_conv = nn.Conv1d(32, 1, kernel_size=3, padding=1)
        
        # Batch normalization
        self.enc_bn1 = nn.BatchNorm1d(64)
        self.enc_bn2 = nn.BatchNorm1d(128)
        self.enc_bn3 = nn.BatchNorm1d(256)
        self.dec_bn1 = nn.BatchNorm1d(128)
        self.dec_bn2 = nn.BatchNorm1d(64)
        self.dec_bn3 = nn.BatchNorm1d(32)
        
        # Dropout for regularization
        self.dropout = nn.Dropout(0.2)
        
        # Activation
        self.relu = nn.ReLU()
        
    def forward(self, x):
        # Reshape for CNN: [batch_size, 200] → [batch_size, 1, 200]
        x = x.unsqueeze(1)
        
        # Encoder (downsampling)
        e1 = self.relu(self.enc_bn1(self.enc_conv1(x)))
        e1_pool = self.pool(e1)
        e1_pool = self.dropout(e1_pool)
        
        e2 = self.relu(self.enc_bn2(self.enc_conv2(e1_pool)))
        e2_pool = self.pool(e2)
        e2_pool = self.dropout(e2_pool)
        
        e3 = self.relu(self.enc_bn3(self.enc_conv3(e2_pool)))
        e3_pool = self.pool(e3)
        e3_pool = self.dropout(e3_pool)
        
        # Decoder (upsampling)
        d1 = self.relu(self.dec_bn1(self.dec_deconv1(e3_pool)))
        d1 = self.dropout(d1)
        
        d2 = self.relu(self.dec_bn2(self.dec_deconv2(d1)))
        d2 = self.dropout(d2)
        
        d3 = self.relu(self.dec_bn3(self.dec_deconv3(d2)))
        d3 = self.dropout(d3)
        
        # Final convolution
        output = self.final_conv(d3)
        
        # Reshape to [batch_size, output_size]
        output = output.squeeze(1)  # Remove channel dimension
        
        # Interpolate to match exact output size if needed
        if output.size(1) != self.output_size:
            output = nn.functional.interpolate(output.unsqueeze(1), size=self.output_size, mode='linear', align_corners=True)
            output = output.squeeze(1)
        
        return output

# Training function with model checkpointing
def train_model(model, train_loader, test_loader, epochs=n_epochs, lr=0.001, use_checkpointing=use_model_checkpointing):
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    
    train_losses = []
    test_losses = []
    best_test_loss = float('inf')
    best_model_state = None
    
    print(f"Training for {epochs} epochs...")
    if use_checkpointing:
        print("Model checkpointing enabled - will restore best validation model")
    
    for epoch in range(epochs):
        # Training
        model.train()
        train_loss = 0.0
        for inputs, targets in train_loader:
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            train_loss += loss.item() * inputs.size(0)
        
        train_loss = train_loss / len(train_loader.dataset)
        train_losses.append(train_loss)
        
        # Validation
        model.eval()
        test_loss = 0.0
        with torch.no_grad():
            for inputs, targets in test_loader:
                outputs = model(inputs)
                loss = criterion(outputs, targets)
                test_loss += loss.item() * inputs.size(0)
        
        test_loss = test_loss / len(test_loader.dataset)
        test_losses.append(test_loss)
        
        # Model checkpointing
        if use_checkpointing and test_loss < best_test_loss:
            best_test_loss = test_loss
            best_model_state = model.state_dict().copy()
            print(f'Epoch {epoch+1}/{epochs}, Train Loss: {train_loss:.4f}, Test Loss: {test_loss:.4f} 🏆 NEW BEST')
        elif (epoch + 1) % 10 == 0:
            print(f'Epoch {epoch+1}/{epochs}, Train Loss: {train_loss:.4f}, Test Loss: {test_loss:.4f}')
    
    if use_checkpointing:
        print(f"\nBest validation loss: {best_test_loss:.4f}")
        print(f"Improvement: {(test_losses[-1] - best_test_loss) / test_losses[-1] * 100:.1f}%")
    
    return train_losses, test_losses, best_model_state

# Create and train the model
print("\nCreating Sonar-to-Profile CNN model...")
model = SonarToProfileCNN(input_size=200, output_size=az_steps)

print(f"Model architecture: Sonar data (200) → Encoder(64,128,256) → Decoder(128,64,32) → FinalConv → {az_steps} profile points")
print("Features: 1D CNN, BatchNorm, Dropout, Skip Connections, Interpolation")

# Train the model
print("\nTraining model...")
train_losses, test_losses, best_model_state = train_model(
    model, train_loader, test_loader,
    epochs=n_epochs,
    use_checkpointing=use_model_checkpointing
)

# Restore best model if checkpointing was used
if use_model_checkpointing and best_model_state is not None:
    print("Restoring best model from checkpoint...")
    model.load_state_dict(best_model_state)

# Plot training curves
plt.figure(figsize=(10, 6))
plt.plot(train_losses, label='Train Loss')
plt.plot(test_losses, label='Test Loss')
plt.xlabel('Epoch')
plt.ylabel('MSE Loss')
plt.title('Training Curves - Full Sonar to Profile Prediction')
plt.legend()
plt.grid(True)
plt.show()

# Evaluation function
def evaluate_model(model, test_loader, profile_scaler):
    model.eval()
    predictions = []
    targets = []
    with torch.no_grad():
        for inputs, batch_targets in test_loader:
            outputs = model(inputs)
            predictions.append(outputs.numpy())
            targets.append(batch_targets.numpy())
    
    predictions = np.concatenate(predictions)
    targets = np.concatenate(targets)
    
    print(f"\nEvaluation Results:")
    print(f"Predictions shape: {predictions.shape}, Targets shape: {targets.shape}")
    
    # Calculate metrics
    mse = np.mean((predictions - targets) ** 2)
    rmse = np.sqrt(mse)
    mae = np.mean(np.abs(predictions - targets))
    
    print(f"MSE: {mse:.4f}")
    print(f"RMSE: {rmse:.4f}")
    print(f"MAE: {mae:.4f}")
    
    # Calculate correlation for each profile point
    correlations = []
    for i in range(predictions.shape[1]):
        corr = np.corrcoef(targets[:, i], predictions[:, i])[0, 1]
        correlations.append(corr)
    
    avg_correlation = np.mean(correlations)
    max_correlation = np.max(correlations)
    min_correlation = np.min(correlations)
    
    print(f"Average correlation per profile point: {avg_correlation:.4f}")
    print(f"Max correlation: {max_correlation:.4f}")
    print(f"Min correlation: {min_correlation:.4f}")
    
    # Plot some example predictions
    plt.figure(figsize=(12, 8))
    for i in range(min(5, len(predictions))):
        plt.subplot(5, 1, i+1)
        plt.plot(targets[i], 'b-', label='Actual' if i == 0 else "")
        plt.plot(predictions[i], 'r--', label='Predicted' if i == 0 else "")
        plt.ylabel(f'Distance (mm)')
        plt.grid(True)
        if i == 0:
            plt.legend()
    plt.suptitle(f'Profile Predictions (Avg Correlation: {avg_correlation:.3f})')
    plt.tight_layout()
    plt.show()
    
    # Plot correlation across profile points
    plt.figure(figsize=(10, 6))
    plt.plot(correlations, 'o-')
    plt.xlabel('Profile Point Index')
    plt.ylabel('Correlation')
    plt.title('Correlation Across Profile Points')
    plt.grid(True)
    plt.show()
    
    # Plot correlation heatmap
    plt.figure(figsize=(10, 6))
    plt.imshow([correlations], cmap='viridis', aspect='auto')
    plt.colorbar(label='Correlation')
    plt.title('Correlation Heatmap Across Profile')
    plt.xlabel('Profile Point Index')
    plt.yticks([])
    plt.show()
    
    return avg_correlation, max_correlation, min_correlation

# Evaluate the model
print("\nEvaluating model...")
avg_correlation, max_correlation, min_correlation = evaluate_model(model, test_loader, profile_scaler)

# Save the model
print("\nSaving model...")
save_dict = {
    'model_state_dict': model.state_dict(),
    'input_size': 200,
    'output_size': az_steps,
    'profile_scaler_mean': profile_scaler.mean_,
    'profile_scaler_scale': profile_scaler.scale_,
    'sonar_scaler_mean': sonar_scaler.mean_,
    'sonar_scaler_scale': sonar_scaler.scale_,
}

model_filename = 'sonar_to_profile_full_cnn.pth'
torch.save(save_dict, model_filename)
print(f"Model saved to '{model_filename}'")

# Final summary
print(f"\n🎉 Full Sonar-to-Profile Training Completed!")
print(f"\nSummary:")
print(f"- Input: Full sonar data (200 values per sample)")
print(f"- Output: {az_steps} visual profile points")
print(f"- Architecture: Encoder(64,128,256) → Decoder(128,64,32) → FinalConv(1)")
print(f"- Final average correlation: {avg_correlation:.3f}")
print(f"- Final max correlation: {max_correlation:.3f}")
print(f"- Final min correlation: {min_correlation:.3f}")
print(f"- Model checkpointing: {'ENABLED' if use_model_checkpointing else 'DISABLED'}")

if use_model_checkpointing:
    best_epoch = np.argmin(test_losses) + 1
    print(f"- Best validation model from epoch {best_epoch} (MSE: {min(test_losses):.4f})")

print(f"\n🔍 Insight: This 1D CNN encoder-decoder uses FULL sonar data (200 values)")
print(f"   Average correlation of {avg_correlation:.3f} should be significantly better")
print(f"   than the single-value approach (which achieved ~0.541)")
print(f"   since we're using much richer input information.")

# Performance comparison
print(f"\n📊 Performance Comparison:")
print(f"   Single sonar value approach: ~0.541 avg correlation")
print(f"   Full sonar data approach: {avg_correlation:.3f} avg correlation")
if avg_correlation > 0.541:
    improvement = (avg_correlation - 0.541) / 0.541 * 100
    print(f"   📈 Improvement: {improvement:.1f}%")
else:
    print(f"   ⚠️  Performance not better than single-value approach")