#!/usr/bin/env python3

"""
SCRIPT_PredictProfileFromSonar.py

Train a neural network to predict visual distance profiles from sonar measurements.
This script explores whether sonar distance measurements can be used to reconstruct
the spatial pattern of distances around the robot.

Approach:
- Input: Sonar distance measurements (single value)
- Output: Visual distance profiles (121 azimuth values)
- Architecture: CNN-based decoder with upsampling
"""

from Library import DataProcessor
from Library import Utils
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# Parameters
az_extent = 15
az_steps = 7  # Number of azimuth steps in profiles
sessions = ['session03', 'session04']
n_epochs = 250
use_model_checkpointing = True

print("=== Training Visual Profile Prediction from Sonar Measurements ===")
print(f"Configuration: Sonar distance → CNN Decoder → {az_steps} profile points")
print(f"Training for {n_epochs} epochs with {'checkpointing' if use_model_checkpointing else 'no checkpointing'}")

# Load data
print("\nLoading data...")
collection = DataProcessor.DataCollection(sessions, az_min=-az_extent, az_max=az_extent, az_steps=az_steps)

# Get sonar measurements and visual profiles
profiles = collection.get_field('profiles')  # Shape: (n_samples, 121)
corrected_distances = collection.get_field('corrected_distance')  # Shape: (n_samples, 1) in meters

print(f"Data shapes - Profiles: {profiles.shape}, Corrected distances: {corrected_distances.shape}")

# Convert meters to millimeters for consistency
target_distances = corrected_distances * 1000  # Convert m to mm
print(f"Target distances: {target_distances.shape} (converted to mm)")

# Data preprocessing
print("\nPreprocessing data...")

# Remove NaN values
valid_indices = (
    np.isfinite(target_distances).flatten() &
    np.all(np.isfinite(profiles), axis=1)
)

profiles_clean = profiles[valid_indices]
target_distances_clean = target_distances[valid_indices]

print(f"Clean data - Profiles: {profiles_clean.shape}, Target distances: {target_distances_clean.shape}")

# Normalize data
print("Normalizing data...")
profile_scaler = StandardScaler()
profiles_normalized = profile_scaler.fit_transform(profiles_clean)

# Normalize sonar distances
distance_scaler = StandardScaler()
target_distances_normalized = distance_scaler.fit_transform(target_distances_clean.reshape(-1, 1)).flatten()

# Prepare data for profile prediction
input_data = target_distances_normalized  # Sonar distances as input
output_data = profiles_normalized  # Visual profiles as output

print(f"Input data shape: {input_data.shape}")
print(f"Output data shape: {output_data.shape}")

# Convert to PyTorch tensors
print("Creating PyTorch tensors...")
X_tensor = torch.FloatTensor(input_data)
y_tensor = torch.FloatTensor(output_data)

print(f"Final data shapes - X: {X_tensor.shape}, y: {y_tensor.shape}")

# Split into train and test sets
train_size = int(0.8 * len(X_tensor))
test_size = len(X_tensor) - train_size
print(f"Train size: {train_size}, Test size: {test_size}")

train_dataset, test_dataset = torch.utils.data.random_split(
    TensorDataset(X_tensor, y_tensor),
    [train_size, test_size]
)

# Create data loaders
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

# CNN Decoder Model for Sonar-to-Profile prediction
class SonarToProfileCNN(nn.Module):
    def __init__(self, output_size=az_steps):
        super(SonarToProfileCNN, self).__init__()
        
        # Input is sonar distance (1 value), we'll expand it
        self.input_expansion = nn.Linear(1, 64)
        
        # Transpose convolution layers to upsample
        self.deconv1 = nn.ConvTranspose1d(64, 128, kernel_size=4, stride=2, padding=1)
        self.deconv2 = nn.ConvTranspose1d(128, 64, kernel_size=4, stride=2, padding=1)
        self.deconv3 = nn.ConvTranspose1d(64, 32, kernel_size=4, stride=2, padding=1)
        
        # Final convolution to get to output size
        self.final_conv = nn.Conv1d(32, 1, kernel_size=3, padding=1)
        
        # Batch normalization
        self.bn1 = nn.BatchNorm1d(128)
        self.bn2 = nn.BatchNorm1d(64)
        self.bn3 = nn.BatchNorm1d(32)
        
        # Dropout for regularization
        self.dropout = nn.Dropout(0.2)
        
        # Activation
        self.relu = nn.ReLU()
        
        # Calculate final output size
        # Starting from 1, then upsampling: 1 → 2 → 4 → 8
        # Final conv maintains size
        self.output_size = output_size
        
    def forward(self, x):
        # Expand input from [batch_size, 1] to [batch_size, 64, 1]
        x = self.relu(self.input_expansion(x))
        x = x.unsqueeze(2)  # Add spatial dimension
        
        # Transpose convolutions for upsampling
        x1 = self.relu(self.bn1(self.deconv1(x)))
        x1 = self.dropout(x1)
        
        x2 = self.relu(self.bn2(self.deconv2(x1)))
        x2 = self.dropout(x2)
        
        x3 = self.relu(self.bn3(self.deconv3(x2)))
        x3 = self.dropout(x3)
        
        # Final convolution
        output = self.final_conv(x3)
        
        # Reshape to [batch_size, output_size]
        output = output.squeeze(1)  # Remove channel dimension
        
        # Interpolate to match exact output size if needed
        if output.size(1) != self.output_size:
            output = nn.functional.interpolate(output.unsqueeze(1), size=self.output_size, mode='linear', align_corners=True)
            output = output.squeeze(1)
        
        return output

# Training function with model checkpointing
def train_model(model, train_loader, test_loader, epochs=n_epochs, lr=0.001, use_checkpointing=use_model_checkpointing):
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    
    train_losses = []
    test_losses = []
    best_test_loss = float('inf')
    best_model_state = None
    
    print(f"Training for {epochs} epochs...")
    if use_checkpointing:
        print("Model checkpointing enabled - will restore best validation model")
    
    for epoch in range(epochs):
        # Training
        model.train()
        train_loss = 0.0
        for inputs, targets in train_loader:
            optimizer.zero_grad()
            outputs = model(inputs.unsqueeze(1))  # Add feature dimension
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            train_loss += loss.item() * inputs.size(0)
        
        train_loss = train_loss / len(train_loader.dataset)
        train_losses.append(train_loss)
        
        # Validation
        model.eval()
        test_loss = 0.0
        with torch.no_grad():
            for inputs, targets in test_loader:
                outputs = model(inputs.unsqueeze(1))  # Add feature dimension
                loss = criterion(outputs, targets)
                test_loss += loss.item() * inputs.size(0)
        
        test_loss = test_loss / len(test_loader.dataset)
        test_losses.append(test_loss)
        
        # Model checkpointing
        if use_checkpointing and test_loss < best_test_loss:
            best_test_loss = test_loss
            best_model_state = model.state_dict().copy()
            print(f'Epoch {epoch+1}/{epochs}, Train Loss: {train_loss:.4f}, Test Loss: {test_loss:.4f} 🏆 NEW BEST')
        elif (epoch + 1) % 10 == 0:
            print(f'Epoch {epoch+1}/{epochs}, Train Loss: {train_loss:.4f}, Test Loss: {test_loss:.4f}')
    
    if use_checkpointing:
        print(f"\nBest validation loss: {best_test_loss:.4f}")
        print(f"Improvement: {(test_losses[-1] - best_test_loss) / test_losses[-1] * 100:.1f}%")
    
    return train_losses, test_losses, best_model_state

# Create and train the model
print("\nCreating Sonar-to-Profile CNN model...")
model = SonarToProfileCNN(output_size=az_steps)

print(f"Model architecture: Sonar distance → Expand(64) → Deconv(128,64,32) → FinalConv → {az_steps} profile points")
print("Features: Transpose Convolutions, BatchNorm, Dropout, Interpolation")

# Train the model
print("\nTraining model...")
train_losses, test_losses, best_model_state = train_model(
    model, train_loader, test_loader,
    epochs=n_epochs,
    use_checkpointing=use_model_checkpointing
)

# Restore best model if checkpointing was used
if use_model_checkpointing and best_model_state is not None:
    print("Restoring best model from checkpoint...")
    model.load_state_dict(best_model_state)

# Plot training curves
plt.figure(figsize=(10, 6))
plt.plot(train_losses, label='Train Loss')
plt.plot(test_losses, label='Test Loss')
plt.xlabel('Epoch')
plt.ylabel('MSE Loss')
plt.title('Training Curves - Sonar to Profile Prediction')
plt.legend()
plt.grid(True)
plt.show()

# Evaluation function
def evaluate_model(model, test_loader, profile_scaler):
    model.eval()
    predictions = []
    targets = []
    with torch.no_grad():
        for inputs, batch_targets in test_loader:
            outputs = model(inputs.unsqueeze(1))  # Add feature dimension
            predictions.append(outputs.numpy())
            targets.append(batch_targets.numpy())
    
    predictions = np.concatenate(predictions)
    targets = np.concatenate(targets)
    
    print(f"\nEvaluation Results:")
    print(f"Predictions shape: {predictions.shape}, Targets shape: {targets.shape}")
    
    # Calculate metrics
    mse = np.mean((predictions - targets) ** 2)
    rmse = np.sqrt(mse)
    mae = np.mean(np.abs(predictions - targets))
    
    print(f"MSE: {mse:.4f}")
    print(f"RMSE: {rmse:.4f}")
    print(f"MAE: {mae:.4f}")
    
    # Calculate correlation for each profile point
    correlations = []
    for i in range(predictions.shape[1]):
        corr = np.corrcoef(targets[:, i], predictions[:, i])[0, 1]
        correlations.append(corr)
    
    avg_correlation = np.mean(correlations)
    print(f"Average correlation per profile point: {avg_correlation:.4f}")
    
    # Plot some example predictions
    plt.figure(figsize=(12, 8))
    for i in range(min(5, len(predictions))):
        plt.subplot(5, 1, i+1)
        plt.plot(targets[i], 'b-', label='Actual' if i == 0 else "")
        plt.plot(predictions[i], 'r--', label='Predicted' if i == 0 else "")
        plt.ylabel(f'Distance (mm)')
        plt.grid(True)
        if i == 0:
            plt.legend()
    plt.suptitle(f'Profile Predictions (Avg Correlation: {avg_correlation:.3f})')
    plt.tight_layout()
    plt.show()
    
    # Plot correlation across profile points
    plt.figure(figsize=(10, 6))
    plt.plot(correlations, 'o-')
    plt.xlabel('Profile Point Index')
    plt.ylabel('Correlation')
    plt.title('Correlation Across Profile Points')
    plt.grid(True)
    plt.show()
    
    return avg_correlation

# Evaluate the model
print("\nEvaluating model...")
avg_correlation = evaluate_model(model, test_loader, profile_scaler)

# Save the model
print("\nSaving model...")
save_dict = {
    'model_state_dict': model.state_dict(),
    'output_size': az_steps,
    'profile_scaler_mean': profile_scaler.mean_,
    'profile_scaler_scale': profile_scaler.scale_,
    'distance_scaler_mean': distance_scaler.mean_,
    'distance_scaler_scale': distance_scaler.scale_,
}

model_filename = 'sonar_to_profile_cnn.pth'
torch.save(save_dict, model_filename)
print(f"Model saved to '{model_filename}'")

# Final summary
print(f"\n🎉 Sonar-to-Profile Training Completed!")
print(f"\nSummary:")
print(f"- Input: Sonar distance (1 value)")
print(f"- Output: {az_steps} visual profile points")
print(f"- Architecture: Expand(64) → Deconv(128,64,32) → FinalConv(1)")
print(f"- Final average correlation: {avg_correlation:.3f}")
print(f"- Model checkpointing: {'ENABLED' if use_model_checkpointing else 'DISABLED'}")

if use_model_checkpointing:
    best_epoch = np.argmin(test_losses) + 1
    print(f"- Best validation model from epoch {best_epoch} (MSE: {min(test_losses):.4f})")

print(f"\n🔍 Insight: This CNN decoder attempts to reconstruct visual profiles from sonar measurements")
print(f"   Average correlation of {avg_correlation:.3f} indicates the {'effectiveness' if avg_correlation > 0.5 else 'challenge'}")
print(f"   of predicting spatial patterns from single sonar distance measurements.")