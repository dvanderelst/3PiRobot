#%%
"""
Train a small neural network to map binaural sonar measurements to the closest obstacle
distance derived from the overhead camera system.
"""
import numpy as np
import torch
import torch.nn as nn
from sklearn.decomposition import FastICA, PCA
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import Dataset, DataLoader
from Library import Utils
from Library import DataProcessor
from matplotlib import pyplot as plt
from matplotlib import colors
from pathlib import Path

torch.set_num_threads(1)
torch.set_num_interop_threads(1)

seed = 123
np.random.seed(seed)
torch.manual_seed(seed)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device, flush=True)

# -----------------------------
# Settings
# -----------------------------
az_steps = 11
max_extent = 30
use_raw_sonar = True
reduction = "ica"  # "pca", "ica", or None
base_components = 75
batch_size_train = 64
batch_size_val = 128
drop_p = 0.1
epochs = 400
patience = 100
error_thresh_m = 0

# -----------------------------
# Load and collate data
# -----------------------------
processor1 = DataProcessor.DataProcessor("session6")
processor2 = DataProcessor.DataProcessor("session7")
processor3 = DataProcessor.DataProcessor("session8")

collated1 = processor1.collate_data(az_min=-max_extent, az_max=max_extent, az_steps=az_steps)
collated2 = processor2.collate_data(az_min=-max_extent, az_max=max_extent, az_steps=az_steps)
collated3 = processor3.collate_data(az_min=-max_extent, az_max=max_extent, az_steps=az_steps)

collated_results = [collated1, collated2, collated3]
profiles = DataProcessor.collect(collated_results, "profiles")
sonar_flat = DataProcessor.collect(collated_results, "sonar_data")  # flattened L/R echoes
sonar_distance = DataProcessor.collect(collated_results, "corrected_distance")  # meters
rob_x = DataProcessor.collect(collated_results, "rob_x")
rob_y = DataProcessor.collect(collated_results, "rob_y")
rob_yaw_deg = DataProcessor.collect(collated_results, "rob_yaw_deg")
wall_x = processor1.wall_x
wall_y = processor1.wall_y



# -----------------------------
# Ground-truth targets from camera data
# -----------------------------
closest_visual_distance = Utils.get_extrema_values(profiles, "min") / 1000.0  # meters

# -----------------------------
# Build feature matrix
# -----------------------------
if use_raw_sonar:
    X = sonar_flat.astype(np.float32)
else:
    raise ValueError("No sonar features selected.")

y_reg_raw = closest_visual_distance.astype(np.float32)
y_reg = np.log1p(y_reg_raw)

valid = np.isfinite(X).all(axis=1)
valid &= np.isfinite(y_reg)
valid &= np.isfinite(rob_x)
valid &= np.isfinite(rob_y)
valid &= np.isfinite(rob_yaw_deg)

X = X[valid]
y_reg = y_reg[valid]
y_reg_raw = y_reg_raw[valid]
closest_visual_distance = closest_visual_distance[valid]
sonar_distance = sonar_distance[valid]
rob_x = rob_x[valid]
rob_y = rob_y[valid]
rob_yaw_deg = rob_yaw_deg[valid]
sample_idx = np.arange(X.shape[0])

# -----------------------------
# Train/val split
# -----------------------------
X_train, X_val, y_reg_train, y_reg_val, y_reg_raw_train, y_reg_raw_val, sonar_distance_train, sonar_distance_val, idx_train, idx_val = train_test_split(
    X,
    y_reg,
    y_reg_raw,
    sonar_distance,
    sample_idx,
    test_size=0.2,
    random_state=seed,
    shuffle=True,
)

# -----------------------------
# Standardize features using train stats
# -----------------------------
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_val = scaler.transform(X_val)

# -----------------------------
# Optional dimensionality reduction
# -----------------------------
if reduction in ("pca", "ica"):
    n_components = base_components
    n_components = min(n_components, X_train.shape[1])
    if reduction == "pca":
        reducer = PCA(n_components=n_components, random_state=seed)
    else:
        reducer = FastICA(n_components=n_components, random_state=seed, max_iter=1000)
    X_train = reducer.fit_transform(X_train)
    X_val = reducer.transform(X_val)

# -----------------------------
# Standardize regression targets
# -----------------------------
y_reg_mean = float(y_reg_train.mean())
y_reg_std = float(y_reg_train.std())
if y_reg_std == 0:
    y_reg_std = 1.0
y_reg_train_n = (y_reg_train - y_reg_mean) / y_reg_std
y_reg_val_n = (y_reg_val - y_reg_mean) / y_reg_std


class SonarDataset(Dataset):
    def __init__(self, X, y_reg_n):
        self.X = torch.from_numpy(X.astype(np.float32))
        self.y_reg_n = torch.from_numpy(y_reg_n.astype(np.float32))

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        return self.X[idx], self.y_reg_n[idx]


train_loader = DataLoader(
    SonarDataset(X_train, y_reg_train_n),
    batch_size=batch_size_train,
    shuffle=True,
    drop_last=False,
)
val_loader = DataLoader(
    SonarDataset(X_val, y_reg_val_n),
    batch_size=batch_size_val,
    shuffle=False,
    drop_last=False,
)

input_dim = X_train.shape[1]
hidden1 = max(128, min(512, input_dim * 2))
hidden2 = max(96, min(320, input_dim))
hidden3 = max(48, min(160, input_dim // 2))


class SonarNet(nn.Module):
    def __init__(self, in_dim, h1, h2, h3, drop_p):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, h1),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(h1, h2),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(h2, h3),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(h3, 1),
        )

    def forward(self, x):
        return self.net(x)


model = SonarNet(input_dim, hidden1, hidden2, hidden3, drop_p).to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
criterion_reg = nn.SmoothL1Loss()

best_val = float("inf")
best_state = None
pat_left = patience

for epoch in range(1, epochs + 1):
    model.train()
    total_loss = 0.0
    for xb, yb_reg in train_loader:
        xb = xb.to(device)
        yb_reg = yb_reg.to(device)
        optimizer.zero_grad()
        pred_reg = model(xb).squeeze(1)
        loss = criterion_reg(pred_reg, yb_reg)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * xb.size(0)

    train_loss = total_loss / len(train_loader.dataset)

    model.eval()
    val_loss = 0.0
    with torch.no_grad():
        for xb, yb_reg in val_loader:
            xb = xb.to(device)
            yb_reg = yb_reg.to(device)
            pred_reg = model(xb).squeeze(1)
            loss = criterion_reg(pred_reg, yb_reg)
            val_loss += loss.item() * xb.size(0)

    val_loss /= len(val_loader.dataset)
    with torch.no_grad():
        y_reg_pred_n = model(torch.from_numpy(X_val).to(device)).squeeze(1).cpu().numpy()
    y_reg_pred_log = y_reg_pred_n * y_reg_std + y_reg_mean
    y_reg_pred = np.expm1(y_reg_pred_log)
    y_reg_true = y_reg_raw_val
    dist_mae = float(np.mean(np.abs(y_reg_pred - y_reg_true)))

    print(
        f"Epoch {epoch:03d} | train loss {train_loss:.5f} | val loss {val_loss:.5f} | "
        f"dist MAE {dist_mae:.3f} m",
        flush=True,
    )

    if val_loss < best_val - 1e-6:
        best_val = val_loss
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        pat_left = patience
    else:
        pat_left -= 1
        if pat_left <= 0:
            print("Early stop", flush=True)
            break

if best_state is not None:
    model.load_state_dict(best_state)

# -----------------------------
# Evaluation and plots
# -----------------------------
model.eval()
with torch.no_grad():
    pred_reg_n = model(torch.from_numpy(X_val).to(device)).squeeze(1)
    pred_reg_log = pred_reg_n.cpu().numpy() * y_reg_std + y_reg_mean
    pred_reg = np.expm1(pred_reg_log)

true_reg = y_reg_raw_val
dist_mae = float(np.mean(np.abs(pred_reg - true_reg)))

print(f"Val distance MAE (m): {dist_mae:.3f}", flush=True)

# Baseline: sonar distance
baseline_dist_mae = float(np.mean(np.abs(sonar_distance_val - y_reg_raw_val)))
print(f"Baseline distance MAE (m): {baseline_dist_mae:.3f}", flush=True)

plot_min = float(min(true_reg.min(), pred_reg.min(), sonar_distance_val.min()))
plot_max = float(max(true_reg.max(), pred_reg.max(), sonar_distance_val.max()))
lims = [plot_min, plot_max]

plt.figure(figsize=(12, 5))
nn_rho = float(np.corrcoef(true_reg, pred_reg)[0, 1])
sonar_rho = float(np.corrcoef(true_reg, sonar_distance_val)[0, 1])

plt.subplot(1, 2, 1)
plt.scatter(true_reg, pred_reg, s=8, alpha=0.5)
plt.plot(lims, lims, "k--", linewidth=1)
plt.xlabel("True distance (m)")
plt.ylabel("Predicted distance (m)")
plt.title(f"NN prediction (val) r={nn_rho:.2f}")
plt.xlim(lims)
plt.ylim(lims)

plt.subplot(1, 2, 2)
plt.scatter(true_reg, sonar_distance_val, s=8, alpha=0.5)
plt.plot(lims, lims, "k--", linewidth=1)
plt.xlabel("True distance (m)")
plt.ylabel("Sonar distance (m)")
plt.title(f"Sonar baseline (val) r={sonar_rho:.2f}")
plt.xlim(lims)
plt.ylim(lims)

plt.tight_layout()
plt.show()

#%%
# -----------------------------
# Spatial error plot for large errors
# -----------------------------
plots_dir = Path("Plots")
plots_dir.mkdir(parents=True, exist_ok=True)

signed_err = pred_reg - true_reg
abs_err = np.abs(signed_err)
val_idx = idx_val.astype(int)
err_mask = abs_err >= error_thresh_m

plt.figure(figsize=(6, 6))
plt.scatter(wall_x, wall_y, s=1, alpha=0.3, color="gray")
vx = rob_x[val_idx]
vy = rob_y[val_idx]
yaw_rad = np.deg2rad(rob_yaw_deg[val_idx])
u = np.cos(yaw_rad)
v = np.sin(yaw_rad)

plt.scatter(vx[~err_mask], vy[~err_mask], s=8, alpha=0.5, color="lightgray", label="Lower error")
max_abs_err = float(np.max(abs_err)) if abs_err.size else 1.0
norm = colors.TwoSlopeNorm(vmin=-max_abs_err, vcenter=0.0, vmax=max_abs_err)
sc = plt.scatter(
    vx[err_mask],
    vy[err_mask],
    s=14,
    c=signed_err[err_mask],
    cmap="coolwarm",
    norm=norm,
    alpha=1,
    label=f"Error >= {error_thresh_m:.2f} m",
)
plt.quiver(
    vx[~err_mask],
    vy[~err_mask],
    u[~err_mask],
    v[~err_mask],
    angles="xy",
    scale_units="xy",
    scale=0.02,
    color="green",
    width=0.002,
)
plt.quiver(
    vx[err_mask],
    vy[err_mask],
    u[err_mask],
    v[err_mask],
    angles="xy",
    scale_units="xy",
    scale=0.02,
    color="black",
    width=0.003,
)
plt.colorbar(sc, label="Signed error (m)")
plt.title("Distance prediction errors (validation)")
plt.xlabel("X")
plt.ylabel("Y")
plt.axis("equal")
plt.legend()
plt.tight_layout()
plt.savefig(plots_dir / "distance_error_map.png", dpi=150)
plt.show()
