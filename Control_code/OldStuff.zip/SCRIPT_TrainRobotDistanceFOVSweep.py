#%%
"""
Sweep FOV (max_extent) with fixed angular resolution and evaluate how well
sonar predicts the closest visual distance.
"""
import numpy as np
import torch
import torch.nn as nn
from sklearn.decomposition import FastICA, PCA
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import Dataset, DataLoader
from Library import Utils
from Library import DataProcessor
from matplotlib import pyplot as plt
from pathlib import Path


torch.set_num_threads(1)
torch.set_num_interop_threads(1)

seed = 123
np.random.seed(seed)
torch.manual_seed(seed)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device, flush=True)

# -----------------------------
# Settings
# -----------------------------
max_extents = [10, 20, 30, 60, 80]
step_deg = 1
use_raw_sonar = True
reduction = "ica"  # "pca", "ica", or None
base_components = 45
batch_size_train = 64
batch_size_val = 128
drop_p = 0.1
epochs = 300
patience = 60
min_samples = 50


def compute_az_steps(max_extent, step_deg):
    steps = int(np.round((2 * max_extent) / step_deg)) + 1
    return max(3, steps)


class SonarDataset(Dataset):
    def __init__(self, X, y_reg_n):
        self.X = torch.from_numpy(X.astype(np.float32))
        self.y_reg_n = torch.from_numpy(y_reg_n.astype(np.float32))

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        return self.X[idx], self.y_reg_n[idx]


class SonarNet(nn.Module):
    def __init__(self, in_dim, h1, h2, h3, drop_p):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, h1),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(h1, h2),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(h2, h3),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(h3, 1),
        )

    def forward(self, x):
        return self.net(x)


def train_eval_for_fov(max_extent):
    az_steps = compute_az_steps(max_extent, step_deg)
    processor1 = DataProcessor.DataProcessor("session6")
    processor2 = DataProcessor.DataProcessor("session7")
    processor3 = DataProcessor.DataProcessor("session8")

    collated1 = processor1.collate_data(az_min=-max_extent, az_max=max_extent, az_steps=az_steps)
    collated2 = processor2.collate_data(az_min=-max_extent, az_max=max_extent, az_steps=az_steps)
    collated3 = processor3.collate_data(az_min=-max_extent, az_max=max_extent, az_steps=az_steps)

    collated_results = [collated1, collated2, collated3]
    profiles = DataProcessor.collect(collated_results, "profiles")
    sonar_flat = DataProcessor.collect(collated_results, "sonar_data")
    sonar_distance = DataProcessor.collect(collated_results, "corrected_distance")

    closest_visual_distance = Utils.get_extrema_values(profiles, "min") / 1000.0

    if use_raw_sonar:
        X = sonar_flat.astype(np.float32)
    else:
        raise ValueError("No sonar features selected.")

    y_reg_raw = closest_visual_distance.astype(np.float32)
    y_reg = np.log1p(y_reg_raw)

    valid = np.isfinite(X).all(axis=1)
    valid &= np.isfinite(y_reg)

    X = X[valid]
    y_reg = y_reg[valid]
    y_reg_raw = y_reg_raw[valid]
    sonar_distance = sonar_distance[valid]

    if X.shape[0] < min_samples:
        print(f"Skipping FOV ±{max_extent} deg: only {X.shape[0]} samples", flush=True)
        return None

    X_train, X_val, y_reg_train, y_reg_val, y_reg_raw_train, y_reg_raw_val, sonar_distance_train, sonar_distance_val = train_test_split(
        X,
        y_reg,
        y_reg_raw,
        sonar_distance,
        test_size=0.2,
        random_state=seed,
        shuffle=True,
    )

    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_val = scaler.transform(X_val)

    if reduction in ("pca", "ica"):
        n_components = base_components
        n_components = min(n_components, X_train.shape[1])
        if reduction == "pca":
            reducer = PCA(n_components=n_components, random_state=seed)
        else:
            reducer = FastICA(n_components=n_components, random_state=seed, max_iter=1000)
        X_train = reducer.fit_transform(X_train)
        X_val = reducer.transform(X_val)

    y_reg_mean = float(y_reg_train.mean())
    y_reg_std = float(y_reg_train.std())
    if y_reg_std == 0:
        y_reg_std = 1.0
    y_reg_train_n = (y_reg_train - y_reg_mean) / y_reg_std
    y_reg_val_n = (y_reg_val - y_reg_mean) / y_reg_std

    train_loader = DataLoader(
        SonarDataset(X_train, y_reg_train_n),
        batch_size=batch_size_train,
        shuffle=True,
        drop_last=False,
    )
    val_loader = DataLoader(
        SonarDataset(X_val, y_reg_val_n),
        batch_size=batch_size_val,
        shuffle=False,
        drop_last=False,
    )

    input_dim = X_train.shape[1]
    hidden1 = max(128, min(512, input_dim * 2))
    hidden2 = max(96, min(320, input_dim))
    hidden3 = max(48, min(160, input_dim // 2))

    model = SonarNet(input_dim, hidden1, hidden2, hidden3, drop_p).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    criterion_reg = nn.SmoothL1Loss()

    best_val = float("inf")
    best_state = None
    pat_left = patience

    for _epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0
        for xb, yb_reg in train_loader:
            xb = xb.to(device)
            yb_reg = yb_reg.to(device)
            optimizer.zero_grad()
            pred_reg = model(xb).squeeze(1)
            loss = criterion_reg(pred_reg, yb_reg)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * xb.size(0)

        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for xb, yb_reg in val_loader:
                xb = xb.to(device)
                yb_reg = yb_reg.to(device)
                pred_reg = model(xb).squeeze(1)
                loss = criterion_reg(pred_reg, yb_reg)
                val_loss += loss.item() * xb.size(0)
        val_loss /= len(val_loader.dataset)

        if val_loss < best_val - 1e-6:
            best_val = val_loss
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            pat_left = patience
        else:
            pat_left -= 1
            if pat_left <= 0:
                break

    if best_state is not None:
        model.load_state_dict(best_state)

    model.eval()
    with torch.no_grad():
        pred_reg_n = model(torch.from_numpy(X_val).to(device)).squeeze(1)
        pred_reg_log = pred_reg_n.cpu().numpy() * y_reg_std + y_reg_mean
        pred_reg = np.expm1(pred_reg_log)

    true_reg = y_reg_raw_val
    mae = float(np.mean(np.abs(pred_reg - true_reg)))
    if true_reg.size < 2:
        rho = float("nan")
    else:
        rho = float(np.corrcoef(true_reg, pred_reg)[0, 1])
    baseline_mae = float(np.mean(np.abs(sonar_distance_val - true_reg)))
    return {
        "max_extent": max_extent,
        "az_steps": az_steps,
        "mae": mae,
        "rho": rho,
        "baseline_mae": baseline_mae,
        "n_val": int(true_reg.shape[0]),
    }


results = []
for max_extent in max_extents:
    res = train_eval_for_fov(max_extent)
    if res is None:
        continue
    results.append(res)
    print(
        f"FOV ±{res['max_extent']} deg | az_steps {res['az_steps']} | "
        f"MAE {res['mae']:.3f} m | r {res['rho']:.2f} | baseline {res['baseline_mae']:.3f} m",
        flush=True,
    )

if not results:
    raise RuntimeError("No valid FOV settings produced enough samples.")

results = sorted(results, key=lambda r: r["max_extent"])
extents = [r["max_extent"] for r in results]
mae_vals = [r["mae"] for r in results]
rho_vals = [r["rho"] for r in results]
base_vals = [r["baseline_mae"] for r in results]

plots_dir = Path("Plots")
plots_dir.mkdir(parents=True, exist_ok=True)

plt.figure(figsize=(7, 4))
plt.plot(extents, mae_vals, marker="o", label="NN MAE")
plt.plot(extents, base_vals, marker="o", linestyle="--", label="Sonar baseline MAE")
plt.xlabel("Max extent (deg)")
plt.ylabel("MAE (m)")
plt.title("Distance MAE vs FOV (fixed angular resolution)")
plt.legend()
plt.tight_layout()
plt.savefig(plots_dir / "distance_fov_sweep_mae.png", dpi=150)
plt.show()
#%%
plt.figure(figsize=(7, 4))
plt.plot(extents, rho_vals, marker="o", label="NN correlation")
plt.xlabel("Max extent (deg)")
plt.ylabel("Correlation r")
plt.title("Distance correlation vs FOV (fixed angular resolution)")
plt.ylim(0.5, 1.0)
plt.legend()
plt.tight_layout()
plt.savefig(plots_dir / "distance_fov_sweep_r.png", dpi=150)
plt.show()
