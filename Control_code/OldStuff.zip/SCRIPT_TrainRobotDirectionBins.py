#%%
"""
Train a small neural network to map binaural sonar measurements to the side
of the closest (min distance) and farthest (max distance) obstacles derived
from the overhead camera system.
"""
import numpy as np
import torch
import torch.nn as nn
from sklearn.decomposition import FastICA, PCA
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import Dataset, DataLoader
from Library import Utils
from Library import DataProcessor
from matplotlib import pyplot as plt
from pathlib import Path


torch.set_num_threads(1)
torch.set_num_interop_threads(1)

seed = 123
np.random.seed(seed)
torch.manual_seed(seed)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device, flush=True)

# -----------------------------
# Settings
# -----------------------------
az_steps = 51
max_extent = 45
use_raw_sonar = True
reduction = "pca"  # "pca", "ica", or None
base_components = 75
batch_size_train = 64
batch_size_val = 128
drop_p = 0.1
epochs = 400
patience = 50

# -----------------------------
# Load and collate data
# -----------------------------
processor1 = DataProcessor.DataProcessor("session6")
processor2 = DataProcessor.DataProcessor("session7")
processor3 = DataProcessor.DataProcessor("session8")

collated1 = processor1.collate_data(az_min=-max_extent, az_max=max_extent, az_steps=az_steps)
collated2 = processor2.collate_data(az_min=-max_extent, az_max=max_extent, az_steps=az_steps)
collated3 = processor3.collate_data(az_min=-max_extent, az_max=max_extent, az_steps=az_steps)

collated_results = [collated1, collated2, collated3]
centers = np.round(collated1["centers"]).astype(np.float32)
profiles = DataProcessor.collect(collated_results, "profiles")
sonar_flat = DataProcessor.collect(collated_results, "sonar_data")  # flattened L/R echoes
sonar_iid = DataProcessor.collect(collated_results, "corrected_iid")  # dB

# Robot x, y, yaw and environment x,y 
rob_x = DataProcessor.collect(collated_results, "rob_x")
rob_y = DataProcessor.collect(collated_results, "rob_y")
rob_yaw_deg = DataProcessor.collect(collated_results, "rob_yaw_deg")
wall_x = processor1.wall_x
wall_y = processor1.wall_y

# -----------------------------
# Ground-truth targets from camera data
# -----------------------------
min_idx = Utils.get_extrema_positions(profiles, "min").astype(np.int64)
max_idx = Utils.get_extrema_positions(profiles, "max").astype(np.int64)
min_direction = centers[min_idx].astype(np.float32)
max_direction = centers[max_idx].astype(np.float32)
min_side = (np.sign(min_direction) * -1).astype(np.int64)  # -1, 0, 1
max_side = (np.sign(max_direction) * -1).astype(np.int64)  # -1, 0, 1
min_distance = Utils.get_extrema_values(profiles, "min").astype(np.float32) / 1000.0
max_distance = Utils.get_extrema_values(profiles, "max").astype(np.float32) / 1000.0

# -----------------------------
# Build feature matrix
# -----------------------------
if use_raw_sonar:
    X = sonar_flat.astype(np.float32)
else:
    raise ValueError("No sonar features selected.")

valid = np.isfinite(X).all(axis=1)
valid &= np.isfinite(min_distance)
valid &= np.isfinite(max_distance)
valid &= np.isfinite(min_side)
valid &= np.isfinite(max_side)

X = X[valid]
min_side = min_side[valid]
max_side = max_side[valid]
min_distance = min_distance[valid]
max_distance = max_distance[valid]
sonar_iid = sonar_iid[valid]
profiles = profiles[valid]
sonar_flat = sonar_flat[valid]
rob_x = rob_x[valid]
rob_y = rob_y[valid]
rob_yaw_deg = rob_yaw_deg[valid]
sample_idx = np.arange(X.shape[0])

same_side_rate = float(np.mean(min_side == max_side))
print(f"Min/max on same side: {same_side_rate:.3f}", flush=True)

# -----------------------------
# Train/val split
# -----------------------------
X_train, X_val, y_min_train, y_min_val, y_max_train, y_max_val, min_dist_train, min_dist_val, max_dist_train, max_dist_val, sonar_iid_train, sonar_iid_val, idx_train, idx_val = train_test_split(
    X,
    min_side,
    max_side,
    min_distance,
    max_distance,
    sonar_iid,
    sample_idx,
    test_size=0.2,
    random_state=seed,
    shuffle=True,
)

# -----------------------------
# Standardize features using train stats
# -----------------------------
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_val = scaler.transform(X_val)

# -----------------------------
# Optional dimensionality reduction
# -----------------------------
if reduction in ("pca", "ica"):
    n_components = base_components
    n_components = min(n_components, X_train.shape[1])
    if reduction == "pca":
        reducer = PCA(n_components=n_components, random_state=seed)
    else:
        reducer = FastICA(n_components=n_components, random_state=seed, max_iter=1000)
    X_train = reducer.fit_transform(X_train)
    X_val = reducer.transform(X_val)


class SonarDataset(Dataset):
    def __init__(self, X, y_min, y_max):
        self.X = torch.from_numpy(X.astype(np.float32))
        self.y_min = torch.from_numpy(y_min.astype(np.int64))
        self.y_max = torch.from_numpy(y_max.astype(np.int64))

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        return self.X[idx], self.y_min[idx], self.y_max[idx]


train_loader = DataLoader(
    SonarDataset(X_train, y_min_train, y_max_train),
    batch_size=batch_size_train,
    shuffle=True,
    drop_last=False,
)
val_loader = DataLoader(
    SonarDataset(X_val, y_min_val, y_max_val),
    batch_size=batch_size_val,
    shuffle=False,
    drop_last=False,
)

input_dim = X_train.shape[1]
hidden1 = max(128, min(512, input_dim * 2))
hidden2 = max(96, min(320, input_dim))
hidden3 = max(48, min(160, input_dim // 2))


class SonarNet(nn.Module):
    def __init__(self, in_dim, h1, h2, h3, drop_p, n_bins):
        super().__init__()
        self.backbone = nn.Sequential(
            nn.Linear(in_dim, h1),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(h1, h2),
            nn.ReLU(),
            nn.Dropout(drop_p),
            nn.Linear(h2, h3),
            nn.ReLU(),
            nn.Dropout(drop_p),
        )
        self.head_min = nn.Linear(h3, n_bins)
        self.head_max = nn.Linear(h3, n_bins)

    def forward(self, x):
        z = self.backbone(x)
        return self.head_min(z), self.head_max(z)


class_count = 3
model = SonarNet(input_dim, hidden1, hidden2, hidden3, drop_p, class_count).to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

min_counts = np.bincount(y_min_train + 1, minlength=class_count).astype(np.float32)
max_counts = np.bincount(y_max_train + 1, minlength=class_count).astype(np.float32)
min_weights = min_counts.sum() / np.clip(min_counts, 1.0, None)
max_weights = max_counts.sum() / np.clip(max_counts, 1.0, None)
min_weights = torch.from_numpy(min_weights).to(device)
max_weights = torch.from_numpy(max_weights).to(device)
criterion_min = nn.CrossEntropyLoss(weight=min_weights)
criterion_max = nn.CrossEntropyLoss(weight=max_weights)

best_val = float("inf")
best_state = None
pat_left = patience

for epoch in range(1, epochs + 1):
    model.train()
    total_loss = 0.0
    for xb, yb_min, yb_max in train_loader:
        xb = xb.to(device)
        yb_min = (yb_min + 1).to(device)
        yb_max = (yb_max + 1).to(device)
        optimizer.zero_grad()
        logits_min, logits_max = model(xb)
        loss_min = criterion_min(logits_min, yb_min)
        loss_max = criterion_max(logits_max, yb_max)
        loss = loss_min + loss_max
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * xb.size(0)

    train_loss = total_loss / len(train_loader.dataset)

    model.eval()
    val_loss = 0.0
    min_correct = 0
    max_correct = 0
    total = 0
    with torch.no_grad():
        for xb, yb_min, yb_max in val_loader:
            xb = xb.to(device)
            yb_min = (yb_min + 1).to(device)
            yb_max = (yb_max + 1).to(device)
            logits_min, logits_max = model(xb)
            loss_min = criterion_min(logits_min, yb_min)
            loss_max = criterion_max(logits_max, yb_max)
            loss = loss_min + loss_max
            val_loss += loss.item() * xb.size(0)
            preds_min = logits_min.argmax(dim=1)
            preds_max = logits_max.argmax(dim=1)
            min_correct += int((preds_min == yb_min).sum().item())
            max_correct += int((preds_max == yb_max).sum().item())
            total += yb_min.size(0)

    val_loss /= len(val_loader.dataset)
    min_acc = min_correct / max(1, total)
    max_acc = max_correct / max(1, total)

    print(
        f"Epoch {epoch:03d} | train loss {train_loss:.5f} | val loss {val_loss:.5f} | "
        f"min acc {min_acc:.3f} | max acc {max_acc:.3f}",
        flush=True,
    )

    if val_loss < best_val - 1e-6:
        best_val = val_loss
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        pat_left = patience
    else:
        pat_left -= 1
        if pat_left <= 0:
            print("Early stop", flush=True)
            break

if best_state is not None:
    model.load_state_dict(best_state)

# -----------------------------
# Evaluation and plots
# -----------------------------
model.eval()
with torch.no_grad():
    logits_min, logits_max = model(torch.from_numpy(X_val).to(device))
    pred_min = logits_min.argmax(dim=1).cpu().numpy() - 1
    pred_max = logits_max.argmax(dim=1).cpu().numpy() - 1

min_acc = float(np.mean(pred_min == y_min_val))
max_acc = float(np.mean(pred_max == y_max_val))
print(f"Val min-side accuracy: {min_acc:.3f}", flush=True)
print(f"Val max-side accuracy: {max_acc:.3f}", flush=True)

sonar_iid_sign = np.sign(sonar_iid_val)
baseline_min_side = float(np.mean(sonar_iid_sign == y_min_val))
baseline_max_side = float(np.mean(sonar_iid_sign == y_max_val))
print(f"Baseline IID sign accuracy (min side): {baseline_min_side:.3f}", flush=True)
print(f"Baseline IID sign accuracy (max side): {baseline_max_side:.3f}", flush=True)

conf_min = np.zeros((class_count, class_count), dtype=int)
for t, p in zip(y_min_val, pred_min):
    conf_min[int(t + 1), int(p + 1)] += 1

plt.figure(figsize=(4, 3))
plt.imshow(conf_min, cmap="Blues")
plt.xlabel("Predicted side")
plt.ylabel("True side")
plt.title("Min-side classification (val)")
plt.xticks([0, 1, 2], ["left", "center", "right"])
plt.yticks([0, 1, 2], ["left", "center", "right"])
plt.colorbar()
plt.tight_layout()
plt.show()

conf_max = np.zeros((class_count, class_count), dtype=int)
for t, p in zip(y_max_val, pred_max):
    conf_max[int(t + 1), int(p + 1)] += 1

plt.figure(figsize=(4, 3))
plt.imshow(conf_max, cmap="Blues")
plt.xlabel("Predicted side")
plt.ylabel("True side")
plt.title("Max-side classification (val)")
plt.xticks([0, 1, 2], ["left", "center", "right"])
plt.yticks([0, 1, 2], ["left", "center", "right"])
plt.colorbar()
plt.tight_layout()
plt.show()

# Accuracy vs distance (binned)
bin_count = 11
dist_min = float(np.nanmin([np.nanmin(min_dist_val), np.nanmin(max_dist_val)]))
dist_max = float(np.nanmax([np.nanmax(min_dist_val), np.nanmax(max_dist_val)]))
dist_edges = np.linspace(dist_min, dist_max, bin_count + 1)
dist_centers = 0.5 * (dist_edges[:-1] + dist_edges[1:])

def accuracy_by_distance(distances, pred_bins, true_bins, edges):
    acc = []
    for i in range(len(edges) - 1):
        if i == len(edges) - 2:
            in_bin = (distances >= edges[i]) & (distances <= edges[i + 1])
        else:
            in_bin = (distances >= edges[i]) & (distances < edges[i + 1])
        if not np.any(in_bin):
            acc.append(np.nan)
            continue
        acc.append(float(np.mean(pred_bins[in_bin] == true_bins[in_bin])))
    return acc

min_acc_by_bin = accuracy_by_distance(min_dist_val, pred_min, y_min_val, dist_edges)
max_acc_by_bin = accuracy_by_distance(max_dist_val, pred_max, y_max_val, dist_edges)

min_side_pred = np.sign(sonar_iid_val)
max_side_pred = min_side_pred.copy()
min_side_true = y_min_val
max_side_true = y_max_val
min_side_acc_by_bin = accuracy_by_distance(min_dist_val, min_side_pred, min_side_true, dist_edges)
max_side_acc_by_bin = accuracy_by_distance(max_dist_val, max_side_pred, max_side_true, dist_edges)

plt.figure(figsize=(6, 4))
plt.plot(dist_centers, min_acc_by_bin, marker="o", label="Min-side")
plt.plot(dist_centers, max_acc_by_bin, marker="o", label="Max-side")
plt.plot(dist_centers, min_side_acc_by_bin, marker="o", linestyle="--", label="IID min side")
plt.plot(dist_centers, max_side_acc_by_bin, marker="o", linestyle="--", label="IID max side")
plt.xlabel("Distance (m)")
plt.ylabel("Accuracy")
plt.title("Side accuracy vs distance")
plt.ylim(0.0, 1.0)
plt.legend()
plt.tight_layout()
plt.show()

# Cumulative accuracy vs distance
def cumulative_accuracy(distances, pred_bins, true_bins, thresholds):
    acc = []
    for edge in thresholds:
        in_range = distances <= edge
        if not np.any(in_range):
            acc.append(np.nan)
            continue
        acc.append(float(np.mean(pred_bins[in_range] == true_bins[in_range])))
    return acc

cum_edges = dist_edges[1:]
min_cum = cumulative_accuracy(min_dist_val, pred_min, y_min_val, cum_edges)
max_cum = cumulative_accuracy(max_dist_val, pred_max, y_max_val, cum_edges)
min_side_cum = cumulative_accuracy(min_dist_val, min_side_pred, min_side_true, cum_edges)
max_side_cum = cumulative_accuracy(max_dist_val, max_side_pred, max_side_true, cum_edges)

plt.figure(figsize=(6, 4))
plt.plot(cum_edges, min_cum, marker="o", label="Min-side")
plt.plot(cum_edges, max_cum, marker="o", label="Max-side")
plt.plot(cum_edges, min_side_cum, marker="o", linestyle="--", label="IID min side")
plt.plot(cum_edges, max_side_cum, marker="o", linestyle="--", label="IID max side")
plt.xlabel("Distance <= x (m)")
plt.ylabel("Cumulative accuracy")
plt.title("Cumulative side accuracy")
plt.ylim(0.0, 1.0)
plt.legend()
plt.tight_layout()
plt.show()

# Spatial error plots for validation failures
plots_dir = Path("Plots")
plots_dir.mkdir(parents=True, exist_ok=True)

def plot_error_map(title, val_indices, correct_mask, out_name):
    plt.figure(figsize=(6, 6))
    plt.scatter(wall_x, wall_y, s=1, alpha=0.3, color="gray")
    if val_indices.size > 0:
        vx = rob_x[val_indices]
        vy = rob_y[val_indices]
        ok = correct_mask
        plt.scatter(vx[ok], vy[ok], s=8, alpha=0.7, color="green", label="Correct")
        plt.scatter(vx[~ok], vy[~ok], s=8, alpha=0.7, color="red", label="Error")

        yaw_rad = np.deg2rad(rob_yaw_deg[val_indices])
        u = np.cos(yaw_rad)
        v = np.sin(yaw_rad)
        plt.quiver(
            vx[ok],
            vy[ok],
            u[ok],
            v[ok],
            angles="xy",
            scale_units="xy",
            scale=0.02,
            color="green",
            width=0.002,
        )
        plt.quiver(
            vx[~ok],
            vy[~ok],
            u[~ok],
            v[~ok],
            angles="xy",
            scale_units="xy",
            scale=0.02,
            color="red",
            width=0.003,
        )
    plt.title(title)
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.axis("equal")
    plt.legend()
    plt.tight_layout()
    plt.savefig(plots_dir / out_name, dpi=150)
    plt.show()

min_correct = pred_min == y_min_val
max_correct = pred_max == y_max_val
plot_error_map("Min-side validation errors", idx_val, min_correct, "min_side_errors.png")
plot_error_map("Max-side validation errors", idx_val, max_correct, "max_side_errors.png")



# # Failure analysis plots
# plots_dir = Path("Plots")
# plots_dir.mkdir(parents=True, exist_ok=True)
# profile_centers = centers
#
# def plot_failure(sample_id, task, true_side, pred_side):
#     sonar_row = sonar_flat[sample_id]
#     n_samples = sonar_row.shape[0] // 2
#     sonar_pair = sonar_row.reshape(n_samples, 2)
#     profile = profiles[sample_id]
#
#     plt.figure(figsize=(10, 4))
#     plt.subplot(1, 2, 1)
#     plt.plot(sonar_pair[:, 0], label="Left")
#     plt.plot(sonar_pair[:, 1], label="Right")
#     plt.xlabel("Sample")
#     plt.ylabel("Amplitude")
#     plt.title("Sonar waveform")
#     plt.legend()
#
#     plt.subplot(1, 2, 2)
#     plt.plot(profile_centers, profile, color="tab:blue")
#     plt.xlabel("Azimuth (deg)")
#     plt.ylabel("Distance")
#     plt.title(f"{task} side: true {true_side} pred {pred_side}")
#     plt.tight_layout()
#
#     out_path = plots_dir / f"fail_{task}_{sample_id}.png"
#     plt.savefig(out_path, dpi=150)
#     plt.close()
#
# for i, sid in enumerate(idx_val):
#     true_min = y_min_val[i]
#     true_max = y_max_val[i]
#     pred_min_i = pred_min[i]
#     pred_max_i = pred_max[i]
#     if pred_min_i != true_min:
#         plot_failure(int(sid), "min", int(true_min), int(pred_min_i))
#     if pred_max_i != true_max:
#         plot_failure(int(sid), "max", int(true_max), int(pred_max_i))
