from Library import DataProcessor
from Library import Utils
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# Parameters
az_extent = 45
az_steps = 7
sessions = ['session03', 'session04']
n_pca_components = 40  # Number of PCA components to use
n_epochs = 250  # Number of training epochs
use_model_checkpointing = True  # Whether to save best model based on validation loss

print("=== Simple MLP with PCA for Sonar Distance Prediction ===")
print(f"Configuration: {n_pca_components} PCA components, {n_epochs} epochs")

# Load data
print("Loading data...")
collection = DataProcessor.DataCollection(sessions, az_min=-az_extent, az_max=az_extent, az_steps=az_steps)
sonar_data_flat = collection.get_field('sonar_data')
profiles = collection.get_field('profiles')
closest_visual_distance = np.min(profiles, axis=1)
#For test: closest_visual_distance = collection.get_field('corrected_distance')

print(f"Original data shapes - Sonar: {sonar_data_flat.shape}, Target: {closest_visual_distance.shape}")

# Data preprocessing
print("Preprocessing data...")

# Remove NaN values
valid_indices = np.isfinite(closest_visual_distance) & np.all(np.isfinite(sonar_data_flat), axis=1)
sonar_data_clean = sonar_data_flat[valid_indices]
closest_distance_clean = closest_visual_distance[valid_indices]

print(f"Clean data shapes - Sonar: {sonar_data_clean.shape}, Target: {closest_distance_clean.shape}")

# Normalize data
print("Normalizing data...")
scaler = StandardScaler()
sonar_data_normalized = scaler.fit_transform(sonar_data_clean)

# Apply PCA for dimensionality reduction
print(f"Applying PCA with {n_pca_components} components...")
pca = PCA(n_components=n_pca_components)
sonar_data_pca = pca.fit_transform(sonar_data_normalized)

# Print PCA variance information
print(f"PCA explained variance ratio: {pca.explained_variance_ratio_.sum():.3f}")
print(f"PCA explained variance: {np.sum(pca.explained_variance_):.1f}")

# Plot PCA variance
plt.figure(figsize=(10, 5))
plt.bar(range(n_pca_components), pca.explained_variance_ratio_)
plt.xlabel('Principal Component')
plt.ylabel('Explained Variance Ratio')
plt.title(f'PCA Explained Variance (Total: {pca.explained_variance_ratio_.sum():.3f})')
plt.grid(True)
plt.show()

# Convert to PyTorch tensors
print("Creating PyTorch tensors...")
X_tensor = torch.FloatTensor(sonar_data_pca)
y_tensor = torch.FloatTensor(closest_distance_clean).view(-1, 1)

print(f"Reduced data shapes - X: {X_tensor.shape}, y: {y_tensor.shape}")

# Split into train and test sets
train_size = int(0.8 * len(X_tensor))
test_size = len(X_tensor) - train_size
print(f"Train size: {train_size}, Test size: {test_size}")

train_dataset, test_dataset = torch.utils.data.random_split(
    TensorDataset(X_tensor, y_tensor), 
    [train_size, test_size]
)

# Create data loaders
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

# Enhanced MLP Model with Advanced Features
class EnhancedMLP(nn.Module):
    def __init__(self, input_size=n_pca_components):
        super(EnhancedMLP, self).__init__()
        
        # Feature extraction layers - wider and deeper
        self.fc1 = nn.Linear(input_size, 256)      # Wider input layer
        self.fc2 = nn.Linear(256, 192)             # Progressive narrowing
        self.fc3 = nn.Linear(192, 128)             # Feature refinement
        self.fc4 = nn.Linear(128, 96)              # Additional refinement
        
        # Bottleneck and output
        self.fc5 = nn.Linear(96, 64)               # Bottleneck layer
        self.fc6 = nn.Linear(64, 1)                # Final prediction
        
        # Advanced regularization and normalization
        self.relu = nn.ReLU()
        self.dropout1 = nn.Dropout(0.3)           # Higher dropout early
        self.dropout2 = nn.Dropout(0.2)           # Lower dropout later
        self.batch_norm1 = nn.BatchNorm1d(256)    # Batch norm for stability
        self.batch_norm2 = nn.BatchNorm1d(192)    # Batch norm for stability
        
        # Skip connection (residual-like)
        self.skip_connection = nn.Linear(input_size, 64)
        
    def forward(self, x):
        # Main path with batch norm and dropout
        x1 = self.relu(self.batch_norm1(self.fc1(x)))
        x1 = self.dropout1(x1)
        
        x2 = self.relu(self.batch_norm2(self.fc2(x1)))
        x2 = self.dropout1(x2)
        
        x3 = self.relu(self.fc3(x2))
        x3 = self.dropout2(x3)
        
        x4 = self.relu(self.fc4(x3))
        x4 = self.dropout2(x4)
        
        # Bottleneck
        x5 = self.relu(self.fc5(x4))
        
        # Skip connection from input to bottleneck
        skip = self.relu(self.skip_connection(x))
        
        # Combine skip connection with main path
        combined = x5 + skip  # Residual-like connection
        
        # Final output
        output = self.fc6(combined)
        
        return output

# Training function with model checkpointing
def train_model(model, train_loader, test_loader, epochs=100, lr=0.001, use_checkpointing=False):
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    
    train_losses = []
    test_losses = []
    best_test_loss = float('inf')
    best_model_state = None
    
    print(f"Training for {epochs} epochs...")
    if use_checkpointing:
        print("Model checkpointing enabled - will restore best validation model")
    
    for epoch in range(epochs):
        # Training
        model.train()
        train_loss = 0.0
        for inputs, targets in train_loader:
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            train_loss += loss.item() * inputs.size(0)
        
        train_loss = train_loss / len(train_loader.dataset)
        train_losses.append(train_loss)
        
        # Testing/Validation
        model.eval()
        test_loss = 0.0
        with torch.no_grad():
            for inputs, targets in test_loader:
                outputs = model(inputs)
                loss = criterion(outputs, targets)
                test_loss += loss.item() * inputs.size(0)
        
        test_loss = test_loss / len(test_loader.dataset)
        test_losses.append(test_loss)
        
        # Model checkpointing - save best model based on validation loss
        if use_checkpointing and test_loss < best_test_loss:
            best_test_loss = test_loss
            best_model_state = model.state_dict().copy()
            print(f'Epoch {epoch+1}/{epochs}, Train Loss: {train_loss:.2f}, Test Loss: {test_loss:.2f} 🏆 NEW BEST')
        elif (epoch + 1) % 10 == 0:
            print(f'Epoch {epoch+1}/{epochs}, Train Loss: {train_loss:.2f}, Test Loss: {test_loss:.2f}')
    
    if use_checkpointing:
        print(f"\nBest validation loss: {best_test_loss:.2f}")
        print(f"Improvement over final model: {(test_losses[-1] - best_test_loss) / test_losses[-1] * 100:.1f}%")
    
    return train_losses, test_losses, best_model_state

# Create and train the model
print("\nCreating Enhanced MLP model...")
model = EnhancedMLP(input_size=n_pca_components)
print(f"Model architecture: {n_pca_components} -> 256 -> 192 -> 128 -> 96 -> 64(+skip) -> 1")
print("Features: BatchNorm, Progressive Dropout, Skip Connections")

# Train the model
print("\nTraining model...")
train_losses, test_losses, best_model_state = train_model(
    model, train_loader, test_loader, 
    epochs=n_epochs, 
    use_checkpointing=use_model_checkpointing
)

# Restore best model if checkpointing was used
if use_model_checkpointing and best_model_state is not None:
    print("Restoring best model from checkpoint...")
    model.load_state_dict(best_model_state)

# Plot training curves
plt.figure(figsize=(10, 6))
plt.plot(train_losses, label='Train Loss')
plt.plot(test_losses, label='Test Loss')
plt.xlabel('Epoch')
plt.ylabel('MSE Loss')
plt.title('Training Curves')
plt.legend()
plt.grid(True)
plt.show()

# Save the model
print("Saving model...")
torch.save({
    'model_state_dict': model.state_dict(),
    'pca_components': n_pca_components,
    'pca_mean': pca.mean_,
    'pca_components_array': pca.components_,
    'scaler_mean': scaler.mean_,
    'scaler_scale': scaler.scale_,
    'input_size': n_pca_components
}, 'enhanced_mlp_sonar_model.pth')
print("Model saved to 'enhanced_mlp_sonar_model.pth'")

# Evaluation function
def evaluate_model(model, test_loader):
    model.eval()
    predictions = []
    targets = []
    with torch.no_grad():
        for inputs, batch_targets in test_loader:
            outputs = model(inputs)
            predictions.append(outputs.numpy().flatten())
            targets.append(batch_targets.numpy().flatten())
    
    predictions = np.concatenate(predictions)
    targets = np.concatenate(targets)
    
    print(f"\nEvaluation Results:")
    print(f"Predictions shape: {predictions.shape}, Targets shape: {targets.shape}")
    
    # Calculate metrics
    mse = np.mean((predictions - targets) ** 2)
    rmse = np.sqrt(mse)
    mae = np.mean(np.abs(predictions - targets))
    
    # Calculate correlation
    correlation = np.corrcoef(targets, predictions)[0, 1]
    r_squared = correlation ** 2
    
    print(f"MSE: {mse:.2f}")
    print(f"RMSE: {rmse:.2f}")
    print(f"MAE: {mae:.2f}")
    print(f"Correlation (r): {correlation:.4f}")
    print(f"R-squared (r²): {r_squared:.4f}")
    print(f"Number of test samples: {len(targets)}")
    
    # Plot predictions vs actual with correlation
    plt.figure(figsize=(10, 6))
    plt.scatter(targets, predictions, alpha=0.5)
    plt.plot([min(targets), max(targets)], [min(targets), max(targets)], 'r--')
    plt.xlabel('Actual Distance (mm)')
    plt.ylabel('Predicted Distance (mm)')
    plt.title(f'Predictions vs Actual Values (r = {correlation:.3f}, r² = {r_squared:.3f})')
    plt.grid(True)
    plt.show()
    
    # Plot correlation analysis
    plt.figure(figsize=(12, 6))
    
    # Scatter plot
    plt.subplot(1, 2, 1)
    plt.scatter(targets, predictions, alpha=0.5)
    plt.plot([min(targets), max(targets)], [min(targets), max(targets)], 'r--')
    plt.xlabel('Actual Distance (mm)')
    plt.ylabel('Predicted Distance (mm)')
    plt.title('Actual vs Predicted')
    plt.grid(True)
    
    # Correlation plot (standardized)
    plt.subplot(1, 2, 2)
    targets_std = (targets - np.mean(targets)) / np.std(targets)
    predictions_std = (predictions - np.mean(predictions)) / np.std(predictions)
    plt.scatter(targets_std, predictions_std, alpha=0.5)
    plt.plot([-3, 3], [-3, 3], 'r--')  # Standardized range
    plt.xlabel('Standardized Actual Distance')
    plt.ylabel('Standardized Predicted Distance')
    plt.title(f'Standardized Correlation (r = {correlation:.3f})')
    plt.xlim(-3, 3)
    plt.ylim(-3, 3)
    plt.grid(True)
    
    plt.tight_layout()
    plt.show()
    
    # Plot residuals
    residuals = predictions - targets
    plt.figure(figsize=(10, 6))
    plt.scatter(targets, residuals, alpha=0.5)
    plt.axhline(y=0, color='r', linestyle='--')
    plt.xlabel('Actual Distance (mm)')
    plt.ylabel('Residuals (mm)')
    plt.title(f'Residual Plot (MAE = {mae:.2f} mm)')
    plt.grid(True)
    plt.show()
    
    # Print correlation interpretation
    print(f"\nCorrelation Interpretation:")
    if correlation > 0.9:
        print("🎯 Excellent correlation - Very strong linear relationship")
    elif correlation > 0.7:
        print("👍 Good correlation - Strong linear relationship")
    elif correlation > 0.5:
        print("🤔 Moderate correlation - Noticeable linear relationship")
    elif correlation > 0.3:
        print("⚠️  Weak correlation - Limited linear relationship")
    else:
        print("❌ Poor correlation - Little to no linear relationship")
    
    return correlation, r_squared

# Evaluate the model
print("\nEvaluating model...")
correlation, r_squared = evaluate_model(model, test_loader)

print("\n🎉 Training completed successfully!")
print(f"\nSummary:")
print(f"- Used {n_pca_components} PCA components capturing {pca.explained_variance_ratio_.sum():.1%} of variance")
print(f"- Trained Enhanced MLP: {n_pca_components} -> 256 -> 192 -> 128 -> 96 -> 64(+skip) -> 1")
print(f"- Model saved to 'enhanced_mlp_sonar_model.pth'")
print(f"- Final test MSE: {test_losses[-1]:.2f}")
print(f"- Final test correlation: {correlation:.3f}")
print(f"- Final test R-squared: {r_squared:.3f}")
print(f"- Model checkpointing: {'ENABLED' if use_model_checkpointing else 'DISABLED'}")
if use_model_checkpointing:
    best_epoch = np.argmin(test_losses) + 1
    print(f"- Best validation model from epoch {best_epoch} (MSE: {min(test_losses):.2f})")
