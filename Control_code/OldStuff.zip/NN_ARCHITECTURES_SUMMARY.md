# Neural Network Architectures for Sonar Distance Prediction

I've implemented 4 different neural network architectures in `SCRIPT_TrainRobot.py` for training a model to predict the closest distance to obstacles from sonar data.

## Data Understanding
- **Input**: Sonar data with shape `(250, 200)` - 250 samples, each with 200 sonar measurements
- **Output**: Closest visual distance with shape `(250,)` - minimum distance to obstacles in millimeters
- **Data Preprocessing**: Standard scaling, NaN removal, 80/20 train-test split

## Implemented Architectures

### 1. Simple MLP (Multi-Layer Perceptron)
```python
SimpleMLP(nn.Module):
    - Input: 200 features
    - Hidden layers: [128, 64, 32] neurons
    - Output: 1 (distance prediction)
    - Activation: ReLU
    - Regularization: Dropout (0.2)
```
**Characteristics**: Lightweight, fast training, good baseline
**Use case**: Quick prototyping, when computational resources are limited

### 2. Deep MLP
```python
DeepMLP(nn.Module):
    - Input: 200 features  
    - Hidden layers: [256, 128, 64, 32, 16] neurons
    - Output: 1 (distance prediction)
    - Activation: ReLU
    - Regularization: Dropout (0.3), BatchNorm on first two layers
```
**Characteristics**: Higher capacity, better feature extraction, more parameters
**Use case**: When you need more complex feature learning from sonar patterns

### 3. Wide and Deep MLP
```python
WideAndDeepMLP(nn.Module):
    - Wide path: Direct linear connection (200 → 1)
    - Deep path: [512, 256, 128, 64, 32] neurons
    - Combined output: wide_output + deep_output
    - Activation: ReLU
    - Regularization: Dropout (0.4), BatchNorm on first two deep layers
```
**Characteristics**: Combines memorization (wide) and generalization (deep) capabilities
**Use case**: When you want both raw feature importance and complex pattern learning

### 4. 1D CNN (Convolutional Neural Network)
```python
CNN1D(nn.Module):
    - Input: Reshaped to (batch_size, 1, 200) as 1D signal
    - Conv layers: 3 layers with [32, 64, 128] filters, kernel_size=5/3
    - Pooling: MaxPool1d(2) after each conv layer
    - FC layers: [128, 64] neurons after flattening
    - Output: 1 (distance prediction)
    - Activation: ReLU
    - Regularization: Dropout (0.3)
```
**Characteristics**: Specialized for sequential/spatial data, captures local patterns
**Use case**: When sonar data has spatial/temporal relationships that should be preserved

## Training Process
- **Optimizer**: Adam with learning rate 0.001
- **Loss Function**: Mean Squared Error (MSE)
- **Batch Size**: 32
- **Epochs**: 100 (configurable)
- **Evaluation**: Training and test loss tracking, final metrics (MSE, RMSE, MAE)

## Key Features
1. **Data Validation**: Automatic NaN removal and cleaning
2. **Normalization**: Standard scaling for better training stability
3. **Visualization**: Training curves and prediction vs actual plots
4. **Model Persistence**: Best model saved to 'best_sonar_distance_model.pth'
5. **Comprehensive Evaluation**: Multiple metrics and visual analysis

## Recommendations
1. **Start with Simple MLP** for baseline performance
2. **Try Deep MLP** if you need better accuracy
3. **Use Wide and Deep** for best balance of memorization and generalization
4. **Experiment with 1D CNN** if sonar data has spatial patterns

The script automatically trains all architectures and compares their performance, saving the best model for deployment.