#!/usr/bin/env python3
"""
CNN Training Script for Distance Prediction

This script trains a CNN to predict the minimum distance to walls
from conical views of the robot's arena.

Training Objective:
- Input: Conical view images (512x512x3 RGB)
- Output: Minimum distance from distance profiles (scalar in mm)

This is a regression task using mean squared error loss.
"""

import numpy as np
import pickle
import os
import matplotlib.pyplot as plt
from datetime import datetime
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, BatchNormalization
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Set random seeds for reproducibility
np.random.seed(42)
tf.random.set_seed(42)

def load_cached_data(session_name='session03', cache_dir='cache'):
    """
    Load cached data from pickle files.
    
    Returns:
        views: Conical view images (N, 512, 512, 3)
        profiles: Distance profiles (N, 19)
        sonar: Sonar data (N, 100, 2)
    """
    print(f"📂 Loading cached data for {session_name}...")
    
    # Load profiles
    with open(os.path.join(cache_dir, f'{session_name}_profiles.npy'), 'rb') as f:
        profiles_data = pickle.load(f)
        profiles = profiles_data['data']
    
    # Load centers (azimuth angles)
    with open(os.path.join(cache_dir, f'{session_name}_centers.npy'), 'rb') as f:
        centers_data = pickle.load(f)
        centers = centers_data['data']
    
    # Load views
    with open(os.path.join(cache_dir, f'{session_name}_views.npy'), 'rb') as f:
        views_data = pickle.load(f)
        views = views_data['data']
    
    # Load sonar data
    with open(os.path.join(cache_dir, f'{session_name}_sonar.npy'), 'rb') as f:
        sonar_data = pickle.load(f)
        sonar = sonar_data['data']
    
    print(f"✅ Loaded data:")
    print(f"   Views: {views.shape}")
    print(f"   Profiles: {profiles.shape}")
    print(f"   Centers: {centers.shape}")
    print(f"   Sonar: {sonar.shape}")
    
    return views, profiles, centers, sonar

def prepare_data(views, profiles):
    """
    Prepare data for training.
    
    Args:
        views: Conical view images
        profiles: Distance profiles
        
    Returns:
        X_train, X_val, y_train, y_val: Split and normalized data
    """
    print("🧹 Preparing data...")
    
    # Calculate minimum distances (target variable)
    min_distances = np.min(profiles, axis=1, keepdims=True)  # Shape: (N, 1)
    
    print(f"📊 Target statistics:")
    print(f"   Min distance range: {np.min(min_distances):.1f} - {np.max(min_distances):.1f} mm")
    print(f"   Mean min distance: {np.mean(min_distances):.1f} mm")
    print(f"   Std min distance: {np.std(min_distances):.1f} mm")
    
    # Normalize input images to [0, 1] range
    X = views.astype(np.float32) / 255.0
    
    # Normalize target values (standard scaling)
    scaler = StandardScaler()
    y = scaler.fit_transform(min_distances)
    
    # Split data into training and validation sets
    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.2, random_state=42, shuffle=True
    )
    
    print(f"📦 Data split:")
    print(f"   Training: {X_train.shape[0]} samples")
    print(f"   Validation: {X_val.shape[0]} samples")
    
    return X_train, X_val, y_train, y_val, scaler

def build_cnn_model(input_shape=(512, 512, 3)):
    """
    Build CNN model for distance prediction.
    
    Architecture:
    - Conv2D layers with batch normalization and dropout
    - Max pooling for downsampling
    - Dense layers for regression output
    """
    print("🏗️ Building CNN model...")
    
    model = Sequential([
        # Input layer
        Conv2D(32, (3, 3), activation='relu', input_shape=input_shape),
        BatchNormalization(),
        MaxPooling2D((2, 2)),
        Dropout(0.2),
        
        # Second convolutional layer
        Conv2D(64, (3, 3), activation='relu'),
        BatchNormalization(),
        MaxPooling2D((2, 2)),
        Dropout(0.3),
        
        # Third convolutional layer
        Conv2D(128, (3, 3), activation='relu'),
        BatchNormalization(),
        MaxPooling2D((2, 2)),
        Dropout(0.4),
        
        # Fourth convolutional layer
        Conv2D(256, (3, 3), activation='relu'),
        BatchNormalization(),
        MaxPooling2D((2, 2)),
        Dropout(0.5),
        
        # Flatten and dense layers
        Flatten(),
        Dense(512, activation='relu'),
        BatchNormalization(),
        Dropout(0.5),
        
        # Output layer (single value regression)
        Dense(1, activation='linear')
    ])
    
    # Compile model
    optimizer = Adam(learning_rate=0.001)
    model.compile(
        optimizer=optimizer,
        loss='mean_squared_error',
        metrics=['mean_absolute_error', 'mean_squared_error']
    )
    
    print("📋 Model summary:")
    model.summary()
    
    return model

def train_model(model, X_train, y_train, X_val, y_val, epochs=100, batch_size=8):
    """
    Train the CNN model with callbacks.
    
    Args:
        model: Compiled Keras model
        X_train, y_train: Training data
        X_val, y_val: Validation data
        epochs: Number of training epochs
        batch_size: Batch size for training
        
    Returns:
        trained model and training history
    """
    print("🚀 Starting training...")
    
    # Create callbacks
    callbacks = [
        EarlyStopping(
            monitor='val_loss', 
            patience=15, 
            restore_best_weights=True,
            verbose=1
        ),
        ReduceLROnPlateau(
            monitor='val_loss', 
            factor=0.5, 
            patience=5, 
            min_lr=1e-6,
            verbose=1
        ),
        ModelCheckpoint(
            'best_model.h5', 
            monitor='val_loss', 
            save_best_only=True,
            save_weights_only=False,
            verbose=1
        )
    ]
    
    # Train the model
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=epochs,
        batch_size=batch_size,
        callbacks=callbacks,
        verbose=1
    )
    
    print("🎉 Training completed!")
    return model, history

def evaluate_model(model, X_val, y_val, scaler, views, min_distances):
    """
    Evaluate model performance and show example predictions.
    
    Args:
        model: Trained model
        X_val, y_val: Validation data
        scaler: Target value scaler
        views: Original view images
        min_distances: Original minimum distances
    """
    print("📊 Evaluating model...")
    
    # Make predictions
    y_pred_scaled = model.predict(X_val)
    y_pred = scaler.inverse_transform(y_pred_scaled)
    y_true = scaler.inverse_transform(y_val)
    
    # Calculate metrics
    mae = np.mean(np.abs(y_pred - y_true))
    rmse = np.sqrt(np.mean((y_pred - y_true)**2))
    
    print(f"📈 Validation metrics:")
    print(f"   MAE: {mae:.1f} mm")
    print(f"   RMSE: {rmse:.1f} mm")
    
    # Show some example predictions
    plt.figure(figsize=(15, 10))
    
    # Get indices of some interesting predictions (sorted by error)
    errors = np.abs(y_pred.flatten() - y_true.flatten())
    sorted_indices = np.argsort(errors)
    
    # Show 6 examples: 3 with smallest error, 3 with largest error
    example_indices = []
    example_indices.extend(sorted_indices[:3])  # Best predictions
    example_indices.extend(sorted_indices[-3:])  # Worst predictions
    
    for i, idx in enumerate(example_indices):
        plt.subplot(2, 3, i+1)
        plt.imshow(views[idx])
        plt.title(f"True: {y_true[idx][0]:.0f}mm\nPred: {y_pred[idx][0]:.0f}mm\nErr: {errors[idx]:.0f}mm")
        plt.axis('off')
    
    plt.suptitle('Example Predictions (Top: Best, Bottom: Worst)', y=1.02)
    plt.tight_layout()
    plt.show()
    
    # Plot training history
    plt.figure(figsize=(12, 6))
    
    plt.subplot(1, 2, 1)
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.title('Training History - Loss')
    plt.xlabel('Epoch')
    plt.ylabel('MSE Loss')
    plt.legend()
    
    plt.subplot(1, 2, 2)
    plt.plot(history.history['mean_absolute_error'], label='Training MAE')
    plt.plot(history.history['val_mean_absolute_error'], label='Validation MAE')
    plt.title('Training History - MAE')
    plt.xlabel('Epoch')
    plt.ylabel('MAE (mm)')
    plt.legend()
    
    plt.tight_layout()
    plt.show()
    
    # Plot prediction vs actual
    plt.figure(figsize=(10, 6))
    plt.scatter(y_true, y_pred, alpha=0.6)
    plt.plot([min(y_true), max(y_true)], [min(y_true), max(y_true)], 'r--')
    plt.xlabel('Actual Minimum Distance (mm)')
    plt.ylabel('Predicted Minimum Distance (mm)')
    plt.title('Actual vs Predicted Minimum Distances')
    plt.grid(True)
    plt.show()

def main():
    """
    Main training pipeline.
    """
    print("🚀 Starting CNN Training for Distance Prediction")
    print("=" * 60)
    
    # Load data
    views, profiles, centers, sonar = load_cached_data('session03')
    
    # Prepare data
    X_train, X_val, y_train, y_val, scaler = prepare_data(views, profiles)
    
    # Build model
    model = build_cnn_model(input_shape=X_train.shape[1:])
    
    # Train model
    model, history = train_model(model, X_train, y_train, X_val, y_val, epochs=100, batch_size=8)
    
    # Evaluate model
    evaluate_model(model, X_val, y_val, scaler, views, np.min(profiles, axis=1))
    
    # Save final model
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    model.save(f'cnn_distance_predictor_{timestamp}.h5')
    print(f"💾 Model saved as: cnn_distance_predictor_{timestamp}.h5")
    
    print("🎉 Training complete!")

if __name__ == "__main__":
    main()