origin_folder = '/home/dieter/Dropbox/PythonRepos/3PiRobot/Robot_code/upload'
staging_folder = 'staging'

excluded_folders = ['__pycache__']
fixed_library_folders = ['pololu_3pi_2040_robot', 'umsgpack']
