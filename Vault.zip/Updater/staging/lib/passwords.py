# DO NOT ADD TO GIT
password0 = 'trainspotting'
password1 = 'lebowski'
password2 = '2BF0EBC3CC'